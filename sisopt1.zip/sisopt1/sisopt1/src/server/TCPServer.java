package server;
import java.io.*; 
import java.net.*;
import java.util.concurrent.Semaphore;

class TCPServer {

	public static void main(String argv[]) throws Exception 
	{ 
		QInteger contador = new QInteger();
		String clientSentence; 
		Semaphore mutex = new Semaphore(1);
		Semaphore escrita = new Semaphore(1);
		QInteger contadorLeitor = new QInteger();
		
		ServerSocket welcomeSocket = new ServerSocket(6793); 
		
		System.out.println("STARTO");

		while(true){ 
			Socket connectionSocket = welcomeSocket.accept();
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
			DataOutputStream  outToClient = new DataOutputStream(connectionSocket.getOutputStream());
			InetAddress IPAddress  = connectionSocket.getInetAddress();
			int port = connectionSocket.getPort();		
			
			clientSentence = inFromClient.readLine();
		
			
			System.out.println(IPAddress.getHostAddress() + ":" + port + " => " + clientSentence);

			
			
			if(clientSentence.equals("1")){
				Thread thread = new Thread(new Leitor(mutex, escrita, contadorLeitor, contador, outToClient, connectionSocket));
				thread.start();
				
			} else if(clientSentence.equals("2")){
				Thread thread = new Thread(new Escritor(escrita, contador, outToClient, connectionSocket));
				thread.start();
				
			} else if(clientSentence.equals("quit")){
				
				outToClient.writeBytes("Shutting down"); 
				connectionSocket.close();				
				break;
			}
		} 
		welcomeSocket.close();
	} 
} 