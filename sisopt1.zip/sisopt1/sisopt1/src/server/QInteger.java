package server;

public class QInteger {
	private int val;
	
	public QInteger() {
		this.val = 0;
	}
	
	public void increment(){
		val++;
	}
	public void decrement(){
		val--;
	}
	public void reset(){
		this.val = 0;
	}
	public int get(){
		return this.val;
	}
}
