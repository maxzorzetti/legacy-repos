package server;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.Semaphore;

public class Leitor implements Runnable {
	
	private Semaphore mutex;
	private QInteger contador;
	private DataOutputStream outToClient;
	private Semaphore escrita;
	private QInteger contadorLeitor;
	private Socket connectionSocket;
	
	public Leitor(Semaphore sem, Semaphore escrita, QInteger contadorLeitor, QInteger contador, DataOutputStream outToClient, Socket connectionSocket) {
		this.mutex = sem;
		this.contador = contador;
		this.outToClient = outToClient;
		this.escrita = escrita;
		this.contadorLeitor = contadorLeitor;
		this.connectionSocket = connectionSocket;
	}
	@Override
	public void run() {
		
		try {
			mutex.acquire();
			contadorLeitor.increment();
			if(contadorLeitor.get() == 1) escrita.acquire();
			mutex.release();
			
			outToClient.writeBytes(String.valueOf(contador.get()) + "\n");
			
			mutex.acquire();
			contadorLeitor.decrement();
			if(contadorLeitor.get() == 0)escrita.release();
			mutex.release();
			
			connectionSocket.close();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
