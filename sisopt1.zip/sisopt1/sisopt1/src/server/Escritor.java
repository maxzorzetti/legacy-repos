package server;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.Semaphore;

public class Escritor implements Runnable {
	
	private Semaphore escrita;
	private QInteger contador;
	private DataOutputStream outToClient;
	private Socket connectionSocket;
		
	public Escritor(Semaphore escrita, QInteger val, DataOutputStream outToClient, Socket connectionSocket) {
		this.escrita = escrita;
		this.contador = val;
		this.outToClient = outToClient;
		this.connectionSocket = connectionSocket;
	}
	@Override
	public void run() {

		try {
			escrita.acquire();
			contador.increment();
			outToClient.writeBytes(String.valueOf(contador.get()) + "\n");
			escrita.release();
			connectionSocket.close();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
