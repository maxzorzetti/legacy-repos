package client;
import java.util.concurrent.Semaphore;

public class SuperClient {

	public static void main(String args[]) throws InterruptedException{
		int maxConn = Integer.parseInt( args[0] );
		int paralelismo = Integer.parseInt( args[1] );
		int estimacao = 0;
		Semaphore sem = new Semaphore(paralelismo);
		
		System.out.println("STARTO");
		
		for(int i = 0; i < maxConn; i++){
			sem.acquire();
			int op = i%2 + 1;
			Thread thread = new Thread(new Cliente(op, sem));
			thread.start();
			if(op == 2) estimacao++;
		}
		sem.acquire(paralelismo);
		System.out.println(estimacao);
	}
}
