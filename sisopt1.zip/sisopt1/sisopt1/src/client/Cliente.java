package client;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.concurrent.Semaphore;

public class Cliente implements Runnable {
	
	private int comando;
	private Semaphore sem;
	
	public Cliente(int comando, Semaphore sem) {
		this.comando = comando;
		this.sem = sem;
	}

	@Override
	public void run() {		
		try {
			Socket clientSocket = new Socket("127.0.0.1", 6793);
			
	        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());

	        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

	        outToServer.writeBytes(String.valueOf(comando) + '\n');
	        
	        System.out.println("FROM SERVER: " + inFromServer.readLine());
	        
	        clientSocket.close(); 
	        sem.release();
			
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
}
