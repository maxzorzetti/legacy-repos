
import java.util.Scanner;

public class HeapTest {
    
  public static void main( String[] args ) {
      int[] v = { 5, 9, 11, 4, 2, 15 };
    Heap H = new Heap();

    Scanner input = new Scanner( System.in );
    System.out.println("Aula: ");
    while ( input.hasNext() ) {
      String temp = input.next();

      if ( temp.equals( "quit" ) ) System.exit(0);
      if ( temp.equals( "get" ) )  System.out.println( H.get() );
      if ( temp.equals( "altera" ) ) H.altera( Integer.parseInt( input.next() ), Integer.parseInt( input.next() ) );
      if ( temp.matches( "[0-9]+" ) ) H.insert( Integer.parseInt( temp ) );
      if(temp.equals("ordena")) {
        for(int i = 0; i < v.length; i++) System.out.print(v[i] + " ");
        System.out.println();
        for(int i = 0; i < v.length; i++) H.insert(v[i]);
        for(int i = v.length - 1; i >= 0; i--) v[i] = H.get();
        for(int i = 0; i < v.length; i++) System.out.print(v[i] + " ");
        }

      H.print();
    }
  }
}
