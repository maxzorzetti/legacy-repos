from datetime import datetime

# A random number generator.
# Either operates based on a given seed and random-number query limit,
# or on a given array of preset numbers. 
class RNG:

	DEFAULT_MOD = pow(2, 32)

	def __init__(self, seed=None, query_limit=None, preset_numbers=None):
		self.current_queries = 0

		if seed != None:
			self.query_limit = query_limit
			self.numbers = []
			last_seed = seed
			for i in range(0, query_limit):
				new_seed = self.linear_congruent_method(last_seed)
				uniform_number = new_seed/float(RNG.DEFAULT_MOD)
				self.numbers.append(uniform_number)
				last_seed = new_seed

		elif preset_numbers:
			self.numbers = preset_numbers
			self.query_limit = len(preset_numbers)

	# The default linear congruent method, used in generating random numbers.
	# Used when the RNG instance was created in 'seed' mode.
	def linear_congruent_method(self, seed, multiplier=1664525, constant=1013904223, mod=DEFAULT_MOD):
		pseudo_random_number = (seed * multiplier + constant) % mod

		return pseudo_random_number

	def should_gen_number(self):
		return not (self.query_limit != None and self.current_queries >= self.query_limit)

	# Consume a randomly-generated number.
	def next_float(self):
		if not self.should_gen_number():
			return None

		uniform_rng = self.numbers.pop()

		self.current_queries += 1

		return uniform_rng