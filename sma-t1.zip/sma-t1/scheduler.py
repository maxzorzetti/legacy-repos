import heapq
import numpy

# A scheduler.
# Handles the scheduling of arrival and exit events in its queues.
# Also triggers said events when consume_event() is called, effectively
# driving the simulation. 
# All scheduled events use the given RNG. Once it stops spitting out numbers,
# no more events are scheduled and the simulation will soon halt.
class Scheduler:

	ARRIVAL_EVENT = 'arrival'
	EXIT_EVENT = 'exit'

	def __init__(self, rng=None, event_limit=None):
		self.events = []
		self.rng = rng
		self.event_limit = None if event_limit <= 0 else event_limit
		self.events_consumed = 0
		self.most_recent_timestamp = 0
		self.queues = {}

	def add_queue(self, queue):
		self.queues[queue.name] = queue
		queue.scheduler = self

	def add_queues(self, queues):
		for queue in queues:
			self.add_queue(queue)

	def should_consume_event(self):
		return not (self.event_limit != None and self.events_consumed >= self.event_limit) and self.events

	# Consume a randomly-generated number to decide the time delay an event should use
	def calculate_event_delay(self, interval):
		random_float = self.rng.next_float()
		if random_float == None:
			return None

		event_delay = (interval[1] - interval[0]) * random_float + interval[0]

		return event_delay

	# Schedule an arrival event on a queue.
	# Schedule is interrupted if there's no random-number to consume (i.e. RNG has dried up and simulation should end).
	def schedule_arrival(self, current_time, queue_name, arrival_interval):
		event_delay = self.calculate_event_delay(arrival_interval)
		if not event_delay:
			return

		self.schedule_event(queue_name, Scheduler.ARRIVAL_EVENT, event_delay, current_time)

	# Schedule an exit event on a queue.
	# If it's a transition-type of exit, schedule an exit event on the source queue, 
	# and an arrival event on the destination queue. Note that arrival events are discarded on void transitions.
	def schedule_exit(self, queue_name, exit_name, exit_interval, current_time):
		event_delay = self.calculate_event_delay(exit_interval)
		if not event_delay:
			return

		exit_event_delay = numpy.nextafter(event_delay, 1)

		self.schedule_event(queue_name, Scheduler.EXIT_EVENT, event_delay, current_time)
		self.schedule_event(exit_name, Scheduler.ARRIVAL_EVENT, exit_event_delay, current_time)

	# Add an event to the event heap.
	# Ignores events scheduled to 'void' queues (i.e. final exit events).
	def schedule_event(self, queue_name, event_type, event_delay, current_time):
		if not queue_name: # Discard empty/void, final transitions
			return

		event_time = current_time + event_delay
		queue = self.queues[queue_name]
		event = (event_time, queue, event_type)

		heapq.heappush(self.events, event)

		# Uncomment this to see events as they are being scheduled.
		# print('Scheduled event {0}').format(event)

	# Consume the next available event, triggering arrival or exit logic in a queue
	def consume_event(self):
		self.events_consumed += 1

		event = heapq.heappop(self.events)
		(event_timestamp, queue, event_type) = event

		self.most_recent_timestamp = event_timestamp

		if event_type == Scheduler.ARRIVAL_EVENT:
			queue.arrival(event_timestamp)
		elif event_type == Scheduler.EXIT_EVENT:
			queue.exit(event_timestamp)

		# Uncomment this to see events as they are being consumed.
		# print "Consumed event {0}".format(event)

	# Consume one randomly-generated number to figure out which exit an exit event should use
	def resolve_exit_choice(self, exits):
		# If there's only one exit (i.e. one transition with 100% chance), 
		# return it so we don't waste the RNG pool.
		if len(exits) == 1:
			return exits[0]

		# Adjust exit chance values to operate on
		adjusted_exits = []
		previous_exit = None
		for (exit_value, exit_name) in exits:
			adjusted_chance = exit_value + (previous_exit[0] if previous_exit else 0)
			adjusted_exit = (adjusted_chance, exit_name)
			adjusted_exits.append(adjusted_exit)
			previous_exit = adjusted_exit

		criterion = self.rng.next_float()
		# Pick an exit based on above randomly generated number
		for exit in adjusted_exits:
			exit_chance = exit[0]
			if criterion <= exit_chance:
				return exit











