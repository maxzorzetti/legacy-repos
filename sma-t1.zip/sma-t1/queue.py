
# A queue. It resolves all arrival and exit logic, 
# such as triggering the schedule of an exit event 
# if the right conditions are met, by itself. 
# 
# All logic related to the actual scheduling is, in fact, in the Scheduler class.
class Q:

	def __init__(self, params, scheduler=None):
		self.name = params.name
		self.scheduler = scheduler
		self.last_timestamp = 0
		self.states = {}
		self.exit_interval = params.exit_interval
		self.arrival_interval = params.arrival_interval
		self.capacity = params.capacity
		self.workers = params.workers
		self.exits = params.exits
		self.current_size = 0
		self.missed_clients = 0

	# Update the queue's current time reference and update it's time spent on the current state
	def update_time(self, current_time):
		delta_time = current_time - self.last_timestamp
		self.states[self.current_size] = delta_time + (self.states[self.current_size] if self.current_size in self.states else 0)
		self.last_timestamp = current_time

	# Do arrival logic, handling queue size increase/decrease and event scheduling
	def arrival(self, current_time):
		self.update_time(current_time)

		if not self.capacity or self.current_size < self.capacity:
			self.current_size += 1

			if self.current_size <= self.workers:
				self.resolve_exit(current_time)
		else:
			self.missed_clients += 1

		# If it's a 'starter queue', keep triggering arrival events
		if self.arrival_interval:
			self.scheduler.schedule_arrival(current_time, self.name, self.arrival_interval)

	# Do arrival logic, handling queue size increase/decrease and event scheduling
	def exit(self, current_time):
		self.update_time(current_time)

		self.current_size -= 1
		if self.current_size >= self.workers:
			self.resolve_exit(current_time)

	# Figure out which exit to use, and then schedule an exit event on it
	def resolve_exit(self, current_time):
		chosen_exit = self.scheduler.resolve_exit_choice(self.exits)

		exit_name = chosen_exit[1]

		self.scheduler.schedule_exit(self.name, exit_name, self.exit_interval, current_time)

	def get_short_description(self):
		header = '{0}\n'.format(self.__str__())
		capacity_description = 'Capacity:\t{0}/{1}\n'.format(self.current_size, self.capacity if self.capacity else 'inf')
		arrival_description = 'Arrival time:\t{0}\n'.format(self.arrival_interval) if self.arrival_interval else ''
		departure_description = 'Departure time:\t{0}\n'.format(self.exit_interval)
		exits_description = 'Exits:\t\t{0}\n'.format(self.exits)

		return header + capacity_description + arrival_description + departure_description + exits_description

	# Calculate relevant simulator data
	def get_report_data(self):
		if self.last_timestamp == 0:
			return None

		total_time = reduce(lambda x, value: x + value, self.states.values())
		missed_clients = self.missed_clients

		state_chances = {}
		for state in self.states:
			state_time = self.states[state]
			state_chance = state_time/total_time
			state_chances[state] = state_chance

		average_population = 0
		flow_rate = 0
		usage = 0
		for state in self.states:
			if state == 0:
				continue
			average_population += state_chances[state] * state
			flow_rate += state_chances[state] * (self.exit_interval[0] + self.exit_interval[1])/2.0
			usage += (state_chances[state] * min(state, self.workers)/self.workers)
		response_time = average_population/flow_rate

		return (missed_clients, state_chances, average_population, flow_rate, usage, response_time, self.states)

	def get_report(self):
		return description

	def __str__(self):
		return '{0} - G/G/{1}/{2}'.format(self.name, self.workers, self.capacity if self.capacity else 'inf')

	def __repr__(self):
		return self.__str__()

# A struct that holds everything necessary to instantiate a Q.
class QParameters:

	def __init__(self, name, capacity, workers, exits, exit_interval, arrival_interval=None):
		self.name = name
		self.capacity = capacity
		self.workers = workers
		self.exits = sorted(exits)
		self.exit_interval = exit_interval
		self.arrival_interval = arrival_interval

	def get_short_description(self):
		header = 'G/G/{0}/{1}\n'.format(self.workers, self.capacity if self.capacity else 'inf')
		arrival_description = 'Arrival time:\t{0}\n'.format(self.arrival_interval) if self.arrival_interval else ''
		departure_description = 'Departure time:\t{0}\n'.format(self.exit_interval)
		exits_description = 'Exits:\t\t{0}'.format(self.exits)

		return header + arrival_description + departure_description + exits_description
	











