from scheduler import Scheduler
from queue import Q, QParameters
from parser import Parser
from rng import RNG

# Helper functions.
# Skip below to line 63!

def sum_dict(x, y):
	all_states = set(x.keys()).union(set(y.keys()))
	state_chance = {}
	for state in all_states:
		x_value = x[state] if state in x else 0
		y_value = y[state] if state in y else 0
		state_chance[state] = x_value + y_value

	return state_chance

def merge_queue_report_data(data):
	missed_clients = reduce(lambda x, y: x + y, map(lambda x: x[0], data), 0) / len(data)
	average_population = reduce(lambda x, y: x + y, map(lambda x: x[2], data), 0) / len(data)
	flow_rate = reduce(lambda x, y: x + y, map(lambda x: x[3], data), 0) / len(data)
	usage = reduce(lambda x, y: x + y, map(lambda x: x[4], data), 0) / len(data)
	response_time = reduce(lambda x, y: x + y, map(lambda x: x[5], data), 0) / len(data)
	state_chance = reduce(sum_dict, map(lambda x: x[1], data))
	state_time = reduce(sum_dict, map(lambda x: x[6], data))
	for state in state_chance:
		state_chance[state] /= len(data)
	for state in state_time:
		state_time[state] /= len(data)

	return (missed_clients, state_chance, average_population, flow_rate, usage, response_time, state_time)

def queue_report_data_description(queue_report_data):
		if not queue_report_data:
			return 'No data'

		missed_clients = queue_report_data[0]
		state_chance = queue_report_data[1]
		average_population = queue_report_data[2]
		flow_rate = queue_report_data[3]
		usage = queue_report_data[4]
		response_time = queue_report_data[5]
		state_time = queue_report_data[6]

		performance_description = 	'Performance indexes (average)\n'\
									'Missed clients: {0}\n'\
									'Population:\t{1}\n'\
									'Flow rate:\t{2}\n'\
									'Usage:\t\t{3}\n'\
									'Response time:\t{4}'.format(missed_clients, average_population, flow_rate, usage, response_time)

		state_description = 'Queue state information:\n'
		for state in state_time:
			time = state_time[state]
			chance = state_chance[state]
			state_description += '{0} - {1}%\t({2}t)\n'.format(state, chance * 100, time)

		description = '{0}\n{1}\n'.format(performance_description, state_description)

		return description

# Queue simulator program

if __name__ == '__main__':
	# Read configuration file
	parser = Parser('model.json')
	q_params = parser.get_q_params()
	initial_arrivals = parser.get_initial_arrivals()
	executions = parser.get_executions()
	rng_type = parser.get_rng_type()
	if rng_type == 'seeds':
		seeds = parser.get_seeds()
		random_number_limit = parser.get_random_number_limit()
	elif rng_type == 'preset_numbers':
		preset_numbers=parser.get_preset_numbers()

	# Display the given topology
	print '==================\n'\
  		  '  Queue topology  \n'\
		  '==================\n'

	for q_param in q_params:
		print q_param.get_short_description()
		print ''

	# Configure and start the simulation
	print '==================\n'\
 		  ' Simulation start \n'\
		  '==================\n'

	print 'Simulation is using {0}.\n'.format('{0} seeds'.format(len(seeds)) if rng_type == 'seeds' else 'preset random numbers')

	report_data = {}
	for run in range(0, executions):		

		# Create the scheduler, instantiate the queues and add them to it
		scheduler = Scheduler()
		queues = map(lambda q_param: Q(q_param), q_params)
		scheduler.add_queues(queues)

		# Configure the scheduler to use a specific type of RNG
		if rng_type == 'seeds':
			seed_rng = RNG(seed=seeds[run], query_limit=random_number_limit)
			scheduler.rng = seed_rng
		elif rng_type == 'preset_numbers':
			preset_rng = RNG(preset_numbers=preset_numbers)
			scheduler.rng = preset_rng

		# Schedule all the initial arrivals
		for arrival in initial_arrivals:
			queue_name = arrival['queue_name']
			arrival_time = arrival['arrival_time']
			scheduler.schedule_event(queue_name, Scheduler.ARRIVAL_EVENT, arrival_time, 0)

		# Run the simulation while the scheduler still has events to consume.
		# Events will stop being produced once the RNG object dries up, according to configuration parameters.
		while scheduler.events:
			scheduler.consume_event()

		print 'Total time for execution #{0}: {1}t'.format(run + 1, scheduler.most_recent_timestamp)

		# Update idle queues (since our time is not global)
		for queue in scheduler.queues.values():
			queue.update_time(scheduler.most_recent_timestamp)

		# Store simulation results in case of multiple executions
		for queue in scheduler.queues.values():
			queue_report_data = queue.get_report_data() 

			if queue.name in report_data:
				data = report_data[queue.name]
				data.append(queue_report_data)
				report_data[queue.name] = data
			else:
				report_data[queue.name] = [queue_report_data]

	print ''			
	print '==================\n'\
  		  '  Simulation end  \n'\
		  '==================\n'

	print 'Displaying simulation results.\n'

	print 'Average simulation time: {0}\n'.format(scheduler.most_recent_timestamp)

	# Calculate the average of each simulation execution and display it
	for queue_name in report_data:
		queue_report_data = report_data[queue_name]
		average_data = merge_queue_report_data(queue_report_data)

		print scheduler.queues[queue_name]
		print queue_report_data_description(average_data)



