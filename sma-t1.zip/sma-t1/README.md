Authored by Bruno F. Wide and Max Zorzetti

# Program features

- Ability to create any kind of queue topology.
- Two types of RNG - seed-based number generation or preset array of numbers.
- Support for multiple starting events on different queues. 
- Calculation of all performance indexes

# Usage requirements
The program requires usage of Python 2.7 and numpy.
To install numpy, execute the following command:

> pip install numpy

or, if it's already installed:

> pip install -U numpy

# Usage instructions
First, set up your queue network using the "model.json" file.
Next, execute the following command in the terminal:

python t1.py

Now, observe the terminal to see the results.

# Model.json help

### RNG options
Use the "use_rng_type" key to determine if you want to use seed-based RNG or preset numbers.
Setting it to "seeds" will use the options as defined in the "seeds" key, 
while setting it to "preset_numbers" will use the given preset numbers array.

### Simulation options
The "initial_arrivals" determines the starting arrival events that should trigger when the simulation begins.
You can set multiple initial events if you so desire.

### Queues
Here you can describe the topology of the queues.
Below is a commented example of a queue.

    { 
      "name": "Q1",                 // The identifier of the queue. Necessary.
      "workers": 2,                 // The number of workers operating on the queue. Necessary.
      "capacity": 4,                // The maximum number of clients in the queue. 
                                       You can ommit this key to set it to infinite.
      "arrival_interval": [2, 3],   // Used when a queue should keep spawning arrival events. 
                                       You can ommit this so the queue doesn't do so.
      "exit_interval": [4, 7],      // The time interval needed for a client to exit the queue. Necessary.
      "exits": [                    // The queue's exit transitions and their respective chance of occurring.
        {"Q2": 0.7}                 // You can ommit this key to set all exit transitions as final.
      ]                             // In this example, a Q1 client has 70% chance to go to Q2, and 30% chance 
    }                               // to leave the system altogether.

Note: in-code, a transition to None/null/nil is a final transition that leaves the system.
