from queue import QParameters
import json

def normalize_exits(exits):
	total_chance = reduce(lambda o, x: o + x[0], exits, 0)

	missing_chance = 1 - total_chance
	if missing_chance > 0:
		exits.append((missing_chance, None))

	return exits

# A parser for the configuration file.
class Parser:
	
	def __init__(self, model_path):
		self.model_path = model_path

		with open(model_path) as model_file:
			model = json.load(model_file)
			queue_models = model['queues']

			# Parse queue network
			self.q_params = []
			for queue_model in queue_models:
				q_name = queue_model['name']
				workers = queue_model['workers']
				capacity = queue_model['capacity'] if 'capacity' in queue_model else None
				arrival_interval = tuple(queue_model['arrival_interval']) if 'arrival_interval' in queue_model else None
				exit_interval = tuple(queue_model['exit_interval'])
				exits = normalize_exits(map(lambda x: (x[x.keys()[0]], x.keys()[0]) , queue_model['exits']) if 'exits' in queue_model else [(1, None)])
				params = QParameters(name=q_name, exits=exits, capacity=capacity, workers=workers, exit_interval=exit_interval, arrival_interval=arrival_interval)
				self.q_params.append(params)

			# Parse simulation options
			simulation_options = model['simulation_options']
			self.initial_arrivals = simulation_options['initial_arrivals']

			# Parse RNG configuration
			rng_options = model['rng_options']
			self.rng_type = rng_options['use_rng_type']

			if self.rng_type == 'seeds':
				self.seeds = rng_options['seeds']['values']
				self.random_number_limit = rng_options['seeds']['random_number_limit']
				self.executions = len(self.seeds)

			elif self.rng_type == 'preset_numbers':
				self.preset_numbers = rng_options['preset_numbers']
				self.executions = 1

	def get_rng_type(self):
		return self.rng_type

	def get_seeds(self):
		return self.seeds

	def get_random_number_limit(self):
		return self.random_number_limit

	def get_preset_numbers(self):
		return self.preset_numbers

	def get_executions(self):
		return self.executions

	def get_q_params(self):
		return self.q_params
		# return [QParameters(name='C', exits=[(0.7, 'D'), (0.3, None)], capacity=4, workers=2, exit_interval=(4,7), arrival_interval=(2,3)),
				# QParameters(name='D', exits=[(1, None)], capacity=None, workers=1, exit_interval=(4,8))]

	def get_initial_arrivals(self):
		return self.initial_arrivals

