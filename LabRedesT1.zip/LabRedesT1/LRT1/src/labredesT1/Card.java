package labredesT1;

public class Card {
	public enum Suit { Diamonds, Clubs, Spades, Hearts }
	public enum Value { 
		Ace(1), Two(2), Three(3), Four(4), Five(5), Six(6), Seven(7), 
		Eight(8), Nine(9), Ten(10), Jack(10), Queen(10), King(10);
		public int value;
		private Value(int value) { this.value = value; }
	}
	
	private Suit suit;
	private Value value;
	
	public int getValue() {
		return value.value;
	}
	
	public Suit getSuit() {
		return suit;
	}
	
	public Card(Suit suit, Value value) {
		this.suit = suit;
		this.value = value;
	}
	
	public Card(Suit suit, int value) {
		this.suit = suit;
		switch(value) {
		case 1: this.value = Value.Ace; break;
		case 2: this.value = Value.Two; break;
		case 3: this.value = Value.Three; break;
		case 4: this.value = Value.Four; break;
		case 5: this.value = Value.Five; break;
		case 6: this.value = Value.Six; break;
		case 7: this.value = Value.Seven; break;
		case 8: this.value = Value.Eight; break;
		case 9: this.value = Value.Nine; break;
		case 10:this.value = Value.Ten; break;
		case 11:this.value = Value.Jack; break;
		case 12:this.value = Value.Queen; break;
		case 13:this.value = Value.King; break;
		default:this.value = Value.Two; break;
		}
	}
	
	public String toString() {
		String card = value.toString() + " of " + suit.toString();
		return card;
	}
}
