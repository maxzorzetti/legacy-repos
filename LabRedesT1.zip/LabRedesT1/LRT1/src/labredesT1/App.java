package labredesT1;

public class App {
	public static void main(String args[]) {
		BlackjackServer server = new BlackjackServer();		
		
		server.start();
	}
}
