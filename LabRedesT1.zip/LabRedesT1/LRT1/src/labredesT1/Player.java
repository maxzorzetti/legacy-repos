package labredesT1;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Player {
	private List<Card> hand;
	private double money;
	private double currentBet;
	//isKicked controls if the player will participate in the round
	private boolean isKicked;
	//playing controls if the player will participate in the endRound
	private boolean playing;
	
	private PlayerConnection connection;
	
	public Player(Socket socket) {
		this.hand = new ArrayList<Card>();
		this.connection = new PlayerConnection(socket);
		this.playing = false;
		this.isKicked = false;
	}
	
	//Method responsible for asking if the player wants to participate in the betting round
	public boolean askForBet(double minimumBet) {
		//send message with the minimum bet
		connection.sendOutputAndOver(String.format("Minimum bet is $%.0f", minimumBet));
		//if player has funds
		if (money >= minimumBet) {
			//signal the client that the player has funds
			connection.sendOutput("funds avaliable");
			
			//ask if the player wants to participate in the round until he types a valid option
			do {
				//sends bet message
				connection.sendOutputAndOver("Make a bet(INT) or SKIP this round?");
				//receive player's choice
				String userChoice = connection.readInput();
				//checks if the player decided to skip the round
				if (userChoice.equalsIgnoreCase("S") | userChoice.equalsIgnoreCase("SKIP")) {
					//returns that the player will not participate in this round
					return false;
				} else {
					//checks if the player made a bet
					try {						
						int betAmount = Integer.parseInt(userChoice);
						
						boolean isValidBet = minimumBet <= betAmount && betAmount <= getMoney();
						//checks if the bet was valid
						if (isValidBet) {
							//case was, signal the client that the player made a valid bet
							signalTrue();
							//set player's bet
							bet(betAmount);
							//returns that the player made a bet
							return true;
						} else {
							//case wasn't, signal the client that it must keep asking the player for a valid bet
							signalFalse();
							continue;
						}
						
					} catch (NumberFormatException e) {
						continue;
					}
				}
				
			} while (true);
		}
		//case the player has no funds
		//signal the client that the player has no funds
		connection.sendOutput("no funds");
		//sends a message to the client informing the player that he has no funds
		connection.sendOutputAndOver("Unfortunately, you've lost all your cash. Get lost, kiddo.");
		//kicks player from the round. he can no longer participate in the game because he has no money
		kick();
		//returns that the player will not participate in this round
		return false;
	}
	
	//Method responsible for asking if the player wants more cards
	public boolean askToReceiveCard() {
		//ask if the player wants more cards until he types a valid option
		do {
			//sends message to client
			connection.sendOutputAndOver("HIT or STAND?");
			//receives player's choice
			String userChoice = connection.readInput();
			//checks if the player wanted more cards
			if (userChoice.equalsIgnoreCase("H") || userChoice.equalsIgnoreCase("1") || userChoice.equalsIgnoreCase("HIT")) {
				return true;
			//checks if the player didn't want more cards
			} else if (userChoice.equalsIgnoreCase("S") || userChoice.equalsIgnoreCase("2") || userChoice.equalsIgnoreCase("STAND")) {
				return false;
			}
		} while (true);
	}
	
	//Method responsible for "kicking" the player from the game. That is, he cannot participate in the game because he has no money
	public void kick() {
		this.isKicked = true;
		//sends a message informing that he can no longer participate in the game
		connection.sendOutputAndOver("Game over, for you.");
	}
	
	public boolean isKicked() {
		return this.isKicked;
	}
	
	//Method responsible for dealing a card to the player
	public void receiveCard(Card card) {
		//adds card to player's hand
		this.hand.add(card);
		//sends message to client informing the card drawn
		if (card.getValue() == 1 || card.getValue() == 8) connection.sendOutputAndOver("You've been dealt an " + card);
		else connection.sendOutputAndOver("You've been dealt a " + card);
	}
	
	public List<Card> getHand() {
		return hand;
	}

	public double getMoney() {
		return money;
	}

	public double getCurrentBet() {
		return currentBet;
	}
	
	public boolean isPlaying(){
		return playing;
	}
	
	public void setPlaying(boolean status){
		playing = status;
	}
	
	public void clearHand() {
		hand.clear();
	}
	
	public void clearCurrentBet(){
		this.currentBet = 0;
	}
	
	//Method responsible for informing the amount of money received
	public void receiveMoney(double money) {
		this.money += money;
		
		connection.sendOutputAndOver(String.format("You received $%.0f", money));
	}
	
	//Method responsible for informing the amount of money the player currently has
	public void showMoney() {
		connection.sendOutputAndOver(String.format("You currently have $%.0f", money));
	}

	//Method responsible for informing the amount of money lost
	public void loseMoney(double money) {
		this.money -= money;
		connection.sendOutputAndOver(String.format("You lost $%.0f", money));
	}
	
	//Method responsible for making a bet
	public boolean bet(double amount) {
		if (amount <= money) {
			currentBet = amount;
			return true;
		}
		return false;
	}

	//Method responsible for calculating player's hand score
	public int getHandScore() {
		int score = 0;
		for (Card card : hand) {
			score += card.getValue();
		}
		return score;
	}
	
	//Method responsible for comparing the dealer's hand with the player's hand
	//and sending a message with the game's outcome
	public int showResults(List<Card> dealerHand, int dealerScore) {
		//0 is draw | 1 is win | -1 is loss
		int result = 0;
		//prepares message
		StringBuilder results = new StringBuilder();
		//adds player hand
		results.append("Your hand score is " + getHandScore() + ": \r\n");
		for (Card card: hand) results.append("\t" + card + "\r\n");
		//adds dealer hand
		results.append("Dealer's hand score is " + dealerScore  +": \r\n");
		for (Card card: dealerHand) results.append("\t" + card + "\r\n");
		
		String winMessage = "Congratulations! You won!";
		String lossMessage = "You lost! Better luck next time!";
		String drawMessage = "Draw!";
		
		//checks win conditions to determine the message to be added
		if (getHandScore() == dealerScore || (getHandScore() > 21 && dealerScore > 21)){ 
			result = 0;
			results.append(drawMessage);
		}
		else if (dealerScore > 21){
			result = 1;
			results.append(winMessage);
		}
		else if (getHandScore() > 21){
			result = -1;
			results.append(lossMessage);
		}
		else if (getHandScore() <= 21){
			if(getHandScore() > dealerScore){
				result = 1;
				results.append(winMessage);
			}
			else{
				result = -1;
				results.append(lossMessage);
			}
		}
		//sends message with the results to the client
		connection.sendOutputAndOver(results.toString());
		//returns 0, 1 or -1 depending on the game's outcome
		return result;
	}
	
	//Method responsible for sending a message with the dealer's initial. The 1st card "facing down" and 2nd card "facing up"
	public void showDealersInitialHand(List<Card> dealerHand){
		StringBuilder sb = new StringBuilder();
		sb.append("Dealer's hand:\n");
		sb.append("\tHidden card\n");
		sb.append("\t" + dealerHand.get(1));
		//sends message to the client
		connection.sendOutputAndOver(sb.toString());
	}
	
	//Method responsible for sending a TRUE signal to the client.
	//This method is used for flux control purposes
	public void signalTrue(){
		connection.sendOutput("true");
	}
	
	//Method responsible for sending a FALSE signal to the client.
	//This method is used for flux control purposes
	public void signalFalse(){
		connection.sendOutput("false");
	}
	
	public String toString() {
		String string = "Money: " + money + "\n" + "Current bet: " + currentBet + "\n" + "Hand: \n";
		for (Card card: hand) {
			string += "\t" + card + "\n";
		}
		return string;
	}

	//Method responsible for sending a message to the client with the remaining time before the game starts
	public void showGameStartTime(int lobbyTimeLeft) {
		connection.sendOutputAndOver("Game starting in " + lobbyTimeLeft + " seconds...");
	}

	//Method responsible for sending a message to the client saying that the game has ended
	public void signalGameHasEnded() {
		connection.sendOutputAndOver("Game has ended. Please come again!");
	}

}
