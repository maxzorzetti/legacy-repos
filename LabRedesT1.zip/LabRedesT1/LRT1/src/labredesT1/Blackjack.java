package labredesT1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ScheduledExecutorService;

public class Blackjack {
	private final int MAX_PLAYERS = 3;
	private final long LOBBY_TIME = 10;
	private final double STARTING_MONEY = 500.0;
	private final double MINIMUM_BET = 30.0;

	public enum State { NEW, INLOBBY, INGAME, ENDED }
	private State state;

	private Date lobbyStartTime;
	private Date lobbyEndTime;
	
	private Collection<Player> players;
	private List<Card> dealerHand;
	private Deck deck;
	
	public Blackjack() {
		players = new ArrayList<Player>();
		deck = new Deck();
		dealerHand = new ArrayList<Card>();
		state = State.NEW;
	}
	
	//Method responsible for starting a blackjack instance. 
	//Players can be added to the instance after this method is called.
	public void initialize() {
		startLobby();
	}
	
	//Method responsible for starting the game phases
	//is called when lobby timer is up
	private void startGame() {
		this.state = State.INGAME;
		//each player receives their starting money
		for (Player player: players) player.receiveMoney(STARTING_MONEY);
		while (isRoundPlayable()) {
			deck = new Deck();
			deck.shuffle();
			bettingRound();
			dealerRound();
			endRound();
		}
		endGame();
	}
	
	//Method responsible for adding player to this instance of blackjack.
	public void addPlayer(Player player) {
		//if adding the first player, start countdown to the start game
		if (players.size() == 0) startLobbyCloseTimer();

		//check if instance is in lobby and there are slots available
		if (state == State.INLOBBY && getAvailableSlots() > 0) {
			players.add(player);
			//send message to client informing the remaining time before starting the game
			player.showGameStartTime(getLobbyTimeLeft());
		}
	}
	
	//Method responsible for starting the countdown to start the game
	private void startLobbyCloseTimer() {
		 ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
		 lobbyStartTime = new Date();
		 lobbyEndTime = new Date(lobbyStartTime.getTime() + LOBBY_TIME*1000);
		 //after LOBBY_TIME, start the game
		 scheduler.schedule(() -> { startGame(); }, LOBBY_TIME, TimeUnit.SECONDS);
	}
	
	public int getAvailableSlots() {
		int availableSlots = MAX_PLAYERS - players.size();
		return availableSlots;
	}
	
	//returns seconds remaining in the game start countdown
	private int getLobbyTimeLeft() {
		return (int) Math.ceil((lobbyEndTime.getTime() - new Date().getTime())/1000d);
	}

	
	private void startLobby() {
		this.state = State.INLOBBY;
	}
	
	//sends message to the players informing that the game has ended
	private void endGame() {
		for (Player player: players) {
			player.signalGameHasEnded();
		}
		this.state = State.ENDED;
	}
	
	//Method responsible for checking if any of the players in the instance still have money to keep playing
	private boolean isRoundPlayable() {
		boolean playable = false;
		for (Player player: players) {
			if (player.getMoney() > MINIMUM_BET) playable = true;
		}
		
		//sends a message to the clients still playing if the round is playable
		for (Player player: players) {
			//if client is still playing
			if (!player.isKicked()) {
				//send message
				if (playable) player.signalTrue();
				else player.signalFalse();
			}
		}	
		return playable;
	}

	//represents the card drawing and betting phase of the game
	private void bettingRound() {
		//dealer draws initial 2 cards
		dealerHand.add(deck.draw());
		dealerHand.add(deck.draw());
		
		for (Player player: players) {
			//receives his current money
			player.showMoney();
			//is asked if wants to participate in the round
			boolean isEnteringGame = player.askForBet(MINIMUM_BET);
			
			//set playing attribute of the player. if true, the player will participate in the endRound
			player.setPlaying(isEnteringGame);
			
			//if player payed the minimun bet
			if (isEnteringGame) {
				//receives his 2 initial cards
				player.receiveCard(deck.draw());
				player.receiveCard(deck.draw());
				//dealer's hand is shown to the player (only the face up card)
				player.showDealersInitialHand(dealerHand);

				boolean wantsHit;
				//do while players wants more cards and has not scored 21 or over
				do {
					//is asked if wants more cards
					wantsHit = player.askToReceiveCard();
					//if wants, receives a card
					if (wantsHit) player.receiveCard(deck.draw());
					
					//checks if the player scored 21 or over, and signals him
					if (player.getHandScore() >= 21) player.signalTrue();
					else player.signalFalse();
				} while (player.getHandScore() < 21 && wantsHit);
			}
		}
	}
	
	//method responsible for drawing cards for the dealer if his hand score is inferior to 17
	private void dealerRound() {
		while (getDealerHandScore() < 17) {
			dealerHand.add(deck.draw());
		}
	}
	
	//method responsible for determining the outcome of the round
	private void endRound() {
		for (Player player: players) {
			//if player is participating in the round
			if(player.isPlaying()){
				int dealerScore = getDealerHandScore();
				//ShowResults is responsible for displaying the player's hand and informing the match outcome
				int matchResult = player.showResults(dealerHand, dealerScore);
				if (matchResult == 1) player.receiveMoney(player.getCurrentBet());
				if (matchResult == 0) player.receiveMoney(0);
				if (matchResult == -1) player.loseMoney(player.getCurrentBet());
			}
			//readying player for next round
			player.clearHand();
			player.clearCurrentBet();
		}
		//readying dealer for next round
		dealerHand.clear();
	}

	//Method responsible for calculating the dealer's hand score
	private int getDealerHandScore() {
		int handScore = 0;
		for (Card card: dealerHand) {
			handScore += card.getValue();
		}
		return handScore;
	}

	public State getGameStatus() {
		return this.state;
	}
	
}
