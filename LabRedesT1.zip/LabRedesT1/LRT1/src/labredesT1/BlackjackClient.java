package labredesT1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class BlackjackClient {
	public static void main(String args[]){
		String ip = "localhost";
		int port = 1200;
		
		if (args.length >= 1) {
			try { port = Integer.parseInt(args[0]);} 
			catch (NumberFormatException e) { System.out.println("Invalid port number. Using default port 1200."); }
		}
		if (args.length >= 2) ip = (args[1]);
		
		System.out.println("Connecting to " + ip + " on port " + port);
		
		String keyword;
		Scanner in = new Scanner(System.in);
		try (
				Socket server = new Socket(ip, port);
				PrintWriter output = new PrintWriter(server.getOutputStream(), true);
				BufferedReader input = new BufferedReader(new InputStreamReader(server.getInputStream()));
			) {
			
			//Keyword used to identify "end of message" 
			keyword = input.readLine();
			String inputFromServer, outputToServer;
			
			/******CLIENT FLUX OF EVENTS******/
			//Receive game start timer
			System.out.println(receiveMessage(input, keyword));
			
			//Receiving money
			System.out.print(receiveMessage(input, keyword));
			boolean canPlay = true;
			
			do {
				//Receive if round is playable
				inputFromServer = input.readLine();
				if (inputFromServer.equals("false")) break;
				
				//Round start
				System.out.println("\r\nRound start");
				
				//Receiving current money
				System.out.print(receiveMessage(input, keyword));
				
				//Receiving minimum bet value
				System.out.print(receiveMessage(input, keyword));
				
				//Checking for funds
				boolean funds = false;
				inputFromServer = input.readLine();
				if (inputFromServer.equals("funds avaliable")) funds = true;
				
				//No funds message (case the user has no funds)
				if (!funds) {
					System.out.print(receiveMessage(input, keyword));
					canPlay = false;
					break;
				}
				
				boolean playing = false;
				do{
					//Being asked if wants to play		
					System.out.print(receiveMessage(input, keyword));
					
					//Response
					System.out.print(">");
					outputToServer = in.nextLine();
					output.println(outputToServer);
					
					//Check if user is playing
					if (outputToServer.equalsIgnoreCase("S") ||	outputToServer.equalsIgnoreCase("SKIP")){
						playing =  false;
						break;
					} else {
						inputFromServer = input.readLine();
						if (inputFromServer.equals("true")) {
							playing = true;
							break;
						}
					}
					
				} while(true);
				
				if (playing) {
					
					//Receiving 1st card
					System.out.print(receiveMessage(input, keyword));
					
					//Receiving 2nd card
					System.out.print(receiveMessage(input, keyword));
					
					//Receiving dealer's initial hand
					System.out.print(receiveMessage(input, keyword));
					
					//Being asked if wants more cards
					boolean wantsHit = false;
					
					do {
						do {
							//Receiving Hit or Stand message
							System.out.print(receiveMessage(input, keyword));
							
							//Response
							System.out.print(">");
							outputToServer = in.nextLine();
							output.println(outputToServer);
							
							if (outputToServer.equalsIgnoreCase("H") || outputToServer.equalsIgnoreCase("1") || outputToServer.equalsIgnoreCase("HIT")){
								wantsHit =  true;
								break;
							}
							if (outputToServer.equalsIgnoreCase("S") || outputToServer.equalsIgnoreCase("2") || outputToServer.equalsIgnoreCase("STAND")) {
								wantsHit = false;
								break;
							}
						
						} while(true);
						
						//If wants more cards, receive
						if(wantsHit){
							System.out.print(receiveMessage(input, keyword));
						}
						
						//case scores 21 or over 21
						boolean gameEnd = false;
						inputFromServer = input.readLine();
						if (inputFromServer.equals("true")) gameEnd = true;
						if(gameEnd) break;
						
					} while (wantsHit);

					//Receive match result;
					System.out.print(receiveMessage(input, keyword));
					
					//Receive or lose money
					System.out.print(receiveMessage(input, keyword));
					
				}
			} while (canPlay);
			
			//Receive end game message
			System.out.println(receiveMessage(input, keyword));
						
			in.close();
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
			System.out.println("Something went wrong. Is the server online?");
			System.out.println("Exiting.");
		} catch (IOException e) {
			System.out.println("Something went wrong. Is your internet connection still up?");
			System.out.println("Exiting.");
		}
	}
	
	//If server used "sendMessageAndOver()", use this method. Otherwise, use input.readLine();
	private static String receiveMessage(BufferedReader input, String KEYWORD) throws IOException {
		StringBuilder stringBuilder = new StringBuilder();
		String inputFromServer;
		while ((inputFromServer = input.readLine()) != null) {
			if (inputFromServer.equals(KEYWORD)) break;
			stringBuilder.append(inputFromServer);
			stringBuilder.append("\n");
		}
		return stringBuilder.toString();
	}
}
