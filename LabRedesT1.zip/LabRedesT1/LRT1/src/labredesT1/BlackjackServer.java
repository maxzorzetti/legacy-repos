package labredesT1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class BlackjackServer {
	
	private ServerSocket server;
	private int port = 1200;
	private boolean running;
	
	private List<BlackjackThread> blackjackInstances;
	
	public BlackjackServer() {
		this.blackjackInstances = new ArrayList<BlackjackThread>();
		this.running = false;
	}
	
	public BlackjackServer(int port) {
		this.blackjackInstances = new ArrayList<BlackjackThread>();
		this.running = false;
		this.port = port;
	}
	
	public static void main(String[] args) {
		BlackjackServer server = null;
		//tries to start the server with the port passed by args
		if (args.length >= 1) {
			try {
				int port = Integer.parseInt(args[0]);
				server = new BlackjackServer(port);				
			} catch (NumberFormatException e) {
				System.out.println("Invalid port number. Starting server on default port 1200.");
			}
		}
		if (server == null) server = new BlackjackServer();		
		server.start();
	}
	
	public void start() {
		try { 
			System.out.println("Starting server on port " + port + "...");
			server = new ServerSocket(port);
			this.running = true;
			
			while (running) {
				System.out.println("Waiting for clients...");
				Socket client = server.accept();
				System.out.println("Client connected.");
				
				System.out.println(blackjackInstances);
				cleanInstances();
				
				//get a running instance of blackjack or create a new one if none is running
				BlackjackThread instance = getAvailableInstance();
				//creates a player with the socket so that the messages can be administered by PlayerConnection
				Player player = new Player(client);
				System.out.println("Assigning client to instance " + instance.getName());
				instance.getBlackjack().addPlayer(player);
			}
			
			server.close();
			
		} catch (IOException e) {
			System.out.println("Server error.");
			e.printStackTrace();
		}
		
	}
	
	//identifies ended instances and removes them
	private void cleanInstances() {
		ArrayList<BlackjackThread> deadInstances = new ArrayList<BlackjackThread>();

		for (BlackjackThread thread: blackjackInstances) {
			if (thread.getBlackjack().getGameStatus() == Blackjack.State.ENDED) {
				try { thread.join(); } 
				catch (InterruptedException e) { e.printStackTrace(); }
				deadInstances.add(thread);
			}
		}
		
		blackjackInstances.removeAll(deadInstances);
	}

	public void stop() {
		this.running = false;
	}
	
	//method responsible for returning a running available instance of blackjack or creating a new one if none is running
	private BlackjackThread getAvailableInstance() {
		BlackjackThread availableInstance = null;
		
		for (BlackjackThread instance: blackjackInstances) {
			 if (instance.getBlackjack().getAvailableSlots() > 0 && instance.getBlackjack().getGameStatus() != Blackjack.State.INGAME) {
				 availableInstance = instance;
				 break;
			 }
		}
		
		if (availableInstance == null) {
			availableInstance = new BlackjackThread("" + this.blackjackInstances.size());
			availableInstance.start();
			blackjackInstances.add(availableInstance);
		}
		
		return availableInstance;
	}
	
}
