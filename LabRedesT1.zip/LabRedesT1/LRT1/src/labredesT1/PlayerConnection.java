package labredesT1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class PlayerConnection {
	private PrintWriter output;
	private BufferedReader input;
	private final String KEYWORD = "@";

	public PlayerConnection(Socket socket) {
		try {
			output = new PrintWriter(socket.getOutputStream(), true);
			input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			//sending keyword to client
			sendKeyword();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//Method responsible for reading messages sent by the client
	public String readInput() {
		String info = null;
		try {
			info = input.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return info;
	}
	
	//Method used for sending a single line of information to the client.
	//The messages sent by this methos must be read with input.readLine()
	public void sendOutput(String info) {
		output.println(info);
	}
	
	//Method used for sending messages to the client.
	//The messages sent by this method must be read at the client with the receiveMessage method
	public void sendOutputAndOver(String info) {
		output.println(info);
		over();
	}
	
	//This method is used to signal the reader the end of a message
	public void over() {
		output.println(KEYWORD);
	}
	
	//This method is used to send the keyword being used to signal end of messages to the client
	private void sendKeyword(){
		over();
	}
}
