package labredesT1;

public class BlackjackThread extends Thread {
	
	private Blackjack game;
	
	public BlackjackThread(String name) {
		this.game = new Blackjack();
		this.setName(name);
	}
	
	public Blackjack getBlackjack() {
		return game;
	}
	
	@Override
	public void run() {
		game.initialize();
		System.out.println("Instance " + this.getName() + " is now running.");
	}

}
