package labredesT1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import labredesT1.Card.Suit;
import labredesT1.Card.Value;

public class Deck {
	private List<Card> cards;
	
	public Deck() {
		this.cards = new ArrayList<Card>(52);
		for (int value = 1; value < 14; value++) {
			this.cards.add(new Card(Suit.Diamonds, value));
			this.cards.add(new Card(Suit.Hearts, value));
			this.cards.add(new Card(Suit.Spades, value));
			this.cards.add(new Card(Suit.Clubs, value));
		}
	}
	
	public void shuffle() {
		Collections.shuffle(cards);
	}
	
	public Card draw() {
		if(cards.size() > 0) return cards.remove(0);
		return null;
	}
}
