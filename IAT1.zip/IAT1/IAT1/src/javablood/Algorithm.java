package javablood;

public interface Algorithm {
	public Point[] getPath(Point start, Point end, Environment environment);
}
