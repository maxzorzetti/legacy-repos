
public class Domino {
	public int front;
	public int back;
	
	public Domino(int a, int b){
		this.front = a;
		this.back = b;
	}
	
	public String toString(){
		return back + "|" + front;
	}
}
