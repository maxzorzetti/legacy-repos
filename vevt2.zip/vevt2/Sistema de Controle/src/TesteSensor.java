import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TesteSensor {
	
	private Sensor sensor;

	@Before
	public void setUp() throws Exception {
		this.sensor = new Sensor(1, new ControladorMock());
		
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void test1() {
		assertEquals(false, sensor.resetH()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test2() {
		assertEquals(false, sensor.getH()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test3() {
		assertEquals(false, sensor.resetAlerta()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test4() {
		assertEquals(false, sensor.getAlerta()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test5() {
		assertEquals(false, sensor.setAlerta()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test6() {
		sensor.setR(1);
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test7() {
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.getH()); 
		assertEquals(true, sensor.resetH());
	}
	@Test
	public void test8() {
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.getH()); 
		assertEquals(true, sensor.getH());
	}
	@Test
	public void test9() {
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.setH()); 
		assertEquals(true, sensor.resetH());
	}
	@Test
	public void test10() {
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.setH()); 
		assertEquals(true, sensor.getH());
	}

	@Test
	public void test11() {
		//Test Sequence 11 :	[setH(), resetH(), resetH()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.resetH());
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test12() {
		//Test Sequence 12 :	[setH(), resetAlerta(), resetH()]
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.resetAlerta());
		assertEquals(true, sensor.resetH());
	}
	@Test
	public void test13() {
		//Test Sequence 13 :	[setH(), resetAlerta(), getH()]
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.resetAlerta());
		assertEquals(true, sensor.getH());
	}
	@Test
	public void test14() {
		//Test Sequence 14 :	[setH(), getAlerta(), resetH()]
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.getAlerta());
		assertEquals(true, sensor.resetH());
	}
	@Test
	public void test15() {
		//Test Sequence 15 :	[setH(), getAlerta(), getH()] 
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.getAlerta());
		assertEquals(true, sensor.getH());
	}
	@Test
	public void test16() {
		//Test Sequence 16 :	[setH(), setR(1), resetH()]
		assertEquals(true, sensor.setH());
		sensor.setR(1);
		assertEquals(true, sensor.resetH());
	}
	@Test
	public void test17() {
		//Test Sequence 17 :	[setH(), setR(1), getH()] 
		assertEquals(true, sensor.setH());
		sensor.setR(1);
		assertEquals(true, sensor.getH());
	}
	@Test
	public void test18() {
		//Test Sequence 18 :	[setH(), setAlerta(), resetAlerta(), resetH()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.setAlerta());
		assertEquals(true, sensor.resetAlerta());
		assertEquals(true, sensor.resetH());
	}
	@Test
	public void test19() {
		//Test Sequence 19 :	[setH(), setAlerta(), resetAlerta(), getH()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.setAlerta());
		assertEquals(true, sensor.resetAlerta());
		assertEquals(true, sensor.getH());
	}
	@Test
	public void test20() {
		//Test Sequence 20 :	[setH(), setAlerta(), getAlerta(), resetH()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.setAlerta());
		assertEquals(true, sensor.getAlerta());
		assertEquals(true, sensor.resetH());
	}
	@Test
	public void test21() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.getAlerta();
		boolean d = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(true, c);
		assertEquals(false, d);
	}
	@Test
	public void test22() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setH();
		boolean d = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(true, d);
	}
	@Test
	public void test23() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setH();
		boolean d = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(false, d);
	}
	@Test
	public void test24() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setH();
		boolean d = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(true, d);
	}
	@Test
	public void test25() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.getH();
		boolean d = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(false, d);
	}
	@Test
	public void test26() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.resetH();
		boolean d = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(true, c);
		assertEquals(false, d);
	}
	@Test
	public void test27() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setAlerta();
		boolean d = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(true, d);
	}
	@Test
	public void test28() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setAlerta();
		boolean d = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(false, d);
	}
	@Test
	public void test29() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		sensor.setR(1);
		boolean c = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(true, c);
	}
	@Test
	public void test30() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		sensor.setR(1);
		boolean c = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
	}
}
