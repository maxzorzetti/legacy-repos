import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ControladorTesteComplementar {
	private Controlador controlador;
	
	@Before
	public void setUp() throws Exception{
		controlador = new Controlador();
	}
	
	@After
	public void tearDown() throws Exception{
		
	}
	/*Teste de argumentos para setH(int n)*/
	@Test
	public void testeComplementar1() {
		try{ controlador.setH(1); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar2() {
		try{ controlador.setH(2); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar3() {
		try{ controlador.setH(0); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar4() {
		try{ controlador.setH(3); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	/*Teste de argumentos para resetH(int n)*/
	@Test
	public void testeComplementar5() {
		try{ controlador.resetH(1); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar6() {
		try{ controlador.resetH(2); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar7() {
		try{ controlador.resetH(0); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar8() {
		try{ controlador.resetH(3); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	/*Teste de argumentos para alerta(int n)*/
	@Test
	public void testeComplementar9() {
		try{ controlador.alerta(1); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar10() {
		try{ controlador.alerta(2); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar11() {
		try{ controlador.alerta(0); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar12() {
		try{ controlador.alerta(3); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	/*Teste de argumentos para resetAlerta(int n)*/
	@Test
	public void testeComplementar13() {
		try{ controlador.resetAlerta(1); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar14() {
		try{ controlador.resetAlerta(2); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar15() {
		try{ controlador.resetAlerta(0); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar16() {
		try{ controlador.resetAlerta(3); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	/*Teste de argumentos para open(int n)*/
	@Test
	public void testeComplementar17() {
		try{ controlador.open(1); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar18() {
		try{ controlador.open(2); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar19() {
		try{ controlador.open(0); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar20() {
		try{ controlador.open(3); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	/*Teste de argumentos para close(int n)*/
	@Test
	public void testeComplementar21() {
		try{ controlador.close(1); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar22() {
		try{ controlador.close(2); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar23() {
		try{ controlador.close(0); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar24() {
		try{ controlador.close(3); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	/*Teste de argumentos para getV(int n)*/
	@Test
	public void testeComplementar25() {
		try{ controlador.getV(1); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar26() {
		try{ controlador.getV(2); }
		catch(IllegalArgumentException e){ fail(); }
	}
	@Test
	public void testeComplementar27() {
		try{ controlador.getV(0); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar28() {
		try{ controlador.getV(3); }
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
}
