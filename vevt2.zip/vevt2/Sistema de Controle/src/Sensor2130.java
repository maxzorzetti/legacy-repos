import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Sensor2130 {
	
	private Sensor sensor;

	@Before
	public void setUp() throws Exception {
		this.sensor = new Sensor(1, new ControladorMock());
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test21() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.getAlerta();
		boolean d = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(true, c);
		assertEquals(false, d);
	}
	@Test
	public void test22() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setH();
		boolean d = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(true, d);
	}
	@Test
	public void test23() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setH();
		boolean d = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(false, d);
	}
	@Test
	public void test24() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setH();
		boolean d = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(true, d);
	}
	@Test
	public void test25() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.getH();
		boolean d = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(false, d);
	}
	@Test
	public void test26() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.resetH();
		boolean d = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(true, c);
		assertEquals(false, d);
	}
	@Test
	public void test27() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setAlerta();
		boolean d = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(true, d);
	}
	@Test
	public void test28() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		boolean c = sensor.setAlerta();
		boolean d = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
		assertEquals(false, d);
	}
	@Test
	public void test29() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		sensor.setR(1);
		boolean c = sensor.resetH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(true, c);
	}
	@Test
	public void test30() {
		boolean a = sensor.setH();
		boolean b = sensor.setAlerta();
		sensor.setR(1);
		boolean c = sensor.getH();
		
		assertEquals(true, a);
		assertEquals(true, b);
		assertEquals(false, c);
	}

	
}
