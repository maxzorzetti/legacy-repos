
public class ControladorMock extends Controlador{
	public ControladorMock() {
	}
}
