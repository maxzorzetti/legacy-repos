import junit.framework.TestCase;

public class TestSequence11a20 extends TestCase{

	Sensor sensor = new Sensor(1, null);
	
	public void setUp() {
		sensor = new Sensor(1, null);
	}
	
	public void testSequence11() {
		//Test Sequence 11 :	[setH(), resetH(), resetH()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.resetH());
		assertEquals(false, sensor.resetH());
	}

	public void testSequence12() {
		//Test Sequence 12 :	[setH(), resetAlerta(), resetH()]
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.resetAlerta());
		assertEquals(true, sensor.resetH());
	}

	public void testSequence13() {
		//Test Sequence 13 :	[setH(), resetAlerta(), getH()]
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.resetAlerta());
		assertEquals(true, sensor.getH());
	}

	public void testSequence14() {
		//Test Sequence 14 :	[setH(), getAlerta(), resetH()]
		assertEquals(true, sensor.setH());
		//assertEquals(false, sensor.getAlerta()); //BUG
		assertEquals(true, sensor.resetH());
	}

	public void testSequence15() {
		//Test Sequence 15 :	[setH(), getAlerta(), getH()] 
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.getAlerta()); //bug
		assertEquals(true, sensor.getH());
	}

	public void testSequence16() {
		//Test Sequence 16 :	[setH(), setR(1), resetH()]
		assertEquals(true, sensor.setH());
		sensor.setR(1);
		assertEquals(true, sensor.resetH());
	}

	public void testSequence17() {
		//Test Sequence 17 :	[setH(), setR(1), getH()] 
		assertEquals(true, sensor.setH());
		sensor.setR(1);
		assertEquals(true, sensor.getH());
	}

	public void testSequence18() {
		//Test Sequence 18 :	[setH(), setAlerta(), resetAlerta(), resetH()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.setAlerta());
		assertEquals(true, sensor.resetAlerta());
		assertEquals(true, sensor.resetH());
	}

	public void testSequence19() {
		//Test Sequence 19 :	[setH(), setAlerta(), resetAlerta(), getH()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.setAlerta());
		assertEquals(true, sensor.resetAlerta());
		assertEquals(true, sensor.getH());
	}

	public void testSequence20() {
		//Test Sequence 20 :	[setH(), setAlerta(), getAlerta(), resetH()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.setAlerta());
		assertEquals(true, sensor.getAlerta());
		assertEquals(true, sensor.resetH());
	}
	
	public void testSequenceE1() {
		//Test Sequence E1 :  [setH(), setAlerta(), getH(), getAlerta()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.setAlerta());
		assertEquals(false, sensor.getH());
		assertEquals(true, sensor.getAlerta());
		
	}
	
	public void testSequenceE2() {
		//Test Sequence E2 :  [setH(), getH(), setR(1), setAlerta()]
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.getH());
		sensor.setR(1);
		assertEquals(true, sensor.setAlerta());
	}
	
	public void testSequenceE3() {
		//Test Sequence E3 :  [getH(), setH(), setAlerta(), setH()]
		assertEquals(false, sensor.getH());
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.setAlerta());
		assertEquals(false, sensor.setH());
	}
	
	public void testSequenceE4() {
		//Test Sequence E4 :  [getH(), setAlerta(), setH(), getH()]
		assertEquals(false, sensor.getH());
		assertEquals(false, sensor.setAlerta());
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.getH());
	}
}
