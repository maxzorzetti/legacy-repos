
public class Controlador {
	Sensor temperatura, pressao;
	Boolean valvulaTemp, valvulaPressao;
	
	public Controlador(){
		temperatura = new Sensor(1, this);
		pressao = new Sensor(2, this);
		valvulaTemp = false;
		valvulaPressao = false;
	}
	
	public boolean setH(int n){
		if(n != 1 && n != 2) throw new IllegalArgumentException("Sensor inv�lido.");
		boolean resp = false;
		if(n == 1)
			resp = temperatura.setH();
		else if(n == 2)
			resp = pressao.setH();
		return resp;	
	}
	
	public boolean resetH(int n){
		if(n != 1 && n != 2) throw new IllegalArgumentException("Sensor inv�lido.");
		boolean resp = false;
		if(n == 1)
			resp = temperatura.resetH();
		else if(n == 2)
			resp = pressao.resetH();
		return resp;
	}
	
	public void alerta(int n){
		if(n != 1 && n != 2) throw new IllegalArgumentException("Sensor inv�lido.");
		open(n);
	}
	
	public void resetAlerta(int n){
		if(n != 1 && n != 2) throw new IllegalArgumentException("Sensor inv�lido.");
		if(n == 1 && valvulaTemp == true) close(1);
		else if(n == 2 && valvulaPressao == true) close(2);
	}
	
	public void open(int n){
		if(n != 1 && n != 2) throw new IllegalArgumentException("V�lvula inv�lida.");
		if(n == 1) valvulaTemp = true;
		else if(n == 2) valvulaPressao = true;
	}
	
	public void close(int n){
		if(n != 1 && n != 2) throw new IllegalArgumentException("V�lvula inv�lida.");
		
		if(n == 1) valvulaTemp = false;
		else if(n == 2) valvulaPressao = false;
	}
	
	public boolean getV(int n){	
		if(n == 1) return valvulaTemp;
		else if(n == 2) return valvulaPressao;

		throw new IllegalArgumentException("V�lvula inv�lida.");
	}
}

