import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestSensor0110 {
	
	private Sensor sensor;

	@Before
	public void setUp() throws Exception {
		this.sensor = new Sensor(1, new ControladorMock());
		
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void test1() {
		assertEquals(false, sensor.resetH()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test2() {
		assertEquals(false, sensor.getH()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test3() {
		assertEquals(false, sensor.resetAlerta()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test4() {
		assertEquals(false, sensor.getAlerta()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test5() {
		assertEquals(false, sensor.setAlerta()); 
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test6() {
		sensor.setR(1);
		assertEquals(false, sensor.resetH());
	}
	@Test
	public void test7() {
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.getH()); 
		assertEquals(true, sensor.resetH());
	}
	@Test
	public void test8() {
		assertEquals(true, sensor.setH());
		assertEquals(true, sensor.getH()); 
		assertEquals(true, sensor.getH());
	}
	@Test
	public void test9() {
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.setH()); 
		assertEquals(true, sensor.resetH());
	}
	@Test
	public void test10() {
		assertEquals(true, sensor.setH());
		assertEquals(false, sensor.setH()); 
		assertEquals(true, sensor.getH());
	}

}
