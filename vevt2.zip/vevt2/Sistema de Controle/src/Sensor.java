
public class Sensor {
	
	enum Estado { DESABILITADO, HABILITADO, ALERTA }
	
	private Estado estado;
	private double confiabilidade;
	private int tipo;
	Controlador controlador;
	
	public Sensor(int tipo, Controlador controlador){
		if(tipo != 1 && tipo != 2) throw new IllegalArgumentException("Tipo de sensor inexistente.");
		this.estado = Estado.DESABILITADO;
		this.confiabilidade = 1;
		this.tipo = tipo;
		this.controlador = controlador;
	}
	
	public boolean setH(){
		if(estado == Estado.HABILITADO || estado == Estado.ALERTA)
			return false;
		else{
			estado = Estado.HABILITADO;
			return true;
		}
	}

	public boolean resetH(){
		if(estado == Estado.DESABILITADO)
			return false;
		else{
			estado = Estado.DESABILITADO;
			return true;
		}
	}

	public void setR(double r){
		if(0 <= r && r <=1){
			confiabilidade = r;
		}
	}

	public boolean getH(){
		return estado == Estado.HABILITADO;
	}
	
	public boolean setAlerta(){
		double x = Math.random();
		boolean funcionamentoCorreto = false;
		if(x <= confiabilidade) funcionamentoCorreto = true;
		
		if(funcionamentoCorreto){
			if(estado == Estado.HABILITADO){
				estado = Estado.ALERTA;
				controlador.alerta(tipo);
				return true;
			}
			return false;
		} 
		//Funcionamento Erroneo
		else{
			if(estado == Estado.HABILITADO) return false;
			
			estado = Estado.ALERTA;
			controlador.alerta(tipo);
			return true;
		}
	}
	
	public boolean resetAlerta(){
		if(estado == Estado.ALERTA){
			estado = Estado.HABILITADO;
			controlador.alerta(tipo);
			return true;
		}
		return false;
	}
	
	public boolean getAlerta(){
		return estado == Estado.ALERTA;
	}
	
	public double getR(){
		return confiabilidade;
	}
}

