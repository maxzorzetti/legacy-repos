import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ControladorTest {
	
	private Controlador controlador;

	@Before
	public void setUp() throws Exception {
		this.controlador = new Controlador();
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSequence1() {
		//Test Sequence 1 :	[resetH(2), setH(1)] q0>q1
		assertEquals(false, controlador.resetH(2));
		assertEquals(true, controlador.setH(1));
		
	}
	@Test
	public void testSequence2() {
		//>>Test Sequence 2 :	[resetH(2), resetH(2)] q0>q0
		assertEquals(false, controlador.resetH(2));
		assertEquals(false, controlador.resetH(2));
		
	}
	@Test
	public void testSequence18() {
		//>>Test Sequence 18 :	[setH(1), resetH(2), setH(2)] q1> q5
		assertEquals(true, controlador.setH(1));
		assertEquals(false, controlador.resetH(2));
		assertEquals(true, controlador.setH(2));
	}
	@Test
	public void testSequence19() {
		//Test Sequence 19 :	[setH(1), resetH(2), resetH(2)] q1>q1
		assertEquals(true, controlador.setH(1));
		assertEquals(false, controlador.resetH(2));
		assertEquals(false, controlador.resetH(2));
	}
	@Test
	public void testSequence30() {
		//Test Sequence 30 :	[setH(1), setH(2), resetH(2)] q5>q1
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2)); 
		assertEquals(true, controlador.resetH(2));
	}
	@Test
	public void testSequence31() {
		//Test Sequence 31 :	[setH(1), setH(2), alerta(2)] q5>q3
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2));
		controlador.alerta(2);
		
	}
	@Test
	public void testSequence48() {
		//Test Sequence 48 :	[setH(2), setH(1), alerta(1), resetH(2), getV(2)] q2>q2
		assertEquals(true, controlador.setH(2));
		assertEquals(true, controlador.setH(1));
		controlador.alerta(1);
		assertEquals(true, controlador.resetH(2));
		assertEquals(false, controlador.getV(2));
		
	}
	@Test
	public void testSequence96() {
		//Test Sequence 96 :	[setH(2), setH(1), alerta(2), alerta(2), getV(1)] q3>q3
		assertEquals(true, controlador.setH(2));
		assertEquals(true, controlador.setH(1));
		controlador.alerta(2);
		controlador.alerta(2);
		assertEquals(false, controlador.getV(1));
	}
	@Test
	public void testSequence129() {
		//Test Sequence 129 :[setH(2), resetAlerta(1), resetH(2)] q4>q0
		assertEquals(true, controlador.setH(2));
		controlador.resetAlerta(1);
		assertEquals(true, controlador.resetH(2));
		
	}
	@Test
	public void testSequence133() {
		//Test Sequence 133 :[setH(2), resetH(1), alerta(2)] q4>q4
		assertEquals(true, controlador.setH(2));
		assertEquals(false, controlador.resetH(1));
		controlador.alerta(2);
		}
	
	@Test
	public void testSequence134() {
		//Test Sequence 134 :[setH(2), resetH(1), setH(1)] q4>q5
		assertEquals(false, controlador.resetH(2));
		assertEquals(true, controlador.setH(1));
		
	}
	@Test
	public void testSequence158() {
		//Test Sequence 158 :[setH(2), setH(1), resetAlerta(1), setH(1)] q5>q5
		assertEquals(true, controlador.setH(2));
		assertEquals(true, controlador.setH(1));
		controlador.resetAlerta(1);
		assertEquals(false, controlador.setH(1));
		
	}
	@Test
	public void testSequence227() {
		//Test Sequence 227 :[setH(2), setH(1), alerta(2), alerta(1), setH(1) q6>q6
		assertEquals(true, controlador.setH(2));
		assertEquals(true, controlador.setH(1));
		controlador.alerta(2);
		controlador.alerta(1);
		assertEquals(false, controlador.setH(1));
		
	}
	@Test
	public void testSequence228() {
		//Test Sequence 228 :[setH(1), setH(1), alerta(2), alerta(1), resetH(1), setH(2)] q0>q4
		assertEquals(true, controlador.setH(1));
		assertEquals(false, controlador.setH(1));
		controlador.alerta(2);
		controlador.alerta(1);
		assertEquals(true, controlador.resetH(1));
		assertEquals(true, controlador.setH(2));
		
		
	}
	@Test
	public void testSequence229() {
		//Test Sequence 229 :[setH(1), setH(1), alerta(2), alerta(1), resetH(1)] q1>q0
		assertEquals(true, controlador.setH(1));
		assertEquals(false, controlador.setH(1));
		controlador.alerta(2);
		controlador.alerta(1);
		assertEquals(true, controlador.resetH(1));
	}
	@Test
	public void testSequence230() {
		//Test sequence 230 :[setH(1), setH(2), alerta(2), alerta(1), resetAlerta(1)] q6>q3
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2));
		controlador.alerta(2);
		controlador.alerta(1);
		controlador.resetAlerta(1);
	}
	@Test
	public void testSequence231() {
		//Test sequence 231 :	[setH(1), setH(2), alerta(2), alerta(1), resetAlerta(2)] q6>q2
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2));
		controlador.alerta(2);
		controlador.alerta(1);
		controlador.resetAlerta(2);
	}
	@Test
	public void testSequence232() {
		//Test sequence 232 :[setH(1), setH(2), alerta(1), resetAlerta(1)] q2>q5
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2));
		controlador.alerta(1);
		controlador.resetAlerta(1);
	}
	@Test
	public void testSequence233() {
		//Test sequence 233 :[setH(1), setH(2), alerta(2), resetAlerta(2)] q3>q5
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2));
		controlador.alerta(2);
		controlador.resetAlerta(2);
	}
	@Test
	public void testSequence234() {
		//Test sequence 234 :[setH(1), setH(2), alerta(1), resetAlerta(2), alerta(2)] q2>q6
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2));
		controlador.alerta(1);
		controlador.resetAlerta(2);
		controlador.alerta(2);
	}
	@Test
	public void testSequence235() {
		//Test sequence 235 :[setH(1), setH(2), alerta(2), resetAlerta(1), alerta(1)] q3>q6
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2));
		controlador.alerta(2);
		controlador.resetAlerta(1);
		controlador.alerta(1);
	}
	@Test
	public void testSequence236() {
		//Test sequence 236 :[setH(1), setH(2), alerta(1)] q5>q2
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2));
		controlador.alerta(1);
	}
	@Test
	public void testSequence237() {
		//Test sequence 237 :[setH(1), setH(2), resetH(1)] q5>q4
		assertEquals(true, controlador.setH(1));
		assertEquals(true, controlador.setH(2));
		assertEquals(true, controlador.resetH(1));
	}
	
}
