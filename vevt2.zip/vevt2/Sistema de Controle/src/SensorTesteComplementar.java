import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SensorTesteComplementar {

	private Sensor sensor;

	@Before
	public void setUp() throws Exception {
		this.sensor = new Sensor(1, new ControladorMock());
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testeComplementar1() {
		sensor.setR(0.5);
		double a = sensor.getR();
		
		assertEquals(0.5, a, 0);
	}
	@Test
	public void testeComplementar2() {
		double old = sensor.getR();
		sensor.setR(-0.5);
		double a = sensor.getR();
		
		assertEquals(old, a, 0);
	}
	@Test
	public void testeComplementar3() {
		double old = sensor.getR();
		sensor.setR(1.5);
		double a = sensor.getR();
		
		assertEquals(old, a, 0);
	}
	@Test
	public void testeComplementar4(){
		try{ sensor = new Sensor(1, new ControladorMock()); }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar5(){
		try{ sensor = new Sensor(2, new ControladorMock()); }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar6(){
		try{ sensor = new Sensor(0, new ControladorMock());	} 
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
	@Test
	public void testeComplementar7(){
		try{ sensor = new Sensor(3, new ControladorMock()); } 
		catch(IllegalArgumentException e){ /*Success*/ }
		catch(Exception e){ fail(); }
	}
}
