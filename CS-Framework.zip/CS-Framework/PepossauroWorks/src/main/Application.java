package main;

import java.sql.SQLException;

import construc.bd.old.CreateBD;
import mock.MockIdentifiable;
import view.Pepoview;

/**
 * Para utilizar este framework, será necessário configurar a classe de configuração:
 * 
 * Pepofile
 * 
 * Para isso, deve-se criar subclasses para as seguintes classes:
 * DatabaseManager
 * Identifiable
 */

public class Application {
	public static void main(String[] args) {		
//		try {
//			CreateBD.main(args);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
		Pepoview.main(args);
	}
}