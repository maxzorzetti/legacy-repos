package main;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import database.Identifiable;

public class ConstrucIdentifiable extends Identifiable {

	private String name;
	private Integer age;
	private String address;
	private Double salary;

	public ConstrucIdentifiable(Object id, String name, Integer age, String address, Double salary) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.address = address;
		this.salary = salary;
	}
	
	public ConstrucIdentifiable() { }

	@Override
	public Map<String, String> getMapRepresentation() {
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("ID", id.toString());
		map.put("NAME", name);
		map.put("AGE", age.toString());
		map.put("ADDRESS", address);
		map.put("SALARY", salary.toString());
		
		return map;
	}

	@Override
	public Identifiable copy() {
		return new ConstrucIdentifiable(this.id, this.name, this.age, this.address, this.salary);
	}
	
	@Override
	public void updateWithDic(Map<String, String> dictionary) throws Exception {
//		super.updateWithDic(dictionary);
		this.id = dictionary.get("ID");
		this.name = dictionary.get("NAME");
		this.age = Integer.parseInt(dictionary.get("AGE"));
		this.address = dictionary.get("ADDRESS");
		this.salary = Double.parseDouble(dictionary.get("SALARY"));
	}
	
	public ArrayList<String> toList(){
		ArrayList<String> dados = new ArrayList<String>();
		dados.add(""+id);
		dados.add(""+name);
		dados.add(""+age);
		dados.add(""+address);
		dados.add(""+salary);
		return dados;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
}
