package main;

import database.DatabaseManager;
import database.Identifiable;
import mock.MockDB;

public class Pepofile {
	/**
	 * Identifica o arquivo que implementa o banco de dados.
	 * Deve ser atribuído à db uma instância da classe que implementa DatabaseManager.
	 * Se db == null, MockDB será utilizado como banco padrão de teste.
	 */
	@SuppressWarnings("unchecked")
	public static DatabaseManager<Identifiable> db = new ConstrucDB("COMPANYaa");
	
	/**
	 * Identifica o arquivo que será manipulado pela aplicação e pelo banco de dados.
	 */
	public static Identifiable identifiable = new ConstrucIdentifiable(1, "MockName", 1, "MockAddress", 1.5);
}
