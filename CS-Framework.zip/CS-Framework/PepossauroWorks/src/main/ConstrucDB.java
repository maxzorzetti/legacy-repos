package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.event.ListSelectionEvent;

import construc.bd.*;
import database.DatabaseManager;
import database.Identifiable;

public class ConstrucDB extends DatabaseManager {
	
	private DBManager dbManager;
	
	public ConstrucDB(String tableName) {
		try {
			MetadadosTabela metadata = new MetadadosTabela(tableName);
			this.dbManager = new DBManager(metadata);
		} catch (SQLException e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

	@Override
	public Collection retrieveAll() {
		try {
			List<LinkedHashMap<String, String>> dictionary = dbManager.buscarTodosRegistrosComoArrayDeMapa();
			List<ConstrucIdentifiable> all = new ArrayList<ConstrucIdentifiable>();
			
			for(Map<String, String> dic: dictionary) {
				ConstrucIdentifiable identifiable = new ConstrucIdentifiable();
				identifiable.updateWithDic(dic);
				all.add(identifiable);
			}

			return all;
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList();
		}
	}

	@Override
	public Identifiable create(Identifiable data) {
		Map<String, String> map = data.getMapRepresentation();
		try {
			dbManager.inserir(new ArrayList<String>(map.values()));
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return data;
	}

	@Override
	public Identifiable retrieve(Object id) {
		return null;
	}

	@Override
	public Identifiable update(Identifiable data) {
		try {
			ArrayList<String> atual = new ArrayList<String>();
			dbManager.update(data.getId().toString(), ((ConstrucIdentifiable)data).toList());
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Identifiable delete(Object id) {
		try {
			String idString = id.toString();
			dbManager.deletar(idString);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
//		ArrayList old = new ArrayList();
//		old.add(id);
//		try {
//			dbManager.deletar(old);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return null;
	}

}
