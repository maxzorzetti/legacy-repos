//
//  Alarme.swift
//  WakeUpBoi
//
//  Created by Student on 9/1/16.
//  Copyright © 2016 Dankness Edit. All rights reserved.
//

import Foundation
import CoreData


class Alarme: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
