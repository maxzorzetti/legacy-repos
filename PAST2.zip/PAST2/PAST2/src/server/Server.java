package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collection;

import logger.Log;
import logic.Champions;
import model.Champion;

public class Server {
	private ServerSocket socket;
	private int port = 1200;
	private boolean running;
	
	private final String endOfTransmissionToken = "@";
	
	public Server(int port) {
		Champions.getInstance();
		this.running = false;
		this.port = port;
	}
	
	public void start() {
		try { 
			String startupMsg = "Starting server on port " + port + "...";
			System.out.println(startupMsg);
			Log.getInstance().logFinest(startupMsg);
			
			socket = new ServerSocket(port);
			this.running = true;
			
			Log.getInstance().logFinest("Server is up and running.");
			
			while (running) {
				Log.getInstance().logFinest("Waiting for a new client to connect.");
				System.out.println("Waiting for clients...");
				
				Socket client = socket.accept();
				Log.getInstance().logFinest("Client " + client.getRemoteSocketAddress() + " connected.");
				System.out.println("Client connected.");
				
				Log.getInstance().logFinest("Dispatching new thread to handle client " + client.getRemoteSocketAddress());
				new Thread(() -> {
					handleClient(client);
				}).start();
				Log.getInstance().logFinest("Thread dispatched for client " + client.getRemoteSocketAddress());
			}
			
			socket.close();
			
		} catch (IOException e) {
			Log.getInstance().logSevere("Error creating server socket");
			System.out.println("Server error.\n\nShutting down.");
			e.printStackTrace();
		}
	}

	private void handleClient(Socket client) {		
		try {
			BufferedReader inputFromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
			PrintWriter outputToClient = new PrintWriter(client.getOutputStream(), true);
			
			boolean repeat = true;
			while(repeat) {
				Log.getInstance().logFinest("Receiving client " + client.getRemoteSocketAddress() + " request.");
				
				String request = inputFromClient.readLine();
				if(request.equals("requestAllChampions")) {
					requestAllChampionsHandler(outputToClient, client.getRemoteSocketAddress().toString());
				} else if(request.equals("requestFight")) {
					requestFightHandler(inputFromClient, outputToClient, client.getRemoteSocketAddress().toString());
				} else if(request.equals("endConnection")) {
					client.close();
					repeat = false;
					Log.getInstance().logFinest("Client " + client.getRemoteSocketAddress() + " disconnected.");
					System.out.println("Client disconnected.");
				} else {
					Log.getInstance().logWarning("Received unknown request \"" + request + "\" from client " + client.getRemoteSocketAddress());					
				}
			}
		} catch (IOException e) {
			Log.getInstance().logSevere("Error handling client " + client.getRemoteSocketAddress() + ". Aborting.");
			e.printStackTrace();
		}		
	}
	
	private void requestAllChampionsHandler(PrintWriter outputToClient, String clientInfo) {
		Log.getInstance().logFinest("Client " + clientInfo + " requested for all champions.");
		
		Collection<Champion> champions = Champions.getInstance().getChampionsAsCollection();
		System.out.println("Sending champion pool size of " + champions.size());
		outputToClient.println(champions.size());
		
		for(Champion champion : champions) {
			sendChampion(champion, outputToClient, clientInfo);
		}
	}
	
	private void sendChampion(Champion champion, PrintWriter outputToClient, String clientInfo) {
		Log.getInstance().logFinest("Sending " + champion.getId() + " to client " + clientInfo);
		outputToClient.println(endOfTransmissionToken); // signals client that this token will be used to end the transmission
		outputToClient.println(champion);
		outputToClient.println(endOfTransmissionToken); // ends the transmission
	}
	
	private void requestFightHandler(BufferedReader inputFromClient, PrintWriter outputToClient, String clientInfo) {
		Log.getInstance().logFinest("Client " + clientInfo + " requested a fight.");
		
		Champion opponent1 = Champions.getInstance().getRandomChampion();
		sendChampion(opponent1, outputToClient, clientInfo);
		
		Champion opponent2 = null;
		boolean isValidClientChampion = false;
		while (!isValidClientChampion) {
			try {
				Log.getInstance().logFinest("Receiving champion from client " + clientInfo);
				String championFromClient = inputFromClient.readLine();
				opponent2 = Champions.getInstance().getChampionByQuery(championFromClient);
				Log.getInstance().logFinest("Received champion " + opponent2.getId() + " from client " + clientInfo);
				isValidClientChampion = true;
				outputToClient.println("valid");
			} catch (Exception e){
				Log.getInstance().logFine("Received unknown champion from client " + clientInfo);
				outputToClient.println("invalid");
			}
		}
		
		Champion winner = Champions.getInstance().getWinnerFromBattle(opponent1, opponent2);
		if (winner == null) {
			Log.getInstance().logFinest("Client " + clientInfo + " battled " + opponent2 + " as " + opponent1 + " and it was a draw.");
			Champions.getInstance().increaseDrawCountForChampion(opponent1);
			Champions.getInstance().increaseDrawCountForChampion(opponent2);
		} else if (winner.getId() == opponent1.getId()) {
			Log.getInstance().logFinest("Client " + clientInfo + " battled " + opponent2 + " as " + opponent1 + " and won.");
			Champions.getInstance().increaseWinCountForChampion(opponent1); 
			Champions.getInstance().increaseLossCountForChampion(opponent2); 
		} else if (winner.getId() == opponent2.getId()) {
			Log.getInstance().logFinest("Client " + clientInfo + " battled " + opponent2 + " as " + opponent1 + " and lost.");
			Champions.getInstance().increaseWinCountForChampion(opponent2); 
			Champions.getInstance().increaseLossCountForChampion(opponent1);
		}

		outputToClient.println(winner != null ? winner.getName() : "Draw!");
	}
	
	public static void main(String args[]) {
		Server server = new Server(1200);
		server.start();
	}
	
}
