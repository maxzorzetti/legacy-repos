package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ChampionListDTO {
	private Map<String, ChampionDTO> data;
	private String type;
	private String version;
	
//	public ChampionListDTO() {
//		data = new HashMap<String, ChampionDTO>();
//	}

	public String getType() {
		return type;
	}

	public String getVersion() {
		return version;
	}

	public Map<String, ChampionDTO> getData() {
		return data;
	}
	
	public List<Champion> getAsChampionList() {
		ArrayList<Champion> championList = new ArrayList<Champion>();
		if (data != null) {			
			for (ChampionDTO championDTO: data.values()) {
				championList.add(championDTO.getAsChampion());
			}
		}
		return championList;
	}
}