package model;

public class Champion {
	private final int id;
	private String name;
	private int level;
	private double hp;
	private double hpPerLevel;
	private double hpRegen;
	private double hpRegenPerLevel;
	private double armor;
	private double armorPerLevel;
	private double attackDamage;
	private double attackDamagePerLevel;
	private double attackSpeed;
	private double attackSpeedPerLevel;
	
	public Champion(int id, String name, int level, double hp, double hpPerLevel,
			double hpRegen, double hpRegenPerLevel, double armor,
			double armorPerLevel, double attackDamage,
			double attackDamagePerLevel, double attackSpeed,
			double attackSpeedPerLevel) {
		super();
		this.id = id;
		this.name = name;
		this.level = level;
		this.hp = hp;
		this.hpPerLevel = hpPerLevel;
		this.hpRegen = hpRegen;
		this.hpRegenPerLevel = hpRegenPerLevel;
		this.armor = armor;
		this.armorPerLevel = armorPerLevel;
		this.attackDamage = attackDamage;
		this.attackDamagePerLevel = attackDamagePerLevel;
		this.attackSpeed = attackSpeed;
		this.attackSpeedPerLevel = attackSpeedPerLevel;
	}

	public Champion(int id, String name, double hp, double hpPerLevel, double hpRegen,
			double hpRegenPerLevel, double armor, double armorPerLevel,
			double attackDamage, double attackDamagePerLevel,
			double attackSpeed, double attackSpeedPerLevel) {
		super();
		this.id = id;
		this.name = name;
		this.level = 1;
		this.hp = hp;
		this.hpPerLevel = hpPerLevel;
		this.hpRegen = hpRegen;
		this.hpRegenPerLevel = hpRegenPerLevel;
		this.armor = armor;
		this.armorPerLevel = armorPerLevel;
		this.attackDamage = attackDamage;
		this.attackDamagePerLevel = attackDamagePerLevel;
		this.attackSpeed = attackSpeed;
		this.attackSpeedPerLevel = attackSpeedPerLevel;
	}


	// basic getters and setters
	public int getId() {
		return id;
	}
	
//	public void setId(int id) {
//		this.id = id;
//	}
//	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		if (level >= 1 && level <= 18) this.level = level;
	}

	public double getHp() {
		return hp;
	}

	public void setHp(double hp) {
		this.hp = hp;
	}

	public double getHpPerLevel() {
		return hpPerLevel;
	}

	public void setHpPerLevel(double hpPerLevel) {
		this.hpPerLevel = hpPerLevel;
	}

	public double getHpRegen() {
		return hpRegen;
	}

	public void setHpRegen(double hpRegen) {
		this.hpRegen = hpRegen;
	}

	public double getHpRegenPerLevel() {
		return hpRegenPerLevel;
	}

	public void setHpRegenPerLevel(double hpRegenPerLevel) {
		this.hpRegenPerLevel = hpRegenPerLevel;
	}

	public double getArmor() {
		return armor;
	}

	public void setArmor(double armor) {
		this.armor = armor;
	}

	public double getArmorPerLevel() {
		return armorPerLevel;
	}

	public void setArmorPerLevel(double armorPerLevel) {
		this.armorPerLevel = armorPerLevel;
	}

	public double getAttackDamage() {
		return attackDamage;
	}

	public void setAttackDamage(double attackDamage) {
		this.attackDamage = attackDamage;
	}

	public double getAttackDamagePerLevel() {
		return attackDamagePerLevel;
	}

	public void setAttackDamagePerLevel(double attackDamagePerLevel) {
		this.attackDamagePerLevel = attackDamagePerLevel;
	}

	public double getAttackSpeed() {
		return attackSpeed;
	}

	public void setAttackSpeed(double attackSpeed) {
		this.attackSpeed = attackSpeed;
	}

	public double getAttackSpeedPerLevel() {
		return attackSpeedPerLevel;
	}

	public void setAttackSpeedPerLevel(double attackSpeedPerLevel) {
		this.attackSpeedPerLevel = attackSpeedPerLevel;
	}
	
	// getters based on level
	public double getHpBasedOnLevel() {
		return hp + hpPerLevel * level;
	}

	public double getHpRegenBasedOnLevel() {
		return hpRegen + hpRegenPerLevel * level;
	}

	public double getArmorBasedOnLevel() {
		return armor + armorPerLevel * level;
	}

	public double getAttackDamageBasedOnLevel() {
		return attackDamage + attackDamagePerLevel * level;
	}

	public double getAttackSpeedBasedOnLevel() {
		return attackSpeed * (1 + attackSpeedPerLevel/100 * level);
	}
	
	// calculates % of incoming damage to be taken
	public double getIncomingDamageMultiplier() {
		return (100 / (100 + armor + armorPerLevel * level));
	}
	
	public String toString() {
		return "Name: " + getName() + 
				"\nId: " + getId() +
				"\nLevel: " + getLevel() +
				"\nHealth points: " + getHpBasedOnLevel() +
				"\nHealth regen: " + getHpRegenBasedOnLevel() + 
				"\nArmor: " + getArmorBasedOnLevel() + 
				"\nAttack damage: " + getAttackDamageBasedOnLevel() + 
				"\nAttack speed: " + getAttackSpeedBasedOnLevel();
	}

}
