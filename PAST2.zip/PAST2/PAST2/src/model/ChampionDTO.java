package model;

public class ChampionDTO {
	private final int id;
	private String key ;
	private String name;
	private StatsDTO stats;
	
	public ChampionDTO(int id, String key, String name, StatsDTO stats) {
		super();
		this.id = id;
		this.key = key;
		this.name = name;
		this.stats = stats;
	}
	
	public Champion getAsChampion() {
		Champion champion= new Champion(id, name, 
				getStats().hp, getStats().hpperlevel, 
				getStats().hpregen, getStats().hpregenperlevel, 
				getStats().armor, getStats().armorperlevel, 
				getStats().attackdamage, getStats().armorperlevel, 
				0.625 - getStats().attackspeedoffset, 
				getStats().attackspeedperlevel);
		
		return champion;
	}
	
	public int getId() {
		return id;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public StatsDTO getStats() {
		return stats;
	}

	public void setStats(StatsDTO stats) {
		this.stats = stats;
	}

	public String toString() {
		return getName();
	}
	
	public class StatsDTO {
		private double hp;
		private double hpperlevel;
		private double hpregen;
		private double hpregenperlevel;
		private double armor;
		private double armorperlevel;
		private double attackdamage;
		private double attackdamageperlevel;
		private double attackspeedoffset;
		private double attackspeedperlevel;
		
		public double getHp() { return hp; }
		public double getHpPerLevel() { return hpperlevel; }
		public double getHpRegen() { return hpregen; }
		public double getHpRegenPerLevel() { return hpregenperlevel; }
		public double getArmor() { return armor; }
		public double getArmorPerLevel() { return armorperlevel; }
		public double getAttackDamage() { return attackdamage; }
		public double getAttackDamagePerLevel() { return attackdamageperlevel; }
		public double getAttackSpeedOffset() { return attackspeedoffset; }
		public double getAttackSpeedPerLevel() { return attackspeedperlevel; }
	}

}
