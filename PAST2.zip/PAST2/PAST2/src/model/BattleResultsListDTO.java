package model;

import java.util.HashMap;
import java.util.Map;

public class BattleResultsListDTO {
	private Map<Integer, BattleResultsDTO> battleResults;
	
	public BattleResultsListDTO() {
		this.battleResults = new HashMap<Integer, BattleResultsDTO>();
	}

	public Map<Integer, BattleResultsDTO> getBattleResults() {
		return battleResults;
	}
}
