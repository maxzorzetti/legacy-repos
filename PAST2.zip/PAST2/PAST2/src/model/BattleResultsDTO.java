package model;

public class BattleResultsDTO {
	private int championId;
	private int winCount;
	private int lossCount;
	private int drawCount;
	
	public BattleResultsDTO(int championId, int winCount, int lossCount, int drawCount) {
		super();
		this.championId = championId;
		this.winCount = winCount;
		this.lossCount = lossCount;
		this.drawCount = drawCount;
	}

	public int getChampionId() {
		return championId;
	}

	public void setChampionId(int championId) {
		this.championId = championId;
	}

	public int getWinCount() {
		return winCount;
	}

	public void setWinCount(int winCount) {
		this.winCount = winCount;
	}

	public int getLossCount() {
		return lossCount;
	}

	public void setLossCount(int lossCount) {
		this.lossCount = lossCount;
	}

	public int getDrawCount() {
		return drawCount;
	}

	public void setDrawCount(int drawCount) {
		this.drawCount = drawCount;
	}

	public String toString() {
		return "Win count: " + winCount + "\tLoss count: " + lossCount + "\tDraw Count: " + drawCount;
	}
}
