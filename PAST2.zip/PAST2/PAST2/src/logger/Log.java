package logger;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Log {
	private Logger logger;
	private FileHandler fileHandler;
	
	public static String fileName = "ServerLog";
	
	private static Log instance;
	
	private Log() {
		File file = new File(fileName);
		try {
			file.createNewFile();
			fileHandler = new FileHandler(fileName, true);
			logger = Logger.getLogger("logger");
			logger.addHandler(fileHandler);
			logger.setLevel(Level.ALL);
			SimpleFormatter simpleFormatter = new SimpleFormatter();
			fileHandler.setFormatter(simpleFormatter);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Log getInstance() {
		if(instance == null) {
			instance = new Log();
		}
		return instance;
	}
	
	public void log(Level level, String msg) {
		logger.log(level, msg);
	}
	
	public void logSevere(String msg) {
		logger.log(Level.SEVERE, msg);
	}
	
	public void logWarning(String msg) {
		logger.log(Level.WARNING, msg);
	}
	
	public void logInfo(String msg) {
		logger.log(Level.INFO, msg);
	}
	
	public void logConfig(String msg) {
		logger.log(Level.CONFIG, msg);
	}
	
	public void logFine(String msg) {
		logger.log(Level.FINE, msg);
	}
	
	public void logFiner(String msg) {
		logger.log(Level.FINER, msg);
	}
	
	public void logFinest(String msg) {
		logger.log(Level.FINEST, msg);
	}
}


//SEVERE (highest value)
//WARNING
//INFO
//CONFIG
//FINE
//FINER
//FINEST (lowest value)