package comms;

import java.io.IOException;
import java.util.Collection;

import com.google.gson.Gson;

import logger.Log;
import model.Champion;
import model.ChampionListDTO;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class RiotAPI {
	
	private static final String staticDataURL = "https://br1.api.riotgames.com/lol/static-data/v3/champions";
	private static final String apiKey = "RGAPI-0e17ad73-3bb6-4afe-bd95-2283db0af0ee";
		
	public static Collection<Champion> getAllChampions() {
		Log.getInstance().logFinest("Loading champions from Riot's API.");
		System.out.println("Loading champions from Riot's API.");
		
		OkHttpClient client = new OkHttpClient();
		Request request = new Request.Builder()
				.url(staticDataURL + "?&api_key=" + apiKey + "&tags=stats&locale=en_US&dataById=true")
				.build();
	
		Response response;
		ChampionListDTO championListDTO;
		try {
			response = client.newCall(request).execute();
			String json = response.body().string();
			championListDTO = new Gson().fromJson(json, ChampionListDTO.class);
		} catch (IOException e) {
			Log.getInstance().logSevere("Failed to connect to Riot's API. No champions have been loaded.");
			championListDTO = new ChampionListDTO();
			e.printStackTrace();
		}
		
		Log.getInstance().logFinest("Finished loading champions from Riot's API.");
		
		return championListDTO.getAsChampionList();
	}
	
}
