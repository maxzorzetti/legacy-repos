package comms;

public interface DatabaseInterface {
	public void increaseWinCountForChampionWithId(int id);
	public void increaseLossCountForChampionWithId(int id);
	public void increaseDrawCountForChampionWithId(int id);
	public int getWinCountForChampionWithId(int id);
	public int getLossCountForChampionWithId(int id);
	public int getDrawCountForChampionWithId(int id);
}
