package comms;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import comms.DatabaseInterface;
import logger.Log;
import model.BattleResultsDTO;
import model.BattleResultsListDTO;

public class JSONDatabase implements DatabaseInterface {
	
	private final File DB_FILE = new File("x1league.json");
	
	public JSONDatabase() {
		
		if (!DB_FILE.exists()) {
			Log.getInstance().logFinest("Database file not found.");
			try {
				Log.getInstance().logFinest("Creating new database file.");
				DB_FILE.createNewFile();
				
				Log.getInstance().logFinest("Creating database structure.");
				JsonWriter jsonWriter = new Gson().newJsonWriter(new BufferedWriter(new FileWriter(DB_FILE)));
				jsonWriter.setIndent("\n");
				jsonWriter.jsonValue(new Gson().toJson(new BattleResultsListDTO()));
				jsonWriter.close();
				
			} catch (IOException e) {
				Log.getInstance().logSevere("Error creating new database.");
				e.printStackTrace();
			}
		}
	}
	
	private BattleResultsDTO getBattleResultsDTOForId(int id) {
		BattleResultsDTO battleResultsDTO = null;
		
		try {
			Log.getInstance().logFinest("Getting battle results for champion " + id);
			
			JsonReader json = new Gson().newJsonReader(new BufferedReader(new FileReader(DB_FILE)));
			BattleResultsListDTO battleResultsListDTO = new Gson().fromJson(json, BattleResultsListDTO.class);
			
			battleResultsDTO = battleResultsListDTO.getBattleResults().get(id);
			if (battleResultsDTO == null) {
				battleResultsDTO = new BattleResultsDTO(id, 0, 0, 0);
			}
			
			
		} catch (FileNotFoundException e) {
			Log.getInstance().logSevere("Unable to get battle results for champion " + id + ". Database file not found.");
			e.printStackTrace();
		}
		
		return battleResultsDTO;
	}
	
	private void saveBattleResultsDTO(BattleResultsDTO brDTO) {
		try {
			JsonReader jsonReader = new Gson().newJsonReader(new BufferedReader(new FileReader(DB_FILE)));
			BattleResultsListDTO battleResultsListDTO = new Gson().fromJson(jsonReader, BattleResultsListDTO.class);
			
			battleResultsListDTO.getBattleResults().put(brDTO.getChampionId(), brDTO);
			
			JsonWriter jsonWriter = new Gson().newJsonWriter(new BufferedWriter(new FileWriter(DB_FILE)));
			jsonWriter.setIndent("    ");
			jsonWriter.jsonValue(new Gson().toJson(battleResultsListDTO));
			jsonWriter.close();
			
		} catch (FileNotFoundException e) {
			Log.getInstance().logSevere("Unable to save battle results for champion " + brDTO.getChampionId() + ". Database file not found.");
			e.printStackTrace();
		} catch (IOException e) {
			Log.getInstance().logSevere("Unable to save battle results for champion " + brDTO.getChampionId() + ". Error on writing data.");
			e.printStackTrace();
		}
	}

	@Override
	public void increaseWinCountForChampionWithId(int id) {
		BattleResultsDTO brDTO = getBattleResultsDTOForId(id);
		brDTO.setWinCount(brDTO.getWinCount() + 1);
		saveBattleResultsDTO(brDTO);
	}	

	@Override
	public void increaseLossCountForChampionWithId(int id) {
		BattleResultsDTO brDTO = getBattleResultsDTOForId(id);
		brDTO.setLossCount(brDTO.getLossCount() + 1);
		saveBattleResultsDTO(brDTO);
	}

	@Override
	public void increaseDrawCountForChampionWithId(int id) {
		BattleResultsDTO brDTO = getBattleResultsDTOForId(id);
		brDTO.setDrawCount(brDTO.getDrawCount() + 1);
		saveBattleResultsDTO(brDTO);
	}

	@Override
	public int getWinCountForChampionWithId(int id) {
		BattleResultsDTO brDTO = getBattleResultsDTOForId(id);
		return brDTO.getWinCount();
	}

	@Override
	public int getLossCountForChampionWithId(int id) {
		BattleResultsDTO brDTO = getBattleResultsDTOForId(id);
		return brDTO.getLossCount();
	}

	@Override
	public int getDrawCountForChampionWithId(int id) {
		BattleResultsDTO brDTO = getBattleResultsDTOForId(id);
		return brDTO.getDrawCount();
	}
	
	public static void main(String args[]) {
		new JSONDatabase();
	}

}
