package logic;
import logger.Log;
import model.Champion;

public class Battle {
	public enum Winner {
		OPPONENT1("opponent1"), OPPONENT2("opponent2"), DRAW("draw");
		private String name;
		private Winner(String s) { name = s; }
		public String toString() { return name; }
	}
	private Champion opponent1;
	private Champion opponent2;
	
	public Battle(Champion opponent1, Champion opponent2) {
		this.opponent1 = opponent1;
		this.opponent2 = opponent2;
	}

	// basic setters and getters
	public Champion getOponent1() {
		return opponent1;
	}

	public void setOponent1(Champion opponent1) {
		if (opponent1 != null) this.opponent1 = opponent1;
	}

	public Champion getOponent2() {
		return opponent2;
	}

	public void setOponent2(Champion opponent2) {
		if (opponent2 != null) this.opponent2 = opponent2;
	}
	
	public Winner fight() {
		if (opponent1 != null && opponent2 != null) {
			Log.getInstance().logFinest("Starting fight between " + opponent1.getId() + " and " + opponent2.getId());
			double oponent1Hp = opponent1.getHpBasedOnLevel();	// get champions's total HP
			double oponent2Hp = opponent2.getHpBasedOnLevel();
			while (oponent1Hp > 0 && oponent2Hp > 0) {	// for each round, decrease their hp by the damage output of the opponent + self hp regen
				oponent1Hp -= opponent2.getAttackDamageBasedOnLevel() * opponent2.getAttackSpeedBasedOnLevel() * opponent1.getIncomingDamageMultiplier() + opponent1.getHpRegenBasedOnLevel();
				oponent2Hp -= opponent1.getAttackDamageBasedOnLevel() * opponent1.getAttackSpeedBasedOnLevel() * opponent2.getIncomingDamageMultiplier() + opponent2.getHpRegenBasedOnLevel();
			}
			if (oponent1Hp <= 0 && oponent2Hp <= 0) {
				return Winner.DRAW;
			} else if (oponent1Hp > 0) return Winner.OPPONENT1;
			else return Winner.OPPONENT2;
		} else {
			Log.getInstance().logSevere("Battle was created between null-valued champions.");
			return null;
		}
	}
	
}
