package logic;

import java.util.Collection;
import java.util.HashSet;
import java.util.Random;

import comms.DatabaseInterface;
import comms.JSONDatabase;
import comms.RiotAPI;
import logger.Log;
import model.Champion;

public class Champions {
	
	private static Champions instance = null;
	
	private HashSet<Champion> champions;
	private DatabaseInterface database;
	
	private Champions() {
		this.champions = new HashSet<Champion>();
		this.database = new JSONDatabase();
		this.champions.addAll(RiotAPI.getAllChampions());
	}
	
	public static Champions getInstance() {
		if (instance == null) {
			instance = new Champions();
		}
		return instance;
	}
	
	public Champion getWinnerFromBattle(Champion opponent1, Champion opponent2) {
		Battle battle = new Battle(opponent1, opponent2);
		
		Battle.Winner results = battle.fight();
		
		switch (results) {
		case OPPONENT1:
			return opponent1;
		case OPPONENT2:
			return opponent2;
		case DRAW:
			return null;
		}
		
		return null;
	}
	
	public void increaseWinCountForChampion(Champion champion) {
		Log.getInstance().logFinest("Increasing win count for champion " + champion.getId());
		database.increaseWinCountForChampionWithId(champion.getId());
	}
	
	public void increaseLossCountForChampion(Champion champion) {
		Log.getInstance().logFinest("Increasing loss count for champion " + champion.getId());
		database.increaseLossCountForChampionWithId(champion.getId());
	}
	
	public void increaseDrawCountForChampion(Champion champion) {
		Log.getInstance().logFinest("Increasing draw count for champion " + champion.getId());
		database.increaseDrawCountForChampionWithId(champion.getId());
	}
	
	public Collection<Champion> getChampionsAsCollection() {
		return champions;
	}
	
	public Champion getRandomChampion() {
		int randomIndex = new Random().nextInt(champions.size());
		
		Champion champion = null;
		int i = 0;
		for(Champion champ: champions) {
			if ( i == randomIndex ) {
				champion = champ;
				break;
			}
			i++;
		}
		return champion;
	}

	public Champion getChampionById(int id) throws Exception {		
		Log.getInstance().logFinest("Searching for champion with id " + id);
		
		for (Champion champion: champions) {
			if (champion.getId() == id) {
				return champion;
			}
		}
		throw new Exception("Unknown champion id.");
	}
	
	public Champion getChampionByName(String name) throws Exception {
		name = name.toLowerCase();
		
		Log.getInstance().logFinest("Searching for champion with name " + name);
		
		for (Champion champion: champions) {
			if (champion.getName().toLowerCase().equals(name)) {
				return champion;
			}
		}
		throw new Exception("Unknown champion name.");
	}
	
	public Champion getChampionByQuery(String query) throws Exception {
		try {
			int id = Integer.parseInt(query);
			return getChampionById(id);
		} catch (NumberFormatException e) {
			return getChampionByName(query);
		} catch (Exception e) {
			throw e;
		}
	}
	
}
