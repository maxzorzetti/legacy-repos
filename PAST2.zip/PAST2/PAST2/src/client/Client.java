package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Client {
	private String serverIp;
	private int serverPort;
	private Socket server;
	private BufferedReader inputFromServer;
	private PrintWriter outputToServer;
	
	public Client(String ip, int port) {
		this.serverIp = ip;
		this.serverPort = port;
	}
	
	public Client() {
		this.serverIp = "localhost";
		this.serverPort = 1200;
	}	
	
	public void start() {
		System.out.println("Connecting to " + serverIp + " on port " + serverPort);

		try {
			server = new Socket(serverIp, serverPort);
			outputToServer = new PrintWriter(server.getOutputStream(), true);
			inputFromServer = new BufferedReader(new InputStreamReader(server.getInputStream()));
			
			menuHandler();
			
			server.close();
		} catch(UnknownHostException e) {
			e.printStackTrace();
			System.out.println("Something went wrong. Is the server online?");
			System.out.println("Exiting.");
		} catch(IOException e) {
			System.out.println("Something went wrong. Is your internet connection still up?");
			System.out.println("Exiting.");
		}
	}

	private void menuHandler() {
		Scanner in = new Scanner(System.in);
		boolean menuLoop = true;
		int option = 0; 
		while(menuLoop) {
			System.out.println("----------YoLeague----------");
			System.out.println("1 - Fight!");
			System.out.println("2 - View champions.");
			System.out.println("0 - Exit.");
			System.out.print("Option: ");
			try {
				option = in.nextInt();
			} catch(InputMismatchException e) {
				System.out.println("Invalid option. Please, try again.");
				continue;
			}
			
			switch(option) {
				case 1:	
					requestFight();
					break;
				case 2:
					requestAllChampions();
					break;
				case 0:
					menuLoop = false;
					endConnection(outputToServer);
					break;
				default:
					System.out.println("Invalid option. Please, try again.");	
			}
		}
		
		System.out.println("Exiting.");	
		in.close();
	}
	
	private void requestAllChampions() {
		outputToServer.println("requestAllChampions");
		try {
			System.out.println("Loading champions.");
			int numberOfChampionsToReceive = Integer.parseInt(inputFromServer.readLine());
			for(int i = 0; i < numberOfChampionsToReceive; i++) {
				System.out.println(receiveChampion());
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	private String receiveChampion() {
		String endOfTransmissionToken;
		StringBuilder stringBuilder = new StringBuilder();
		try {
			endOfTransmissionToken = inputFromServer.readLine();	// receives token that will be used to end the transmission
			boolean repeat = true;
			while(repeat) {
				String data = inputFromServer.readLine();
				if(data.equals(endOfTransmissionToken)) repeat = false;	// transmission ended
				else {
					stringBuilder.append(data);
					stringBuilder.append("\n");
				}
			}
		} catch(IOException e) {	
			e.printStackTrace();
		}
		return stringBuilder.toString();
	}
	
	private void requestFight() {
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		
		outputToServer.println("requestFight");
		
		String opponent = receiveChampion();
		System.out.println("Your opponent is: ");
		System.out.println(opponent);
		
		boolean repeat = true;
		while(repeat) {
			System.out.print("Choose your champion (name or id): ");
			String champion = in.nextLine();
			outputToServer.println(champion);
			
			try {
				String isValidChampion = inputFromServer.readLine();
				if(isValidChampion.equals("valid")) {
					String winner = inputFromServer.readLine();
					System.out.println("The winner is: " + winner);
					repeat = false;
				} else {
					System.out.println("Invalid champion. Please, try again.");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}		
	}
	
	private void endConnection(PrintWriter outToServer) {
		outToServer.println("endConnection");
	}
	
	public static void main(String args[]) {
		if (args.length == 0) {
			Client client = new Client("localhost", 1200);
			client.start();			
		} else {
			Client client = new Client(args[0], 1200);
			client.start();
		}
	}
	
}
