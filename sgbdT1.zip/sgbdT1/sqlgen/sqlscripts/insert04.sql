INSERT INTO END_COMPL_ESTAB
VALUES ('1', '757', 'Rua 5845', '920', '153', 'Bairro no.845', '94049340', '783', '5505133033126', '476', '5505155833819', 'complemento_845@generico.com', '845');
INSERT INTO END_COMPL_ESTAB
VALUES ('2', '504', 'Rua 5909', '781', '185', 'Bairro no.909', '92505063', '908', '5505139827853', '809', '5505159021658', 'complemento_909@generico.com', '909');
INSERT INTO END_COMPL_ESTAB
VALUES ('3', '729', 'Rua 5311', '1398', '141', 'Bairro no.311', '91007011', '433', '5505136108869', '912', '5505159666062', 'complemento_311@generico.com', '311');
INSERT INTO END_COMPL_ESTAB
VALUES ('4', '865', 'Rua 5478', '760', '164', 'Bairro no.478', '90140416', '718', '5505133988235', '824', '5505156681531', 'complemento_478@generico.com', '478');
INSERT INTO END_COMPL_ESTAB
VALUES ('5', '493', 'Rua 5002', '1367', '97', 'Bairro no.2', '98704711', '190', '5505135675106', '238', '5505159675401', 'complemento_2@generico.com', '2');
INSERT INTO END_COMPL_ESTAB
VALUES ('6', '447', 'Rua 5804', '580', '152', 'Bairro no.804', '99328337', '108', '5505135512671', '705', '5505155474408', 'complemento_804@generico.com', '804');
INSERT INTO END_COMPL_ESTAB
VALUES ('7', '540', 'Rua 5815', '1463', '176', 'Bairro no.815', '94449889', '595', '5505133849011', '575', '5505152903294', 'complemento_815@generico.com', '815');
INSERT INTO END_COMPL_ESTAB
VALUES ('8', '186', 'Rua 5190', '1112', '142', 'Bairro no.190', '90898243', '756', '5505138767702', '922', '5505158424601', 'complemento_190@generico.com', '190');
INSERT INTO END_COMPL_ESTAB
VALUES ('9', '923', 'Rua 5899', '1040', '211', 'Bairro no.899', '92756340', '810', '5505138494858', '894', '5505155898011', 'complemento_899@generico.com', '899');
INSERT INTO END_COMPL_ESTAB
VALUES ('10', '579', 'Rua 5950', '950', '298', 'Bairro no.950', '99169411', '792', '5505130823729', '612', '5505154864441', 'complemento_950@generico.com', '950');
INSERT INTO END_COMPL_ESTAB
VALUES ('11', '845', 'Rua 5631', '743', '35', 'Bairro no.631', '92204605', '793', '5505133325361', '815', '5505151006075', 'complemento_631@generico.com', '631');
INSERT INTO END_COMPL_ESTAB
VALUES ('12', '697', 'Rua 5147', '545', '273', 'Bairro no.147', '95341979', '679', '5505130266967', '634', '5505156063383', 'complemento_147@generico.com', '147');
INSERT INTO END_COMPL_ESTAB
VALUES ('13', '391', 'Rua 5576', '870', '10', 'Bairro no.576', '90216365', '960', '5505131849719', '123', '5505152105764', 'complemento_576@generico.com', '576');
INSERT INTO END_COMPL_ESTAB
VALUES ('14', '936', 'Rua 5801', '522', '30', 'Bairro no.801', '92599198', '220', '5505136469256', '349', '5505151803178', 'complemento_801@generico.com', '801');
INSERT INTO END_COMPL_ESTAB
VALUES ('15', '39', 'Rua 5504', '600', '', 'Bairro no.504', '91993557', '358', '5505137315982', '837', '5505159184819', 'complemento_504@generico.com', '504');
INSERT INTO END_COMPL_ESTAB
VALUES ('16', '672', 'Rua 5170', '1466', '202', 'Bairro no.170', '98454245', '341', '5505132506873', '596', '5505154423139', 'complemento_170@generico.com', '170');
INSERT INTO END_COMPL_ESTAB
VALUES ('17', '471', 'Rua 5175', '909', '152', 'Bairro no.175', '93114459', '356', '5505138376610', '250', '5505155606001', 'complemento_175@generico.com', '175');
INSERT INTO END_COMPL_ESTAB
VALUES ('18', '741', 'Rua 5013', '835', '84', 'Bairro no.13', '92401303', '952', '5505133522255', '287', '5505153592011', 'complemento_13@generico.com', '13');
INSERT INTO END_COMPL_ESTAB
VALUES ('19', '633', 'Rua 5947', '1121', '', 'Bairro no.947', '93880171', '414', '5505136508327', '1', '5505151923095', 'complemento_947@generico.com', '947');
INSERT INTO END_COMPL_ESTAB
VALUES ('20', '239', 'Rua 5335', '1137', '262', 'Bairro no.335', '95681513', '413', '5505134022670', '701', '5505154182265', 'complemento_335@generico.com', '335');
INSERT INTO END_COMPL_ESTAB
VALUES ('21', '46', 'Rua 5663', '945', '47', 'Bairro no.663', '95275730', '486', '5505135614048', '754', '5505158838750', 'complemento_663@generico.com', '663');
INSERT INTO END_COMPL_ESTAB
VALUES ('22', '312', 'Rua 5495', '966', '262', 'Bairro no.495', '98124148', '187', '5505139994202', '632', '5505150834670', 'complemento_495@generico.com', '495');
INSERT INTO END_COMPL_ESTAB
VALUES ('23', '986', 'Rua 5726', '901', '94', 'Bairro no.726', '92135246', '716', '5505130023575', '821', '5505155283459', 'complemento_726@generico.com', '726');
INSERT INTO END_COMPL_ESTAB
VALUES ('24', '118', 'Rua 5098', '1149', '83', 'Bairro no.98', '99785150', '100', '5505138539380', '396', '5505150813454', 'complemento_98@generico.com', '98');
INSERT INTO END_COMPL_ESTAB
VALUES ('25', '452', 'Rua 5275', '1292', '40', 'Bairro no.275', '95208654', '650', '5505133470529', '870', '5505152784097', 'complemento_275@generico.com', '275');
INSERT INTO END_COMPL_ESTAB
VALUES ('26', '40', 'Rua 5019', '1180', '283', 'Bairro no.19', '99384387', '908', '5505130420045', '748', '5505157013247', 'complemento_19@generico.com', '19');
INSERT INTO END_COMPL_ESTAB
VALUES ('27', '712', 'Rua 5656', '1402', '111', 'Bairro no.656', '95379287', '207', '5505135871254', '8', '5505151510231', 'complemento_656@generico.com', '656');
INSERT INTO END_COMPL_ESTAB
VALUES ('28', '789', 'Rua 5334', '1218', '', 'Bairro no.334', '96205380', '41', '5505131638605', '980', '5505152895308', 'complemento_334@generico.com', '334');
INSERT INTO END_COMPL_ESTAB
VALUES ('29', '548', 'Rua 5395', '793', '71', 'Bairro no.395', '90482563', '179', '5505135230501', '70', '5505154031691', 'complemento_395@generico.com', '395');
INSERT INTO END_COMPL_ESTAB
VALUES ('30', '414', 'Rua 5329', '599', '142', 'Bairro no.329', '98408482', '975', '5505133436515', '478', '5505156995952', 'complemento_329@generico.com', '329');
INSERT INTO END_COMPL_ESTAB
VALUES ('31', '301', 'Rua 5427', '1234', '275', 'Bairro no.427', '96267419', '375', '5505139745604', '638', '5505150658346', 'complemento_427@generico.com', '427');
INSERT INTO END_COMPL_ESTAB
VALUES ('32', '749', 'Rua 5085', '561', '118', 'Bairro no.85', '95190036', '448', '5505134886187', '584', '5505156793024', 'complemento_85@generico.com', '85');
INSERT INTO END_COMPL_ESTAB
VALUES ('33', '368', 'Rua 5424', '1488', '', 'Bairro no.424', '97771000', '430', '5505133585203', '63', '5505158635788', 'complemento_424@generico.com', '424');
INSERT INTO END_COMPL_ESTAB
VALUES ('34', '903', 'Rua 5703', '951', '', 'Bairro no.703', '91189102', '397', '5505132072319', '42', '5505159479612', 'complemento_703@generico.com', '703');
INSERT INTO END_COMPL_ESTAB
VALUES ('35', '146', 'Rua 5216', '697', '163', 'Bairro no.216', '91513343', '987', '5505139829891', '148', '5505154059068', 'complemento_216@generico.com', '216');
INSERT INTO END_COMPL_ESTAB
VALUES ('36', '877', 'Rua 5680', '995', '96', 'Bairro no.680', '94984408', '498', '5505136700680', '201', '5505156097705', 'complemento_680@generico.com', '680');
INSERT INTO END_COMPL_ESTAB
VALUES ('37', '340', 'Rua 5219', '1462', '245', 'Bairro no.219', '90354682', '148', '5505132568818', '783', '5505158423332', 'complemento_219@generico.com', '219');
INSERT INTO END_COMPL_ESTAB
VALUES ('38', '718', 'Rua 5583', '1307', '25', 'Bairro no.583', '98688952', '39', '5505132250906', '40', '5505150152851', 'complemento_583@generico.com', '583');
INSERT INTO END_COMPL_ESTAB
VALUES ('39', '330', 'Rua 5844', '660', '196', 'Bairro no.844', '99685981', '504', '5505139010903', '501', '5505155738724', 'complemento_844@generico.com', '844');
INSERT INTO END_COMPL_ESTAB
VALUES ('40', '805', 'Rua 5679', '1257', '224', 'Bairro no.679', '99057806', '205', '5505135354162', '598', '5505158256965', 'complemento_679@generico.com', '679');
INSERT INTO END_COMPL_ESTAB
VALUES ('41', '791', 'Rua 5483', '888', '255', 'Bairro no.483', '97980593', '656', '5505130002406', '181', '5505155068577', 'complemento_483@generico.com', '483');
INSERT INTO END_COMPL_ESTAB
VALUES ('42', '65', 'Rua 5255', '1359', '90', 'Bairro no.255', '94080731', '809', '5505130622587', '640', '5505151273208', 'complemento_255@generico.com', '255');
INSERT INTO END_COMPL_ESTAB
VALUES ('43', '829', 'Rua 5288', '555', '125', 'Bairro no.288', '94918309', '862', '5505137171886', '672', '5505151513737', 'complemento_288@generico.com', '288');
INSERT INTO END_COMPL_ESTAB
VALUES ('44', '411', 'Rua 5987', '1111', '14', 'Bairro no.987', '94708891', '151', '5505130324654', '616', '5505156299662', 'complemento_987@generico.com', '987');
INSERT INTO END_COMPL_ESTAB
VALUES ('45', '549', 'Rua 5106', '846', '232', 'Bairro no.106', '94903196', '880', '5505136101196', '466', '5505156323125', 'complemento_106@generico.com', '106');
INSERT INTO END_COMPL_ESTAB
VALUES ('46', '124', 'Rua 5338', '1182', '236', 'Bairro no.338', '91271091', '910', '5505137993411', '915', '5505158725346', 'complemento_338@generico.com', '338');
INSERT INTO END_COMPL_ESTAB
VALUES ('47', '810', 'Rua 5682', '1019', '56', 'Bairro no.682', '97821140', '444', '5505137566161', '455', '5505157895586', 'complemento_682@generico.com', '682');
INSERT INTO END_COMPL_ESTAB
VALUES ('48', '44', 'Rua 5076', '1434', '270', 'Bairro no.76', '99447831', '665', '5505135717967', '215', '5505150934762', 'complemento_76@generico.com', '76');
INSERT INTO END_COMPL_ESTAB
VALUES ('49', '888', 'Rua 5820', '1279', '126', 'Bairro no.820', '93053115', '113', '5505134259702', '565', '5505159228804', 'complemento_820@generico.com', '820');
INSERT INTO END_COMPL_ESTAB
VALUES ('50', '415', 'Rua 5936', '599', '220', 'Bairro no.936', '90307008', '446', '5505136864180', '30', '5505159192822', 'complemento_936@generico.com', '936');
INSERT INTO END_COMPL_ESTAB
VALUES ('51', '722', 'Rua 5963', '578', '107', 'Bairro no.963', '90293775', '347', '5505130099642', '973', '5505158190066', 'complemento_963@generico.com', '963');
INSERT INTO END_COMPL_ESTAB
VALUES ('52', '893', 'Rua 5071', '707', '202', 'Bairro no.71', '99382621', '123', '5505130071845', '368', '5505150246500', 'complemento_71@generico.com', '71');
INSERT INTO END_COMPL_ESTAB
VALUES ('53', '859', 'Rua 5605', '686', '103', 'Bairro no.605', '99591714', '130', '5505139665191', '361', '5505154733703', 'complemento_605@generico.com', '605');
INSERT INTO END_COMPL_ESTAB
VALUES ('54', '937', 'Rua 5293', '1458', '55', 'Bairro no.293', '99929516', '102', '5505135808493', '156', '5505158976752', 'complemento_293@generico.com', '293');
INSERT INTO END_COMPL_ESTAB
VALUES ('55', '804', 'Rua 5946', '815', '226', 'Bairro no.946', '92910594', '419', '5505130462556', '132', '5505150205496', 'complemento_946@generico.com', '946');
INSERT INTO END_COMPL_ESTAB
VALUES ('56', '73', 'Rua 5078', '920', '222', 'Bairro no.78', '91422834', '421', '5505136369659', '84', '5505154448111', 'complemento_78@generico.com', '78');
INSERT INTO END_COMPL_ESTAB
VALUES ('57', '948', 'Rua 5370', '557', '125', 'Bairro no.370', '97281804', '320', '5505132039902', '293', '5505154708874', 'complemento_370@generico.com', '370');
INSERT INTO END_COMPL_ESTAB
VALUES ('58', '796', 'Rua 5951', '776', '206', 'Bairro no.951', '97956570', '445', '5505133987768', '766', '5505154317164', 'complemento_951@generico.com', '951');
INSERT INTO END_COMPL_ESTAB
VALUES ('59', '453', 'Rua 5248', '1437', '138', 'Bairro no.248', '96373034', '482', '5505132036398', '1', '5505156989916', 'complemento_248@generico.com', '248');
INSERT INTO END_COMPL_ESTAB
VALUES ('60', '7', 'Rua 5619', '798', '188', 'Bairro no.619', '95452080', '156', '5505137062939', '470', '5505156781786', 'complemento_619@generico.com', '619');
INSERT INTO END_COMPL_ESTAB
VALUES ('61', '232', 'Rua 5761', '1261', '295', 'Bairro no.761', '91208315', '882', '5505130405471', '256', '5505155261018', 'complemento_761@generico.com', '761');
INSERT INTO END_COMPL_ESTAB
VALUES ('62', '396', 'Rua 5582', '602', '85', 'Bairro no.582', '97552227', '907', '5505135954098', '35', '5505157922363', 'complemento_582@generico.com', '582');
INSERT INTO END_COMPL_ESTAB
VALUES ('63', '339', 'Rua 5306', '1030', '275', 'Bairro no.306', '91635547', '414', '5505132896919', '519', '5505155739817', 'complemento_306@generico.com', '306');
INSERT INTO END_COMPL_ESTAB
VALUES ('64', '531', 'Rua 5628', '910', '121', 'Bairro no.628', '97785501', '787', '5505132922541', '371', '5505156288108', 'complemento_628@generico.com', '628');
INSERT INTO END_COMPL_ESTAB
VALUES ('65', '697', 'Rua 5158', '881', '41', 'Bairro no.158', '96682583', '353', '5505134726655', '414', '5505154767152', 'complemento_158@generico.com', '158');
INSERT INTO END_COMPL_ESTAB
VALUES ('66', '318', 'Rua 5695', '1152', '90', 'Bairro no.695', '97452096', '52', '5505136211421', '25', '5505154715288', 'complemento_695@generico.com', '695');
INSERT INTO END_COMPL_ESTAB
VALUES ('67', '10', 'Rua 5889', '1026', '260', 'Bairro no.889', '96862964', '741', '5505136690075', '6', '5505150411778', 'complemento_889@generico.com', '889');
INSERT INTO END_COMPL_ESTAB
VALUES ('68', '999', 'Rua 5621', '1373', '218', 'Bairro no.621', '92266869', '750', '5505132879240', '105', '5505154608948', 'complemento_621@generico.com', '621');
INSERT INTO END_COMPL_ESTAB
VALUES ('69', '168', 'Rua 5331', '921', '', 'Bairro no.331', '94352702', '446', '5505137088276', '523', '5505151292230', 'complemento_331@generico.com', '331');
INSERT INTO END_COMPL_ESTAB
VALUES ('70', '444', 'Rua 5911', '1289', '242', 'Bairro no.911', '93895363', '219', '5505131961946', '939', '5505155865301', 'complemento_911@generico.com', '911');
INSERT INTO END_COMPL_ESTAB
VALUES ('71', '388', 'Rua 5050', '734', '56', 'Bairro no.50', '90569904', '637', '5505131733738', '610', '5505156125066', 'complemento_50@generico.com', '50');
INSERT INTO END_COMPL_ESTAB
VALUES ('72', '512', 'Rua 5705', '784', '105', 'Bairro no.705', '94582942', '631', '5505135161242', '955', '5505159547175', 'complemento_705@generico.com', '705');
INSERT INTO END_COMPL_ESTAB
VALUES ('73', '934', 'Rua 5930', '1080', '211', 'Bairro no.930', '92154195', '265', '5505130438072', '162', '5505150038745', 'complemento_930@generico.com', '930');
INSERT INTO END_COMPL_ESTAB
VALUES ('74', '140', 'Rua 5655', '1286', '291', 'Bairro no.655', '93965144', '920', '5505134537041', '339', '5505151023388', 'complemento_655@generico.com', '655');
INSERT INTO END_COMPL_ESTAB
VALUES ('75', '794', 'Rua 5883', '822', '', 'Bairro no.883', '93251434', '28', '5505130443525', '368', '5505152095913', 'complemento_883@generico.com', '883');
INSERT INTO END_COMPL_ESTAB
VALUES ('76', '187', 'Rua 5525', '701', '220', 'Bairro no.525', '93122320', '859', '5505132546391', '343', '5505157124803', 'complemento_525@generico.com', '525');
INSERT INTO END_COMPL_ESTAB
VALUES ('77', '934', 'Rua 5045', '572', '217', 'Bairro no.45', '90474685', '808', '5505139788932', '460', '5505151181236', 'complemento_45@generico.com', '45');
INSERT INTO END_COMPL_ESTAB
VALUES ('78', '98', 'Rua 5082', '1265', '275', 'Bairro no.82', '94406397', '77', '5505134269355', '754', '5505158293383', 'complemento_82@generico.com', '82');
INSERT INTO END_COMPL_ESTAB
VALUES ('79', '180', 'Rua 5040', '990', '261', 'Bairro no.40', '99344607', '319', '5505134348436', '556', '5505152855057', 'complemento_40@generico.com', '40');
INSERT INTO END_COMPL_ESTAB
VALUES ('80', '201', 'Rua 5542', '796', '181', 'Bairro no.542', '95361649', '260', '5505132317878', '118', '5505157834935', 'complemento_542@generico.com', '542');
INSERT INTO END_COMPL_ESTAB
VALUES ('81', '732', 'Rua 5099', '748', '220', 'Bairro no.99', '96596207', '741', '5505135152830', '858', '5505151217938', 'complemento_99@generico.com', '99');
INSERT INTO END_COMPL_ESTAB
VALUES ('82', '118', 'Rua 5646', '1237', '202', 'Bairro no.646', '97034838', '659', '5505132215579', '830', '5505152401360', 'complemento_646@generico.com', '646');
INSERT INTO END_COMPL_ESTAB
VALUES ('83', '674', 'Rua 5519', '733', '86', 'Bairro no.519', '91713823', '808', '5505135531227', '327', '5505155854308', 'complemento_519@generico.com', '519');
INSERT INTO END_COMPL_ESTAB
VALUES ('84', '129', 'Rua 5026', '895', '', 'Bairro no.26', '95104744', '76', '5505137650405', '780', '5505157748020', 'complemento_26@generico.com', '26');
INSERT INTO END_COMPL_ESTAB
VALUES ('85', '695', 'Rua 5570', '713', '244', 'Bairro no.570', '97599664', '353', '5505135910279', '628', '5505159008097', 'complemento_570@generico.com', '570');
INSERT INTO END_COMPL_ESTAB
VALUES ('86', '833', 'Rua 5109', '1026', '136', 'Bairro no.109', '90126354', '219', '5505136527633', '660', '5505154946988', 'complemento_109@generico.com', '109');
INSERT INTO END_COMPL_ESTAB
VALUES ('87', '480', 'Rua 5954', '813', '77', 'Bairro no.954', '96043059', '702', '5505138216962', '784', '5505153840922', 'complemento_954@generico.com', '954');
INSERT INTO END_COMPL_ESTAB
VALUES ('88', '38', 'Rua 5060', '1226', '102', 'Bairro no.60', '94411950', '725', '5505136578311', '259', '5505156715847', 'complemento_60@generico.com', '60');
INSERT INTO END_COMPL_ESTAB
VALUES ('89', '356', 'Rua 5305', '1039', '45', 'Bairro no.305', '90219872', '627', '5505130245646', '44', '5505152257755', 'complemento_305@generico.com', '305');
INSERT INTO END_COMPL_ESTAB
VALUES ('90', '66', 'Rua 5654', '562', '126', 'Bairro no.654', '98924288', '216', '5505134352131', '357', '5505151769355', 'complemento_654@generico.com', '654');
INSERT INTO END_COMPL_ESTAB
VALUES ('91', '986', 'Rua 5329', '1247', '122', 'Bairro no.329', '92637408', '530', '5505137356368', '685', '5505154626497', 'complemento_329@generico.com', '329');
INSERT INTO END_COMPL_ESTAB
VALUES ('92', '921', 'Rua 5042', '908', '', 'Bairro no.42', '90031101', '138', '5505138688533', '513', '5505157324347', 'complemento_42@generico.com', '42');
INSERT INTO END_COMPL_ESTAB
VALUES ('93', '330', 'Rua 5149', '1340', '74', 'Bairro no.149', '90219753', '805', '5505131688439', '786', '5505156836591', 'complemento_149@generico.com', '149');
INSERT INTO END_COMPL_ESTAB
VALUES ('94', '78', 'Rua 5169', '1427', '186', 'Bairro no.169', '94575117', '149', '5505136019698', '252', '5505158058945', 'complemento_169@generico.com', '169');
INSERT INTO END_COMPL_ESTAB
VALUES ('95', '27', 'Rua 5733', '1432', '26', 'Bairro no.733', '92927345', '150', '5505132361450', '355', '5505157354996', 'complemento_733@generico.com', '733');
INSERT INTO END_COMPL_ESTAB
VALUES ('96', '269', 'Rua 5405', '992', '93', 'Bairro no.405', '99005415', '549', '5505139773274', '772', '5505155704992', 'complemento_405@generico.com', '405');
INSERT INTO END_COMPL_ESTAB
VALUES ('97', '686', 'Rua 5263', '955', '121', 'Bairro no.263', '94960049', '20', '5505137399584', '34', '5505156807253', 'complemento_263@generico.com', '263');
INSERT INTO END_COMPL_ESTAB
VALUES ('98', '775', 'Rua 5583', '789', '62', 'Bairro no.583', '95292719', '339', '5505139784544', '970', '5505152089697', 'complemento_583@generico.com', '583');
INSERT INTO END_COMPL_ESTAB
VALUES ('99', '329', 'Rua 5567', '1468', '175', 'Bairro no.567', '97200843', '680', '5505133533555', '915', '5505158994534', 'complemento_567@generico.com', '567');
INSERT INTO END_COMPL_ESTAB
VALUES ('100', '747', 'Rua 5331', '509', '169', 'Bairro no.331', '99523066', '362', '5505136257130', '322', '5505157827853', 'complemento_331@generico.com', '331');
INSERT INTO END_COMPL_ESTAB
VALUES ('101', '987', 'Rua 5601', '501', '13', 'Bairro no.601', '91258478', '928', '5505139486082', '479', '5505159466892', 'complemento_601@generico.com', '601');
INSERT INTO END_COMPL_ESTAB
VALUES ('102', '778', 'Rua 5819', '1247', '164', 'Bairro no.819', '94238791', '948', '5505131738335', '169', '5505156588616', 'complemento_819@generico.com', '819');
INSERT INTO END_COMPL_ESTAB
VALUES ('103', '110', 'Rua 5158', '1003', '181', 'Bairro no.158', '97547538', '265', '5505132849628', '428', '5505159908477', 'complemento_158@generico.com', '158');
INSERT INTO END_COMPL_ESTAB
VALUES ('104', '946', 'Rua 5718', '1037', '297', 'Bairro no.718', '91899882', '781', '5505137915137', '843', '5505157500526', 'complemento_718@generico.com', '718');
INSERT INTO END_COMPL_ESTAB
VALUES ('105', '661', 'Rua 5156', '1423', '108', 'Bairro no.156', '99495200', '561', '5505134116363', '613', '5505158041249', 'complemento_156@generico.com', '156');
INSERT INTO END_COMPL_ESTAB
VALUES ('106', '15', 'Rua 5229', '1029', '204', 'Bairro no.229', '96309079', '627', '5505134969896', '730', '5505152491944', 'complemento_229@generico.com', '229');
INSERT INTO END_COMPL_ESTAB
VALUES ('107', '274', 'Rua 5892', '1444', '23', 'Bairro no.892', '94481796', '743', '5505134496540', '508', '5505158068238', 'complemento_892@generico.com', '892');
INSERT INTO END_COMPL_ESTAB
VALUES ('108', '958', 'Rua 5705', '664', '', 'Bairro no.705', '99279861', '634', '5505139403907', '252', '5505158817871', 'complemento_705@generico.com', '705');
INSERT INTO END_COMPL_ESTAB
VALUES ('109', '609', 'Rua 5774', '590', '3', 'Bairro no.774', '92505580', '761', '5505133866249', '774', '5505156256424', 'complemento_774@generico.com', '774');
INSERT INTO END_COMPL_ESTAB
VALUES ('110', '880', 'Rua 5390', '538', '248', 'Bairro no.390', '91268134', '709', '5505133281158', '24', '5505154737248', 'complemento_390@generico.com', '390');
INSERT INTO END_COMPL_ESTAB
VALUES ('111', '41', 'Rua 5522', '1065', '1', 'Bairro no.522', '91907733', '110', '5505135406219', '43', '5505159281324', 'complemento_522@generico.com', '522');
INSERT INTO END_COMPL_ESTAB
VALUES ('112', '945', 'Rua 5846', '814', '295', 'Bairro no.846', '97647313', '274', '5505136708892', '595', '5505154042032', 'complemento_846@generico.com', '846');
INSERT INTO END_COMPL_ESTAB
VALUES ('113', '59', 'Rua 5307', '625', '144', 'Bairro no.307', '96418933', '763', '5505130467137', '822', '5505150434712', 'complemento_307@generico.com', '307');
INSERT INTO END_COMPL_ESTAB
VALUES ('114', '744', 'Rua 5555', '1131', '', 'Bairro no.555', '93446983', '585', '5505130827990', '559', '5505158132987', 'complemento_555@generico.com', '555');
INSERT INTO END_COMPL_ESTAB
VALUES ('115', '260', 'Rua 5202', '1200', '77', 'Bairro no.202', '99355151', '997', '5505131551984', '899', '5505155527264', 'complemento_202@generico.com', '202');
INSERT INTO END_COMPL_ESTAB
VALUES ('116', '585', 'Rua 5039', '1141', '227', 'Bairro no.39', '98178000', '71', '5505136483998', '456', '5505152387212', 'complemento_39@generico.com', '39');
INSERT INTO END_COMPL_ESTAB
VALUES ('117', '159', 'Rua 5459', '833', '142', 'Bairro no.459', '95559200', '542', '5505138205941', '343', '5505158129620', 'complemento_459@generico.com', '459');
INSERT INTO END_COMPL_ESTAB
VALUES ('118', '427', 'Rua 5080', '852', '250', 'Bairro no.80', '95123993', '986', '5505138614606', '118', '5505153168915', 'complemento_80@generico.com', '80');
INSERT INTO END_COMPL_ESTAB
VALUES ('119', '733', 'Rua 5023', '519', '58', 'Bairro no.23', '94138362', '61', '5505133112548', '389', '5505150522309', 'complemento_23@generico.com', '23');
INSERT INTO END_COMPL_ESTAB
VALUES ('120', '711', 'Rua 5768', '857', '23', 'Bairro no.768', '90540063', '354', '5505139018412', '755', '5505156723176', 'complemento_768@generico.com', '768');
INSERT INTO END_COMPL_ESTAB
VALUES ('121', '803', 'Rua 5563', '912', '240', 'Bairro no.563', '91904934', '387', '5505133576093', '123', '5505153507843', 'complemento_563@generico.com', '563');
INSERT INTO END_COMPL_ESTAB
VALUES ('122', '616', 'Rua 5178', '1153', '', 'Bairro no.178', '94564758', '553', '5505138716629', '495', '5505150804504', 'complemento_178@generico.com', '178');
INSERT INTO END_COMPL_ESTAB
VALUES ('123', '862', 'Rua 5052', '1290', '', 'Bairro no.52', '92622426', '647', '5505130957180', '825', '5505153336129', 'complemento_52@generico.com', '52');
INSERT INTO END_COMPL_ESTAB
VALUES ('124', '471', 'Rua 5956', '533', '187', 'Bairro no.956', '92870812', '36', '5505133766863', '156', '5505155482802', 'complemento_956@generico.com', '956');
INSERT INTO END_COMPL_ESTAB
VALUES ('125', '174', 'Rua 5147', '1420', '72', 'Bairro no.147', '98788961', '624', '5505139455992', '482', '5505158879007', 'complemento_147@generico.com', '147');
INSERT INTO END_COMPL_ESTAB
VALUES ('126', '44', 'Rua 5679', '740', '51', 'Bairro no.679', '92381869', '225', '5505138783436', '462', '5505158765117', 'complemento_679@generico.com', '679');
INSERT INTO END_COMPL_ESTAB
VALUES ('127', '564', 'Rua 5138', '513', '1', 'Bairro no.138', '93899076', '800', '5505139998814', '19', '5505158240854', 'complemento_138@generico.com', '138');
INSERT INTO END_COMPL_ESTAB
VALUES ('128', '38', 'Rua 5511', '1277', '183', 'Bairro no.511', '97783251', '672', '5505133798742', '26', '5505154362639', 'complemento_511@generico.com', '511');
INSERT INTO END_COMPL_ESTAB
VALUES ('129', '332', 'Rua 5914', '747', '153', 'Bairro no.914', '95333482', '72', '5505134077584', '658', '5505159660505', 'complemento_914@generico.com', '914');
INSERT INTO END_COMPL_ESTAB
VALUES ('130', '436', 'Rua 5432', '971', '118', 'Bairro no.432', '96452646', '396', '5505135813756', '834', '5505159979674', 'complemento_432@generico.com', '432');
INSERT INTO END_COMPL_ESTAB
VALUES ('131', '371', 'Rua 5886', '521', '', 'Bairro no.886', '94745506', '236', '5505130403040', '321', '5505157980712', 'complemento_886@generico.com', '886');
INSERT INTO END_COMPL_ESTAB
VALUES ('132', '106', 'Rua 5965', '1377', '214', 'Bairro no.965', '90267957', '420', '5505138702307', '392', '5505159245642', 'complemento_965@generico.com', '965');
INSERT INTO END_COMPL_ESTAB
VALUES ('133', '604', 'Rua 5714', '661', '123', 'Bairro no.714', '95902048', '995', '5505132837097', '503', '5505159334478', 'complemento_714@generico.com', '714');
INSERT INTO END_COMPL_ESTAB
VALUES ('134', '628', 'Rua 5346', '1266', '226', 'Bairro no.346', '91956929', '956', '5505131768977', '583', '5505152960425', 'complemento_346@generico.com', '346');
INSERT INTO END_COMPL_ESTAB
VALUES ('135', '291', 'Rua 5635', '931', '80', 'Bairro no.635', '97278758', '346', '5505131321560', '612', '5505151657580', 'complemento_635@generico.com', '635');
INSERT INTO END_COMPL_ESTAB
VALUES ('136', '398', 'Rua 5431', '576', '204', 'Bairro no.431', '97777949', '544', '5505135539167', '169', '5505152074638', 'complemento_431@generico.com', '431');
INSERT INTO END_COMPL_ESTAB
VALUES ('137', '525', 'Rua 5229', '1318', '264', 'Bairro no.229', '97358781', '715', '5505133351720', '118', '5505159627903', 'complemento_229@generico.com', '229');
INSERT INTO END_COMPL_ESTAB
VALUES ('138', '408', 'Rua 5855', '1363', '102', 'Bairro no.855', '95015614', '331', '5505136951574', '911', '5505159845440', 'complemento_855@generico.com', '855');
INSERT INTO END_COMPL_ESTAB
VALUES ('139', '305', 'Rua 5744', '1380', '103', 'Bairro no.744', '99487122', '511', '5505139646353', '994', '5505158129420', 'complemento_744@generico.com', '744');
INSERT INTO END_COMPL_ESTAB
VALUES ('140', '154', 'Rua 5684', '504', '211', 'Bairro no.684', '99355379', '516', '5505136968465', '646', '5505152049201', 'complemento_684@generico.com', '684');
INSERT INTO END_COMPL_ESTAB
VALUES ('141', '981', 'Rua 5645', '611', '184', 'Bairro no.645', '93758546', '792', '5505130104858', '891', '5505158173638', 'complemento_645@generico.com', '645');
INSERT INTO END_COMPL_ESTAB
VALUES ('142', '108', 'Rua 5481', '952', '76', 'Bairro no.481', '94865314', '774', '5505139227317', '561', '5505158272417', 'complemento_481@generico.com', '481');
INSERT INTO END_COMPL_ESTAB
VALUES ('143', '856', 'Rua 5078', '1420', '248', 'Bairro no.78', '98495660', '877', '5505135171394', '607', '5505152080832', 'complemento_78@generico.com', '78');
INSERT INTO END_COMPL_ESTAB
VALUES ('144', '405', 'Rua 5709', '521', '116', 'Bairro no.709', '98851797', '564', '5505139162569', '928', '5505150867949', 'complemento_709@generico.com', '709');
INSERT INTO END_COMPL_ESTAB
VALUES ('145', '334', 'Rua 5589', '1006', '', 'Bairro no.589', '94799432', '101', '5505138331600', '489', '5505156449874', 'complemento_589@generico.com', '589');
INSERT INTO END_COMPL_ESTAB
VALUES ('146', '181', 'Rua 5473', '1041', '255', 'Bairro no.473', '98316039', '143', '5505130688439', '68', '5505153932439', 'complemento_473@generico.com', '473');
INSERT INTO END_COMPL_ESTAB
VALUES ('147', '556', 'Rua 5954', '765', '33', 'Bairro no.954', '91410711', '811', '5505131386334', '863', '5505158229979', 'complemento_954@generico.com', '954');
INSERT INTO END_COMPL_ESTAB
VALUES ('148', '558', 'Rua 5137', '507', '167', 'Bairro no.137', '97553403', '489', '5505136904219', '930', '5505155595457', 'complemento_137@generico.com', '137');
INSERT INTO END_COMPL_ESTAB
VALUES ('149', '343', 'Rua 5875', '597', '67', 'Bairro no.875', '98385867', '311', '5505132246161', '495', '5505159469040', 'complemento_875@generico.com', '875');
INSERT INTO END_COMPL_ESTAB
VALUES ('150', '340', 'Rua 5509', '577', '67', 'Bairro no.509', '93674990', '380', '5505137581842', '231', '5505159358921', 'complemento_509@generico.com', '509');
INSERT INTO END_COMPL_ESTAB
VALUES ('151', '481', 'Rua 5743', '1380', '115', 'Bairro no.743', '91293691', '777', '5505134011926', '499', '5505154709686', 'complemento_743@generico.com', '743');
INSERT INTO END_COMPL_ESTAB
VALUES ('152', '373', 'Rua 5657', '1415', '107', 'Bairro no.657', '94008780', '765', '5505139930564', '865', '5505154797274', 'complemento_657@generico.com', '657');
INSERT INTO END_COMPL_ESTAB
VALUES ('153', '445', 'Rua 5292', '844', '56', 'Bairro no.292', '99558756', '498', '5505131099748', '383', '5505153887168', 'complemento_292@generico.com', '292');
INSERT INTO END_COMPL_ESTAB
VALUES ('154', '980', 'Rua 5514', '1476', '185', 'Bairro no.514', '96756290', '501', '5505134866780', '314', '5505156839216', 'complemento_514@generico.com', '514');
INSERT INTO END_COMPL_ESTAB
VALUES ('155', '317', 'Rua 5092', '1390', '290', 'Bairro no.92', '99841696', '574', '5505130404359', '93', '5505152003016', 'complemento_92@generico.com', '92');
INSERT INTO END_COMPL_ESTAB
VALUES ('156', '113', 'Rua 5327', '1297', '', 'Bairro no.327', '92337336', '43', '5505133826718', '4', '5505151164914', 'complemento_327@generico.com', '327');
INSERT INTO END_COMPL_ESTAB
VALUES ('157', '934', 'Rua 5605', '699', '', 'Bairro no.605', '91977055', '1', '5505138965379', '845', '5505150667787', 'complemento_605@generico.com', '605');
INSERT INTO END_COMPL_ESTAB
VALUES ('158', '234', 'Rua 5178', '1428', '242', 'Bairro no.178', '94358134', '380', '5505137653479', '615', '5505152693176', 'complemento_178@generico.com', '178');
INSERT INTO END_COMPL_ESTAB
VALUES ('159', '703', 'Rua 5583', '1327', '192', 'Bairro no.583', '95959022', '91', '5505139451889', '714', '5505152728711', 'complemento_583@generico.com', '583');
INSERT INTO END_COMPL_ESTAB
VALUES ('160', '620', 'Rua 5693', '1158', '171', 'Bairro no.693', '96600271', '201', '5505135080121', '120', '5505151055304', 'complemento_693@generico.com', '693');
INSERT INTO END_COMPL_ESTAB
VALUES ('161', '124', 'Rua 5912', '1393', '136', 'Bairro no.912', '93398152', '415', '5505133772323', '564', '5505153355932', 'complemento_912@generico.com', '912');
INSERT INTO END_COMPL_ESTAB
VALUES ('162', '233', 'Rua 5822', '748', '280', 'Bairro no.822', '90239156', '722', '5505130060065', '404', '5505157642071', 'complemento_822@generico.com', '822');
INSERT INTO END_COMPL_ESTAB
VALUES ('163', '429', 'Rua 5447', '753', '68', 'Bairro no.447', '92835212', '652', '5505135994469', '928', '5505159688689', 'complemento_447@generico.com', '447');
INSERT INTO END_COMPL_ESTAB
VALUES ('164', '87', 'Rua 5523', '799', '201', 'Bairro no.523', '99461971', '154', '5505130366846', '869', '5505158051642', 'complemento_523@generico.com', '523');
INSERT INTO END_COMPL_ESTAB
VALUES ('165', '468', 'Rua 5766', '1177', '57', 'Bairro no.766', '93908937', '786', '5505138018555', '960', '5505158876670', 'complemento_766@generico.com', '766');
INSERT INTO END_COMPL_ESTAB
VALUES ('166', '520', 'Rua 5683', '1223', '276', 'Bairro no.683', '97125765', '593', '5505134340416', '632', '5505156176786', 'complemento_683@generico.com', '683');
INSERT INTO END_COMPL_ESTAB
VALUES ('167', '570', 'Rua 5899', '713', '72', 'Bairro no.899', '99049500', '842', '5505135558190', '196', '5505150435420', 'complemento_899@generico.com', '899');
INSERT INTO END_COMPL_ESTAB
VALUES ('168', '443', 'Rua 5135', '1174', '205', 'Bairro no.135', '98619492', '756', '5505134255274', '645', '5505159883673', 'complemento_135@generico.com', '135');
INSERT INTO END_COMPL_ESTAB
VALUES ('169', '338', 'Rua 5886', '1185', '167', 'Bairro no.886', '93565339', '437', '5505134388988', '662', '5505158459959', 'complemento_886@generico.com', '886');
INSERT INTO END_COMPL_ESTAB
VALUES ('170', '146', 'Rua 5469', '1254', '286', 'Bairro no.469', '93940559', '463', '5505135405956', '891', '5505157042164', 'complemento_469@generico.com', '469');
INSERT INTO END_COMPL_ESTAB
VALUES ('171', '207', 'Rua 5022', '1353', '', 'Bairro no.22', '98739083', '410', '5505132104678', '4', '5505159960508', 'complemento_22@generico.com', '22');
INSERT INTO END_COMPL_ESTAB
VALUES ('172', '642', 'Rua 5137', '989', '161', 'Bairro no.137', '90782835', '969', '5505134927368', '15', '5505154193433', 'complemento_137@generico.com', '137');
INSERT INTO END_COMPL_ESTAB
VALUES ('173', '312', 'Rua 5758', '1245', '', 'Bairro no.758', '92391206', '967', '5505130278887', '862', '5505155126490', 'complemento_758@generico.com', '758');
INSERT INTO END_COMPL_ESTAB
VALUES ('174', '258', 'Rua 5154', '1093', '251', 'Bairro no.154', '92195284', '383', '5505135068131', '339', '5505158241427', 'complemento_154@generico.com', '154');
INSERT INTO END_COMPL_ESTAB
VALUES ('175', '88', 'Rua 5264', '654', '169', 'Bairro no.264', '90632983', '992', '5505134794405', '319', '5505157291623', 'complemento_264@generico.com', '264');
INSERT INTO END_COMPL_ESTAB
VALUES ('176', '434', 'Rua 5025', '1164', '', 'Bairro no.25', '97616377', '884', '5505131189058', '429', '5505150317904', 'complemento_25@generico.com', '25');
INSERT INTO END_COMPL_ESTAB
VALUES ('177', '384', 'Rua 5272', '843', '240', 'Bairro no.272', '91895436', '823', '5505135419210', '338', '5505155522357', 'complemento_272@generico.com', '272');
INSERT INTO END_COMPL_ESTAB
VALUES ('178', '495', 'Rua 5162', '521', '99', 'Bairro no.162', '93440429', '994', '5505136134556', '417', '5505157906566', 'complemento_162@generico.com', '162');
INSERT INTO END_COMPL_ESTAB
VALUES ('179', '570', 'Rua 5068', '1020', '175', 'Bairro no.68', '94852723', '519', '5505137818972', '346', '5505155577893', 'complemento_68@generico.com', '68');
INSERT INTO END_COMPL_ESTAB
VALUES ('180', '995', 'Rua 5708', '1193', '119', 'Bairro no.708', '96087809', '744', '5505133484159', '268', '5505159728330', 'complemento_708@generico.com', '708');
INSERT INTO END_COMPL_ESTAB
VALUES ('181', '999', 'Rua 5349', '1352', '248', 'Bairro no.349', '99836270', '276', '5505136644543', '768', '5505150832819', 'complemento_349@generico.com', '349');
INSERT INTO END_COMPL_ESTAB
VALUES ('182', '308', 'Rua 5820', '1206', '10', 'Bairro no.820', '96117128', '292', '5505131146587', '711', '5505159790464', 'complemento_820@generico.com', '820');
INSERT INTO END_COMPL_ESTAB
VALUES ('183', '346', 'Rua 5513', '949', '159', 'Bairro no.513', '94091757', '80', '5505139794276', '995', '5505151741345', 'complemento_513@generico.com', '513');
INSERT INTO END_COMPL_ESTAB
VALUES ('184', '436', 'Rua 5242', '1198', '250', 'Bairro no.242', '96384333', '269', '5505138708671', '660', '5505153169242', 'complemento_242@generico.com', '242');
INSERT INTO END_COMPL_ESTAB
VALUES ('185', '979', 'Rua 5548', '548', '254', 'Bairro no.548', '96923167', '139', '5505135971495', '785', '5505154185958', 'complemento_548@generico.com', '548');
INSERT INTO END_COMPL_ESTAB
VALUES ('186', '253', 'Rua 5583', '812', '146', 'Bairro no.583', '94488116', '122', '5505133744708', '520', '5505152310123', 'complemento_583@generico.com', '583');
INSERT INTO END_COMPL_ESTAB
VALUES ('187', '383', 'Rua 5808', '738', '247', 'Bairro no.808', '99041433', '959', '5505130151940', '753', '5505155254839', 'complemento_808@generico.com', '808');
INSERT INTO END_COMPL_ESTAB
VALUES ('188', '246', 'Rua 5125', '781', '141', 'Bairro no.125', '99367887', '58', '5505137091692', '853', '5505153572998', 'complemento_125@generico.com', '125');
INSERT INTO END_COMPL_ESTAB
VALUES ('189', '221', 'Rua 5250', '800', '165', 'Bairro no.250', '92503994', '27', '5505132326334', '819', '5505154173701', 'complemento_250@generico.com', '250');
INSERT INTO END_COMPL_ESTAB
VALUES ('190', '943', 'Rua 5884', '743', '', 'Bairro no.884', '98810668', '580', '5505131680002', '247', '5505159876247', 'complemento_884@generico.com', '884');
INSERT INTO END_COMPL_ESTAB
VALUES ('191', '867', 'Rua 5300', '1295', '', 'Bairro no.300', '97219421', '789', '5505138474076', '62', '5505151678098', 'complemento_300@generico.com', '300');
INSERT INTO END_COMPL_ESTAB
VALUES ('192', '212', 'Rua 5506', '1033', '38', 'Bairro no.506', '90859611', '11', '5505138250360', '81', '5505159615652', 'complemento_506@generico.com', '506');
INSERT INTO END_COMPL_ESTAB
VALUES ('193', '745', 'Rua 5984', '950', '123', 'Bairro no.984', '93452932', '395', '5505137261957', '891', '5505151577150', 'complemento_984@generico.com', '984');
INSERT INTO END_COMPL_ESTAB
VALUES ('194', '209', 'Rua 5243', '545', '153', 'Bairro no.243', '90670347', '445', '5505134506107', '777', '5505157613973', 'complemento_243@generico.com', '243');
INSERT INTO END_COMPL_ESTAB
VALUES ('195', '626', 'Rua 5135', '1009', '', 'Bairro no.135', '91477358', '666', '5505133670257', '962', '5505155017503', 'complemento_135@generico.com', '135');
INSERT INTO END_COMPL_ESTAB
VALUES ('196', '133', 'Rua 5689', '979', '250', 'Bairro no.689', '91996074', '396', '5505134735269', '439', '5505154754416', 'complemento_689@generico.com', '689');
INSERT INTO END_COMPL_ESTAB
VALUES ('197', '808', 'Rua 5296', '1413', '191', 'Bairro no.296', '93807058', '578', '5505136955388', '501', '5505156745820', 'complemento_296@generico.com', '296');
INSERT INTO END_COMPL_ESTAB
VALUES ('198', '843', 'Rua 5758', '688', '154', 'Bairro no.758', '95096569', '806', '5505135173833', '899', '5505157776027', 'complemento_758@generico.com', '758');
INSERT INTO END_COMPL_ESTAB
VALUES ('199', '826', 'Rua 5507', '975', '130', 'Bairro no.507', '94562079', '649', '5505130521570', '728', '5505159682326', 'complemento_507@generico.com', '507');
INSERT INTO END_COMPL_ESTAB
VALUES ('200', '68', 'Rua 5459', '701', '76', 'Bairro no.459', '97939070', '1', '5505138735792', '938', '5505151850030', 'complemento_459@generico.com', '459');
INSERT INTO END_COMPL_ESTAB
VALUES ('201', '965', 'Rua 5174', '860', '2', 'Bairro no.174', '99907914', '16', '5505136075705', '927', '5505158312607', 'complemento_174@generico.com', '174');
INSERT INTO END_COMPL_ESTAB
VALUES ('202', '822', 'Rua 5311', '893', '108', 'Bairro no.311', '93547180', '581', '5505137820679', '698', '5505157680778', 'complemento_311@generico.com', '311');
INSERT INTO END_COMPL_ESTAB
VALUES ('203', '531', 'Rua 5015', '852', '', 'Bairro no.15', '99208517', '196', '5505131844749', '178', '5505156580948', 'complemento_15@generico.com', '15');
INSERT INTO END_COMPL_ESTAB
VALUES ('204', '505', 'Rua 5612', '1086', '258', 'Bairro no.612', '99059344', '54', '5505138974126', '31', '5505156476428', 'complemento_612@generico.com', '612');
INSERT INTO END_COMPL_ESTAB
VALUES ('205', '502', 'Rua 5931', '919', '274', 'Bairro no.931', '99259691', '618', '5505137144289', '338', '5505151381747', 'complemento_931@generico.com', '931');
INSERT INTO END_COMPL_ESTAB
VALUES ('206', '657', 'Rua 5980', '774', '182', 'Bairro no.980', '93305850', '894', '5505130779004', '803', '5505151595789', 'complemento_980@generico.com', '980');
INSERT INTO END_COMPL_ESTAB
VALUES ('207', '258', 'Rua 5108', '1214', '126', 'Bairro no.108', '91590461', '922', '5505137662850', '685', '5505158129089', 'complemento_108@generico.com', '108');
INSERT INTO END_COMPL_ESTAB
VALUES ('208', '112', 'Rua 5775', '1273', '224', 'Bairro no.775', '94822772', '685', '5505131000076', '763', '5505152622277', 'complemento_775@generico.com', '775');
INSERT INTO END_COMPL_ESTAB
VALUES ('209', '635', 'Rua 5786', '1009', '22', 'Bairro no.786', '90408979', '14', '5505137755423', '138', '5505151228665', 'complemento_786@generico.com', '786');
INSERT INTO END_COMPL_ESTAB
VALUES ('210', '977', 'Rua 5386', '1385', '245', 'Bairro no.386', '90850777', '391', '5505135792057', '985', '5505150487069', 'complemento_386@generico.com', '386');
INSERT INTO END_COMPL_ESTAB
VALUES ('211', '919', 'Rua 5413', '527', '119', 'Bairro no.413', '95602684', '702', '5505134066953', '891', '5505159557144', 'complemento_413@generico.com', '413');
INSERT INTO END_COMPL_ESTAB
VALUES ('212', '54', 'Rua 5986', '1336', '43', 'Bairro no.986', '99414294', '126', '5505132073140', '954', '5505158307830', 'complemento_986@generico.com', '986');
INSERT INTO END_COMPL_ESTAB
VALUES ('213', '287', 'Rua 5577', '752', '', 'Bairro no.577', '90089934', '635', '5505130515501', '773', '5505150701636', 'complemento_577@generico.com', '577');
INSERT INTO END_COMPL_ESTAB
VALUES ('214', '284', 'Rua 5011', '1272', '', 'Bairro no.11', '95073027', '937', '5505131145170', '331', '5505157403452', 'complemento_11@generico.com', '11');
INSERT INTO END_COMPL_ESTAB
VALUES ('215', '145', 'Rua 5324', '1078', '111', 'Bairro no.324', '92538687', '331', '5505134851821', '535', '5505150843574', 'complemento_324@generico.com', '324');
INSERT INTO END_COMPL_ESTAB
VALUES ('216', '383', 'Rua 5316', '903', '127', 'Bairro no.316', '90740275', '219', '5505136442859', '827', '5505155114405', 'complemento_316@generico.com', '316');
INSERT INTO END_COMPL_ESTAB
VALUES ('217', '70', 'Rua 5149', '655', '169', 'Bairro no.149', '96642571', '523', '5505135652906', '351', '5505156655968', 'complemento_149@generico.com', '149');
INSERT INTO END_COMPL_ESTAB
VALUES ('218', '402', 'Rua 5727', '1314', '271', 'Bairro no.727', '94667482', '344', '5505137772035', '37', '5505153838762', 'complemento_727@generico.com', '727');
INSERT INTO END_COMPL_ESTAB
VALUES ('219', '342', 'Rua 5978', '1012', '23', 'Bairro no.978', '91109517', '434', '5505136190022', '545', '5505155186821', 'complemento_978@generico.com', '978');
INSERT INTO END_COMPL_ESTAB
VALUES ('220', '40', 'Rua 5112', '858', '53', 'Bairro no.112', '92692613', '482', '5505139142071', '946', '5505150013035', 'complemento_112@generico.com', '112');
INSERT INTO END_COMPL_ESTAB
VALUES ('221', '236', 'Rua 5648', '1154', '266', 'Bairro no.648', '96834174', '846', '5505137844798', '160', '5505150436927', 'complemento_648@generico.com', '648');
INSERT INTO END_COMPL_ESTAB
VALUES ('222', '525', 'Rua 5739', '1497', '115', 'Bairro no.739', '92877835', '877', '5505134836957', '912', '5505157071899', 'complemento_739@generico.com', '739');
INSERT INTO END_COMPL_ESTAB
VALUES ('223', '599', 'Rua 5999', '1476', '132', 'Bairro no.999', '95783911', '977', '5505135678797', '864', '5505156285054', 'complemento_999@generico.com', '999');
INSERT INTO END_COMPL_ESTAB
VALUES ('224', '391', 'Rua 5513', '868', '63', 'Bairro no.513', '99625769', '535', '5505138658694', '884', '5505159422997', 'complemento_513@generico.com', '513');
INSERT INTO END_COMPL_ESTAB
VALUES ('225', '337', 'Rua 5239', '1133', '43', 'Bairro no.239', '97598591', '549', '5505135365229', '709', '5505151147402', 'complemento_239@generico.com', '239');
INSERT INTO END_COMPL_ESTAB
VALUES ('226', '479', 'Rua 5922', '1191', '181', 'Bairro no.922', '97099116', '88', '5505134967331', '210', '5505153896838', 'complemento_922@generico.com', '922');
INSERT INTO END_COMPL_ESTAB
VALUES ('227', '353', 'Rua 5512', '906', '12', 'Bairro no.512', '99565934', '603', '5505131635546', '556', '5505150809355', 'complemento_512@generico.com', '512');
INSERT INTO END_COMPL_ESTAB
VALUES ('228', '688', 'Rua 5502', '919', '202', 'Bairro no.502', '99352850', '872', '5505133853681', '862', '5505151150341', 'complemento_502@generico.com', '502');
INSERT INTO END_COMPL_ESTAB
VALUES ('229', '983', 'Rua 5059', '1262', '167', 'Bairro no.59', '93088789', '898', '5505138527503', '481', '5505152203827', 'complemento_59@generico.com', '59');
INSERT INTO END_COMPL_ESTAB
VALUES ('230', '726', 'Rua 5677', '1495', '27', 'Bairro no.677', '99899407', '853', '5505135825238', '330', '5505157329276', 'complemento_677@generico.com', '677');
INSERT INTO END_COMPL_ESTAB
VALUES ('231', '95', 'Rua 5597', '1063', '236', 'Bairro no.597', '98235856', '729', '5505130914784', '587', '5505153913955', 'complemento_597@generico.com', '597');
INSERT INTO END_COMPL_ESTAB
VALUES ('232', '892', 'Rua 5129', '1442', '159', 'Bairro no.129', '98644284', '197', '5505132954839', '907', '5505155903739', 'complemento_129@generico.com', '129');
INSERT INTO END_COMPL_ESTAB
VALUES ('233', '130', 'Rua 5227', '728', '91', 'Bairro no.227', '97344216', '271', '5505130784375', '897', '5505156638392', 'complemento_227@generico.com', '227');
INSERT INTO END_COMPL_ESTAB
VALUES ('234', '181', 'Rua 5975', '1370', '161', 'Bairro no.975', '94797423', '126', '5505138151186', '270', '5505158984340', 'complemento_975@generico.com', '975');
INSERT INTO END_COMPL_ESTAB
VALUES ('235', '852', 'Rua 5700', '1366', '220', 'Bairro no.700', '90040705', '143', '5505132071320', '576', '5505150033746', 'complemento_700@generico.com', '700');
INSERT INTO END_COMPL_ESTAB
VALUES ('236', '484', 'Rua 5128', '541', '65', 'Bairro no.128', '91744070', '316', '5505138812166', '231', '5505156491587', 'complemento_128@generico.com', '128');
INSERT INTO END_COMPL_ESTAB
VALUES ('237', '675', 'Rua 5734', '688', '81', 'Bairro no.734', '95386462', '968', '5505132178725', '551', '5505150654766', 'complemento_734@generico.com', '734');
INSERT INTO END_COMPL_ESTAB
VALUES ('238', '954', 'Rua 5376', '1408', '255', 'Bairro no.376', '97157063', '917', '5505134608154', '422', '5505158961528', 'complemento_376@generico.com', '376');
INSERT INTO END_COMPL_ESTAB
VALUES ('239', '761', 'Rua 5537', '677', '132', 'Bairro no.537', '93270514', '511', '5505133443233', '861', '5505157356048', 'complemento_537@generico.com', '537');
INSERT INTO END_COMPL_ESTAB
VALUES ('240', '125', 'Rua 5384', '1209', '45', 'Bairro no.384', '90347847', '616', '5505135162478', '574', '5505154158611', 'complemento_384@generico.com', '384');
INSERT INTO END_COMPL_ESTAB
VALUES ('241', '391', 'Rua 5469', '587', '36', 'Bairro no.469', '96734885', '748', '5505131679290', '201', '5505152407110', 'complemento_469@generico.com', '469');
INSERT INTO END_COMPL_ESTAB
VALUES ('242', '406', 'Rua 5599', '1387', '157', 'Bairro no.599', '92184938', '90', '5505139247098', '99', '5505151302250', 'complemento_599@generico.com', '599');
INSERT INTO END_COMPL_ESTAB
VALUES ('243', '576', 'Rua 5196', '1139', '118', 'Bairro no.196', '96410272', '261', '5505138004503', '639', '5505156028625', 'complemento_196@generico.com', '196');
INSERT INTO END_COMPL_ESTAB
VALUES ('244', '345', 'Rua 5029', '1268', '193', 'Bairro no.29', '99747196', '440', '5505135179472', '211', '5505150070167', 'complemento_29@generico.com', '29');
INSERT INTO END_COMPL_ESTAB
VALUES ('245', '471', 'Rua 5237', '1104', '87', 'Bairro no.237', '93290444', '719', '5505136642811', '713', '5505158772846', 'complemento_237@generico.com', '237');
INSERT INTO END_COMPL_ESTAB
VALUES ('246', '124', 'Rua 5089', '996', '196', 'Bairro no.89', '92300974', '135', '5505139214357', '239', '5505150178282', 'complemento_89@generico.com', '89');
INSERT INTO END_COMPL_ESTAB
VALUES ('247', '517', 'Rua 5283', '1133', '43', 'Bairro no.283', '95078761', '319', '5505137246834', '359', '5505158111432', 'complemento_283@generico.com', '283');
INSERT INTO END_COMPL_ESTAB
VALUES ('248', '994', 'Rua 5192', '1021', '217', 'Bairro no.192', '93788452', '35', '5505134408763', '287', '5505156612115', 'complemento_192@generico.com', '192');
INSERT INTO END_COMPL_ESTAB
VALUES ('249', '830', 'Rua 5527', '989', '44', 'Bairro no.527', '95726231', '264', '5505132115992', '940', '5505151392962', 'complemento_527@generico.com', '527');
INSERT INTO END_COMPL_ESTAB
VALUES ('250', '536', 'Rua 5917', '1436', '89', 'Bairro no.917', '94701965', '85', '5505133666713', '925', '5505151009996', 'complemento_917@generico.com', '917');
INSERT INTO END_COMPL_ESTAB
VALUES ('251', '42', 'Rua 5246', '1360', '176', 'Bairro no.246', '94656527', '259', '5505135858434', '702', '5505157929995', 'complemento_246@generico.com', '246');
INSERT INTO END_COMPL_ESTAB
VALUES ('252', '625', 'Rua 5163', '1178', '218', 'Bairro no.163', '95177835', '953', '5505136501853', '627', '5505150131577', 'complemento_163@generico.com', '163');
INSERT INTO END_COMPL_ESTAB
VALUES ('253', '601', 'Rua 5144', '1266', '191', 'Bairro no.144', '91543463', '762', '5505138212051', '619', '5505150679138', 'complemento_144@generico.com', '144');
INSERT INTO END_COMPL_ESTAB
VALUES ('254', '269', 'Rua 5280', '967', '', 'Bairro no.280', '95783177', '990', '5505137082470', '141', '5505159791290', 'complemento_280@generico.com', '280');
INSERT INTO END_COMPL_ESTAB
VALUES ('255', '332', 'Rua 5059', '1137', '', 'Bairro no.59', '90221724', '296', '5505132418666', '775', '5505155925538', 'complemento_59@generico.com', '59');
INSERT INTO END_COMPL_ESTAB
VALUES ('256', '872', 'Rua 5144', '712', '262', 'Bairro no.144', '97652162', '420', '5505135192716', '978', '5505157108062', 'complemento_144@generico.com', '144');
INSERT INTO END_COMPL_ESTAB
VALUES ('257', '655', 'Rua 5716', '1488', '89', 'Bairro no.716', '94451579', '635', '5505132369003', '646', '5505159032727', 'complemento_716@generico.com', '716');
INSERT INTO END_COMPL_ESTAB
VALUES ('258', '367', 'Rua 5307', '949', '192', 'Bairro no.307', '90519692', '775', '5505132853422', '621', '5505154238682', 'complemento_307@generico.com', '307');
INSERT INTO END_COMPL_ESTAB
VALUES ('259', '568', 'Rua 5612', '1017', '2', 'Bairro no.612', '91069767', '384', '5505132570974', '484', '5505154708313', 'complemento_612@generico.com', '612');
INSERT INTO END_COMPL_ESTAB
VALUES ('260', '132', 'Rua 5516', '997', '51', 'Bairro no.516', '90155433', '338', '5505137084992', '859', '5505151092679', 'complemento_516@generico.com', '516');
INSERT INTO END_COMPL_ESTAB
VALUES ('261', '310', 'Rua 5032', '1122', '99', 'Bairro no.32', '97793622', '127', '5505136409724', '249', '5505157611781', 'complemento_32@generico.com', '32');
INSERT INTO END_COMPL_ESTAB
VALUES ('262', '441', 'Rua 5913', '1187', '254', 'Bairro no.913', '94101337', '583', '5505139864543', '557', '5505154528302', 'complemento_913@generico.com', '913');
INSERT INTO END_COMPL_ESTAB
VALUES ('263', '949', 'Rua 5097', '1024', '196', 'Bairro no.97', '92374435', '636', '5505130966287', '57', '5505158409132', 'complemento_97@generico.com', '97');
INSERT INTO END_COMPL_ESTAB
VALUES ('264', '301', 'Rua 5601', '1026', '203', 'Bairro no.601', '90001342', '144', '5505130931698', '752', '5505154523346', 'complemento_601@generico.com', '601');
INSERT INTO END_COMPL_ESTAB
VALUES ('265', '374', 'Rua 5199', '1169', '163', 'Bairro no.199', '99375331', '399', '5505131032539', '107', '5505157247172', 'complemento_199@generico.com', '199');
INSERT INTO END_COMPL_ESTAB
VALUES ('266', '115', 'Rua 5313', '1278', '30', 'Bairro no.313', '96165137', '739', '5505132458346', '835', '5505156840123', 'complemento_313@generico.com', '313');
INSERT INTO END_COMPL_ESTAB
VALUES ('267', '165', 'Rua 5445', '757', '50', 'Bairro no.445', '97046332', '570', '5505135607179', '16', '5505151227012', 'complemento_445@generico.com', '445');
INSERT INTO END_COMPL_ESTAB
VALUES ('268', '630', 'Rua 5310', '881', '115', 'Bairro no.310', '94631157', '593', '5505135597474', '367', '5505154254622', 'complemento_310@generico.com', '310');
INSERT INTO END_COMPL_ESTAB
VALUES ('269', '589', 'Rua 5807', '1470', '84', 'Bairro no.807', '95131155', '472', '5505138529260', '736', '5505158805876', 'complemento_807@generico.com', '807');
INSERT INTO END_COMPL_ESTAB
VALUES ('270', '253', 'Rua 5718', '772', '263', 'Bairro no.718', '99000827', '323', '5505130232236', '473', '5505157883793', 'complemento_718@generico.com', '718');
INSERT INTO END_COMPL_ESTAB
VALUES ('271', '675', 'Rua 5703', '521', '218', 'Bairro no.703', '98185510', '182', '5505138163800', '950', '5505156016346', 'complemento_703@generico.com', '703');
INSERT INTO END_COMPL_ESTAB
VALUES ('272', '32', 'Rua 5552', '913', '286', 'Bairro no.552', '94408611', '11', '5505135671000', '68', '5505159920194', 'complemento_552@generico.com', '552');
INSERT INTO END_COMPL_ESTAB
VALUES ('273', '719', 'Rua 5660', '1193', '121', 'Bairro no.660', '92789405', '78', '5505130228210', '476', '5505157437016', 'complemento_660@generico.com', '660');
INSERT INTO END_COMPL_ESTAB
VALUES ('274', '2', 'Rua 5740', '1116', '260', 'Bairro no.740', '97696247', '418', '5505137039575', '700', '5505150642034', 'complemento_740@generico.com', '740');
INSERT INTO END_COMPL_ESTAB
VALUES ('275', '346', 'Rua 5039', '1143', '193', 'Bairro no.39', '97615126', '770', '5505132831832', '970', '5505155537945', 'complemento_39@generico.com', '39');
INSERT INTO END_COMPL_ESTAB
VALUES ('276', '635', 'Rua 5628', '1173', '202', 'Bairro no.628', '94315374', '967', '5505137141501', '973', '5505159910600', 'complemento_628@generico.com', '628');
INSERT INTO END_COMPL_ESTAB
VALUES ('277', '586', 'Rua 5834', '1100', '110', 'Bairro no.834', '94187406', '912', '5505136463047', '169', '5505150372606', 'complemento_834@generico.com', '834');
INSERT INTO END_COMPL_ESTAB
VALUES ('278', '440', 'Rua 5440', '565', '99', 'Bairro no.440', '93767328', '624', '5505131559911', '820', '5505154971112', 'complemento_440@generico.com', '440');
INSERT INTO END_COMPL_ESTAB
VALUES ('279', '99', 'Rua 5070', '1443', '194', 'Bairro no.70', '91789870', '653', '5505139875935', '917', '5505154372564', 'complemento_70@generico.com', '70');
INSERT INTO END_COMPL_ESTAB
VALUES ('280', '289', 'Rua 5432', '940', '11', 'Bairro no.432', '94788353', '894', '5505131066111', '116', '5505158147707', 'complemento_432@generico.com', '432');
INSERT INTO END_COMPL_ESTAB
VALUES ('281', '797', 'Rua 5283', '801', '245', 'Bairro no.283', '93318195', '460', '5505130598516', '650', '5505158289527', 'complemento_283@generico.com', '283');
INSERT INTO END_COMPL_ESTAB
VALUES ('282', '933', 'Rua 5220', '1133', '61', 'Bairro no.220', '98760683', '423', '5505130426616', '924', '5505153688474', 'complemento_220@generico.com', '220');
INSERT INTO END_COMPL_ESTAB
VALUES ('283', '58', 'Rua 5295', '533', '262', 'Bairro no.295', '98678800', '469', '5505130812474', '139', '5505159475225', 'complemento_295@generico.com', '295');
INSERT INTO END_COMPL_ESTAB
VALUES ('284', '795', 'Rua 5561', '576', '', 'Bairro no.561', '97771264', '115', '5505138207013', '933', '5505154328310', 'complemento_561@generico.com', '561');
INSERT INTO END_COMPL_ESTAB
VALUES ('285', '717', 'Rua 5116', '945', '266', 'Bairro no.116', '95398562', '138', '5505133725113', '848', '5505155114457', 'complemento_116@generico.com', '116');
INSERT INTO END_COMPL_ESTAB
VALUES ('286', '506', 'Rua 5081', '535', '74', 'Bairro no.81', '97291780', '993', '5505138963646', '528', '5505153241471', 'complemento_81@generico.com', '81');
INSERT INTO END_COMPL_ESTAB
VALUES ('287', '546', 'Rua 5699', '1408', '208', 'Bairro no.699', '91524853', '404', '5505137773905', '363', '5505152836242', 'complemento_699@generico.com', '699');
INSERT INTO END_COMPL_ESTAB
VALUES ('288', '373', 'Rua 5353', '507', '', 'Bairro no.353', '97405761', '692', '5505136524823', '136', '5505151158320', 'complemento_353@generico.com', '353');
INSERT INTO END_COMPL_ESTAB
VALUES ('289', '483', 'Rua 5490', '625', '245', 'Bairro no.490', '98722168', '172', '5505136565363', '812', '5505153235147', 'complemento_490@generico.com', '490');
INSERT INTO END_COMPL_ESTAB
VALUES ('290', '95', 'Rua 5986', '1293', '75', 'Bairro no.986', '91895184', '115', '5505136708925', '242', '5505157992528', 'complemento_986@generico.com', '986');
INSERT INTO END_COMPL_ESTAB
VALUES ('291', '957', 'Rua 5770', '1274', '167', 'Bairro no.770', '90319905', '331', '5505133940799', '965', '5505154211298', 'complemento_770@generico.com', '770');
INSERT INTO END_COMPL_ESTAB
VALUES ('292', '799', 'Rua 5271', '1419', '294', 'Bairro no.271', '97226807', '994', '5505136485573', '7', '5505156783247', 'complemento_271@generico.com', '271');
INSERT INTO END_COMPL_ESTAB
VALUES ('293', '988', 'Rua 5227', '1432', '212', 'Bairro no.227', '92533935', '925', '5505138226149', '633', '5505151709526', 'complemento_227@generico.com', '227');
INSERT INTO END_COMPL_ESTAB
VALUES ('294', '566', 'Rua 5200', '1093', '244', 'Bairro no.200', '96783771', '257', '5505130300441', '606', '5505153293979', 'complemento_200@generico.com', '200');
INSERT INTO END_COMPL_ESTAB
VALUES ('295', '234', 'Rua 5890', '1048', '290', 'Bairro no.890', '96429394', '752', '5505138908562', '453', '5505155467403', 'complemento_890@generico.com', '890');
INSERT INTO END_COMPL_ESTAB
VALUES ('296', '619', 'Rua 5450', '834', '109', 'Bairro no.450', '97713829', '16', '5505133636849', '479', '5505159010515', 'complemento_450@generico.com', '450');
INSERT INTO END_COMPL_ESTAB
VALUES ('297', '733', 'Rua 5723', '1136', '217', 'Bairro no.723', '96314745', '919', '5505137641951', '14', '5505158686192', 'complemento_723@generico.com', '723');
INSERT INTO END_COMPL_ESTAB
VALUES ('298', '748', 'Rua 5189', '913', '46', 'Bairro no.189', '94288643', '998', '5505138272904', '736', '5505156429373', 'complemento_189@generico.com', '189');
INSERT INTO END_COMPL_ESTAB
VALUES ('299', '63', 'Rua 5215', '1432', '0', 'Bairro no.215', '99110859', '748', '5505130987453', '154', '5505151763696', 'complemento_215@generico.com', '215');
INSERT INTO END_COMPL_ESTAB
VALUES ('300', '902', 'Rua 5257', '921', '127', 'Bairro no.257', '94640972', '250', '5505133151209', '252', '5505152848973', 'complemento_257@generico.com', '257');
