'''
Created on 27 de ago de 2016

@author: Max
'''
from random import random, seed

def atividades_profissionais_gen():
    seed(0)
    inputFile = open("cbo", "r")
    cbo = 0
    for linha in inputFile:
        cbo += 1
        prof = linha[8:-1]
        tp_cbo_saude = 'NULL'
        sql_inserts.write(
"""\
INSERT INTO ATIVIDADES_PROFISSIONAIS VALUES ('{0}', '{1}', {2});
"""
        .format(cbo, prof, tp_cbo_saude))
    print("atividades_profissionais done")
    
estados = []
def estados_gen():
    seed(0)
    inputFile = open("estados", "r")
    
    for linha in inputFile:
        uf = linha[-3:-1]
        estados.append(uf)
        estado = linha[:-4]
        sql_inserts.write(
"""\
INSERT INTO ESTADOS VALUES ('{0}', '{1}');
"""
        .format(uf, estado))
    print("estados done")

def estabelecimentos_gen():
    seed(0)
    for i in range(1, 1001):
        unidade_id = i
        cnes = 10000 + i       
        latitude = 90 * random()
        longitude = 90 * random()
        cod_mun = int( 1000 * random() + 1)
        logradouro = "Rua " + str( i + 5000 )
        numero = 500 + int( random() * 1000 )
        complemento = "NULL" if random() < 0.07 else "'{0}'".format(int( random()*300 ))
        bairro = "Bairro no." + str(i)
        cep = 90000000 + i*int((random()*10000))
        telefone = 5505130000000 + i*int((random()*10000))
        fax = 5505150000000 + i*int((random()*10000))
        email = "hospital_" + str(i) + "@generico.com"
        statusmov = "NULL"
        sql_inserts.write(
"""\
INSERT INTO ESTABELECIMENTOS
VALUES ('{0}', '{1}', {2}, {3}, '{4}', '{5}', '{6}', {7}, '{8}', '{9}', '{10}', '{11}', '{12}', {13});
"""
        .format(unidade_id, cnes, latitude, longitude, cod_mun, logradouro, numero, complemento, bairro, cep, telefone, fax, email, statusmov))
    print("estabelecimentos done")

def municipios_gen():
    seed(0)
    for i in range(1, 1001):
        uf =  estados[i % len(estados)]
        nome_mun = "Cidade no." + str(i)
        sql_inserts.write(
"""\
INSERT INTO MUNICIPIOS VALUES ('{0}', '{1}', '{2}');
"""
        .format(i, uf, nome_mun))
    print("municipios done")
    
def end_compl_estab_gen():
    seed(0)
    for end_compl_id in range(1, 301):
        i = int(1000 * random() + 1)
        unidade_id = i
        cod_mun = int( 1000 * random() )
        logradouro = "Rua " + str( i + 5000 )
        numero = 500 + int( random() * 1000 )
        complemento = "" if int( random()*1000 )%13 == 0 else int( random()*300 )    
        bairro = "Bairro no." + str(i)
        cep = 90000000 + int((random()*9999999))
        ddd_tel = int(random() * 999)
        telefone = 5505130000000 + int((random()*9999999))
        ddd_fax = int(random() * 999)
        fax = 5505150000000 + int((random()*9999999))
        email = "complemento_" + str(i) + "@generico.com"
        sql_inserts.write(
"""\
INSERT INTO END_COMPL_ESTAB
VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}');
"""
        .format(end_compl_id, cod_mun, logradouro, numero, complemento, bairro, cep, ddd_tel, telefone, ddd_fax, fax, email, unidade_id))
    print("end_compl_estab done")
        
def estab_horario_atend_gen():
    seed(0)
    estab_horario_atend_id = 0
    for unidade_id in range(1, 1001):
        for co_dia_semana in range(1, 8):
            estab_horario_atend_id += 1
            hr_inicio = str(int(12 * random())) + ":00"
            hr_fim = str(int(12 + 12 * random())) + ":00"
            sql_inserts.write(
"""\
INSERT INTO ESTAB_HORARIOS_ATEND VALUES ('{0}', '{1}', '{2}', '{3}', '{4}');
"""
            .format(estab_horario_atend_id, unidade_id, co_dia_semana, hr_inicio, hr_fim))
    print("estab_horario_atend_gen done")
    
def tipos_de_atendimento_gen():
    seed(0)
    for co_atend_prestado in range(0, 100):
        descricao = "Descricao " + str(co_atend_prestado)
        categoria = 'c' if random() < 0.33 else ('e' if random() < 0.66 else 'p')
        sql_inserts.write(
"""\
INSERT INTO TIPOS_DE_ATENDIMENTO VALUES ('{0}', '{1}', '{2}');
"""
        .format(co_atend_prestado, descricao, categoria) )
    print("tipos_de_atendimento_gen done")

    
def tipos_atend_estab_gen():
    seed(0)
    id_tipos_atend_estab = 0
    for unidade_id in range(1, 1001):
        for co_atend_prestado in range(0, 100):
            if random() < 0.039:
                id_tipos_atend_estab += 1
                sql_inserts.write(
"""\
INSERT INTO TIPOS_ATEND_ESTAB VALUES ({0}, '{1}', '{2}');
"""
                .format(id_tipos_atend_estab, unidade_id, co_atend_prestado))
    print("tipos_atend_estab_gen done")
    
def usuarios_gen():
    seed(0)
    for id_usuario in range(1, 1001):
        telefone = 5505130000000 + int((random()*9999999))
        dd = int(random() * 27.99 + 1)
        mm = int(random() * 11.99 + 1)
        rr = int(random() * 16)
        hh24 = int(random() * 23.99)
        mi = int(random() * 59)
        ss = int(random() * 59)
        ts_cadastro = "TO_DATE ('{0}-{1}-{2} {3}:{4}:{5}', 'DD-MM-RR HH24:MI:SS')".format(dd, mm, rr, hh24, mi, ss)
        sql_inserts.write(
"""\
INSERT INTO USUARIOS VALUES ({0}, {1}, {2});
"""
        .format(id_usuario, telefone, ts_cadastro))
    print("usuarios_gen done")
    
def pacientes_gen():
    seed(0)
    for id_paciente in range(1, 700):
        sql_inserts.write(
"""\
INSERT INTO PACIENTES VALUES ({0});
"""
        .format(id_paciente))
    print("pacientes_gen done")
        
def profissionais_gen():
    seed(0)
    for id_usuario in range(600, 1001):
        prof_id = str(10000 + id_usuario)
        cpf_prof = int(89999999999 * random()) + 10000000000
        nome_prof = "Profissional " + prof_id
        dd = int(random() * 27.99 + 1)
        mm = int(random() * 11.99 + 1)
        yyyy = 1915 + int(random() * 100)        
        data_nasc = "TO_DATE ('{0}-{1}-{2}', 'DD-MM-YYYY')".format(dd, mm, yyyy)
        sexo = "m" if random() < 0.5 else "f"
        statusmov = "NULL"
        no_email = "profissional_" + str(prof_id) + "@generico.com"
        sql_inserts.write(
"""\
INSERT INTO PROFISSIONAIS VALUES ({0}, '{1}', '{2}', '{3}', {4}, '{5}', '{6}', '{7}');       
"""
        .format(id_usuario, prof_id, cpf_prof, nome_prof, data_nasc, sexo, statusmov, no_email))
    print("profissionais_gen done")
 
def medicos_gen():
    seed(0)
    for id_medico in range(650, 901):
        sql_inserts.write(
"""\
INSERT INTO MEDICOS VALUES ({0});        
"""
        .format(id_medico))
    print("medicos_gen done")
    
def enderecos_gen():
    seed(0)
    id_enderecos = 0
    for id_paciente in range(1, 700):
        id_enderecos += 1
        dd = int(random() * 27.99 + 1)
        mm = int(random() * 11.99 + 1)
        rr = int(random() * 16)
        hh24 = int(random() * 23.99)
        mi = int(random() * 59)
        ss = int(random() * 59)
        ts_cadastro = "TO_DATE ('{0}-{1}-{2} {3}:{4}:{5}', 'DD-MM-RR HH24:MI:SS')".format(dd, mm, rr, hh24, mi, ss)
        logradouro = "Rua " + str( id_paciente + 5000 )
        numero = 500 + int( random() * 1000 )
        complemento = "NULL" if random() < 0.07 else "'{0}'".format(int( random()*300 ))
        bairro = "Bairro no." + str(id_paciente)
        cod_cep = 90000000 + int((random()*9999999))
        
        sql_inserts.write(
"""\
INSERT INTO ENDERECOS
VALUES ({0}, {1}, {2}, '{3}', '{4}', {5}, '{6}', '{7}');
"""        
        .format(id_enderecos, id_paciente, ts_cadastro, logradouro, numero, complemento, bairro, cod_cep))
        
        if(random() < 0.66):
            id_enderecos += 1
            dd = int(random() * 27.99 + 1)
            mm = int(random() * 11.99 + 1)
            rr = int(random() * 16)
            hh24 = int(random() * 23.99)
            mi = int(random() * 59)
            ss = int(random() * 59)
            ts_cadastro = "TO_DATE ('{0}-{1}-{2} {3}:{4}:{5}', 'DD-MM-RR HH24:MI:SS')".format(dd, mm, rr, hh24, mi, ss)
            logradouro = "Rua " + str( id_paciente + 5000 )
            numero = 500 + int( random() * 1000 )
            complemento = "NULL" if random() < 0.07 else "'{0}'".format(int( random()*300 ))
            bairro = "Bairro no." + str(id_paciente)
            cod_cep = 90000000 + int((random()*9999999))
            
            sql_inserts.write(
"""\
INSERT INTO ENDERECOS
VALUES ({0}, {1}, {2}, '{3}', '{4}', {5}, '{6}', '{7}');
"""        
            .format(id_enderecos, id_paciente, ts_cadastro, logradouro, numero, complemento, bairro, cod_cep))
    print("enderecos_gen done")
    
def atendimentos_gen():
    for id_atendimento in range(1, 2001):
        co_atend_prestado = int(99.99*random())
        id_medico = 650 + int(random()*250.99)
        dd = int(random() * 27.99 + 1)
        mm = int(random() * 11.99 + 1)
        rr = int(random() * 1.99) + 15
        hh24 = int(random() * 12)
        mi = int(random() * 59)
        ss = int(random() * 59)
        ts_inicio = "TO_DATE ('{0}-{1}-{2} {3}:{4}:{5}', 'DD-MM-RR HH24:MI:SS')".format(dd, mm, rr, hh24, mi, ss)
        
        hh24 = int(random() * 12 + 10)
        mi = int(random() * 59)
        ss = int(random() * 59)
        ts_fim = "TO_DATE ('{0}-{1}-{2} {3}:{4}:{5}', 'DD-MM-RR HH24:MI:SS')".format(dd, mm, rr, hh24, mi, ss)

        descricao = "Descricao de atendimento no." + str(id_atendimento)        
        id_paciente = int(random()*698.99 + 1)
        while id_paciente == id_medico:
        	id_paciente = int(random()*698.99 + 1)
        unidade_id = int(random()*999.99 + 1)
        sql_inserts.write(
"""\
INSERT INTO ATENDIMENTOS
VALUES ({0}, '{1}', {2}, {3}, {4}, '{5}', {6}, '{7}');
"""        
        .format(id_atendimento, co_atend_prestado, id_medico, ts_inicio, ts_fim, descricao, id_paciente, unidade_id))
    print("atendimentos_gen done")
        
def prof_estab_gen():
	seed(0)
	for id_prof_estab in range(1, 1001):
		unidade_id = 1 + int(999*random())
		id_usuario = 600 + int(random()*400.99)
		cod_cbo = int(999.99*random()) + 1
		sql_inserts.write(
"""\
INSERT INTO PROF_ESTAB VALUES ({0}, '{1}', {2}, '{3}');
"""
		.format(id_prof_estab, unidade_id, id_usuario, cod_cbo))
	print("prof_estab_gen done")

#sql_inserts = open("sql_inserts", "w")

funcoes = [ estados_gen, municipios_gen, estabelecimentos_gen, estab_horario_atend_gen,
end_compl_estab_gen, atividades_profissionais_gen, tipos_de_atendimento_gen,
tipos_atend_estab_gen, usuarios_gen, pacientes_gen, profissionais_gen,
medicos_gen, enderecos_gen, atendimentos_gen, prof_estab_gen]

for i, func in enumerate(funcoes):
	print("insert{:02d}.sql".format(i))
	sql_inserts = open("insert{:02d}.sql".format(i), "w")
	func()
	sql_inserts.close()

#print(funcoes)
#sql_inserts.close()
print("all done!")