package visual;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import spips.AtorDAO;
import spips.DiretorDAO;
import spips.FilmeDAO;
import spips.UsuarioDAO;
import util.ScriptReader;

public class DatabaseModel {
    private static final String DB_URL = "jdbc:oracle:thin:@camburi.pucrs.br:1521:facin11g";
    
    private static final String USER = "BF104329";
    private static final String PASS = "senha";
    
    private Connection conn = null;
    
    public DatabaseModel() throws Exception {
	// registra o driver durante execução do código fonte
        Class.forName("oracle.jdbc.OracleDriver");

        // abre uma conexão com o banco de dados
        conn = DriverManager.getConnection(DB_URL, USER, PASS);  
    }
    
    public void createDatabase() throws Exception {
    	ScriptReader.readScript("criabanco.sql", conn);
    }
    
    public void clearDatabase() throws Exception {
    	ScriptReader.readScript("limpabanco.sql", conn);
    }

    /**
     * Código de exemplo. Modificar para a base escolhida.
     * @param typeQuery O índice da consulta na lista de consultas.
     * @return Lista de resultados da base de dados.
     * @throws Exception 
     */
    public ArrayList<String> query(int typeQuery) throws Exception {    
    	ArrayList<String> results = new ArrayList<>();
    	DiretorDAO diretorDAO = new DiretorDAO(conn);
    	FilmeDAO filmeDAO = new FilmeDAO(conn);
    	AtorDAO atorDAO = new AtorDAO(conn);
    	UsuarioDAO usuarioDAO = new UsuarioDAO(conn);
    	
    	switch(typeQuery){
    	case 0: filmeDAO.consulta1().stream().forEach(d -> results.add(d.toString())); break;
    	case 1: results.add("" + filmeDAO.consulta2()); break;

    	case 3: results.add("" + diretorDAO.consulta4()); break;
    	case 4: filmeDAO.consulta5().stream().forEach(d -> results.add(d.toString())); break;
    	case 5: results.add("" + filmeDAO.consulta6()); break;

    	case 6: results.add("" + usuarioDAO.consulta7()); break;
    	
    	case 7: filmeDAO.consulta8().stream().forEach(d -> results.add(d.toString())); break;

    	case 8: results.add("" + filmeDAO.consulta9()); break;

    	case 9: atorDAO.consulta10().stream().forEach(d -> results.add(d.toString())); break;
    	case 10: filmeDAO.consulta11().stream().forEach(d -> results.add(d.toString())); break;
    	case 12: filmeDAO.consulta13().stream().forEach(d -> results.add(d.toString())); break;
    	case 15: filmeDAO.consulta16().stream().forEach(d -> results.add(d.toString())); break;
    	case 16: filmeDAO.consulta17().stream().forEach(d -> results.add(d.toString())); break;
    	case 17: filmeDAO.consulta18().stream().forEach(d -> results.add(d.toString())); break;
    	case 18: filmeDAO.consulta19().stream().forEach(d -> results.add(d.toString())); break;
    	case 19: filmeDAO.consulta20().stream().forEach(d -> results.add(d.toString())); break;

    	}

	return results;
    }
    
    public void closeConnections() throws Exception {
	conn.close();
    }
}
