package model;

import java.sql.Date;
import java.util.Set;

public class Diretor {
	private int id;
	private String nome;
	private Date nascimento;
	private Date morte;
	private Sexo sexo;
	private Set<Filme> filmes;
	
	
	public Diretor(int id, String nome, Date nascimento, Date morte, Sexo sexo){
		this.id = id;
		this.nome = nome;
		this.nascimento = nascimento;
		this.morte = morte;
		this.sexo = sexo;
	}
	
	public Diretor(){
		
	}
	
	public void setFilmes(Set<Filme> filmes){
		this.filmes = filmes;
	}
	public int getId() {
		return id;
	}
	public String getNome() {
		return nome;
	}	
	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getNascimento() {
		return nascimento;
	}
	public Date getMorte() {
		return morte;
	}
	public Sexo getSexo() {
		return sexo;
	}
	public Set<Filme> getFilmes() {
		return filmes;
	}
	public int getIdade(){
		if(morte == null) return (int)(new java.util.Date().getTime() - nascimento.getTime())/(365*1000 * 60 * 60 * 24);
		return (int)(morte.getTime() - nascimento.getTime())/(365*1000 * 60 * 60 * 24);
	}
	@Override
	public String toString() {
		String filmes = "";
		for(Filme filme: this.filmes){
			filmes.concat(filme.getNome()+" (" + filme.getAno() + ")\n");
		}
		return nome +"("+sexo+")" + "\nIdade: " + getIdade() + (morte == null ? "" : ("\nMorte: " + morte.toString()) ) + "\nFilmes:\n";  
	}	
}
