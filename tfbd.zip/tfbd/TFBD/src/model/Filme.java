package model;

import java.util.Set;

public class Filme {
	private int id;
	private String nome;
	private String sinopse;
	private int ano;
	private int duracao;
	private Set<Diretor> diretores;
	private Set<Ator> elenco;
	private Set<Genero> generos;
	
	public Filme(int id, String nome, String sinopse, int ano, int duracao) {
		this.id = id;
		this.nome = nome;
		this.sinopse = sinopse;
		this.ano = ano;
		this.duracao = duracao;
	}	
	public Filme(){
		
	}	
	public void setAno(int ano){
		this.ano = ano;
	}	
	public void setNome(String nome){
		this.nome = nome;
	}
	public void setDiretores(Set<Diretor> diretores){
		this.diretores = diretores;
	}
	public void setElenco(Set<Ator> atores){
		this.elenco = atores;
	}
	public void setGenero(Set<Genero> generos){
		this.generos = generos;
	}
	public int getId() {
		return id;
	}
	public String getNome() {
		return nome;
	}
	public String getSinopse() {
		return sinopse;
	}
	public int getAno() {
		return ano;
	}
	public int getDuracao() {
		return duracao;
	}
	public Set<Diretor> getDiretores() {
		return diretores;
	}
	public Set<Ator> getElenco() {
		return elenco;
	}
	public Set<Genero> getGeneros(){
		return generos;
	}
	
	@Override
	public String toString() {
		return "Filme [nome=" + nome + ", sinopse=" + sinopse + ", ano=" + ano
				+ ", duracao=" + duracao + ", diretores=" + diretores
				+ ", elenco=" + elenco + ", generos=" + generos + "]";
	}
	
}
