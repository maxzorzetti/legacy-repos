package model;

import java.sql.Date;
import java.util.Set;

public class Ator {
	private int id;
	private String nome;
	private Date nascimento;
	private Date morte;
	private Sexo sexo;
	private Set<Filme> filmes; 
	
	public Ator(int id, String nome, Date nascimento, Date morte, Sexo sexo) {
		this.id = id;
		this.nome = nome;
		this.nascimento = nascimento;
		this.morte = morte;
		this.sexo = sexo;
	}
	
	public Ator() {
		
	}
	public void setFilmes(Set<Filme> filmes){
		this.filmes = filmes;
	}
	public int getId() {
		return id;
	}
	public String getNome() {
		return nome;
	}
		
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Date getNascimento() {
		return nascimento;
	}
	public Date getMorte() {
		return morte;
	}
	public Sexo getSexo() {
		return sexo;
	}
	public Set<Filme> getFilmes() {
		return filmes;
	}
	@Override
	public String toString() {
		String filmes = "";
		for(Filme filme: this.filmes){
			filmes.concat(filme.getNome() + "\n");
		}
		return "Ator [nome=" + nome + ", nascimento=" + nascimento + ", morte="
				+ morte + ", sexo=" + sexo + ", filmes=" + filmes + "]";
	}
	
	
}
