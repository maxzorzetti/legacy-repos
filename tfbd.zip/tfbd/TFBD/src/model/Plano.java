package model;

public class Plano {
	private int id;
	private String nome;
	private int telas;
	private String defTela;
	private double mensalidade;
	
	public Plano(int id, String nome, int telas, String defTela,
			double mensalidade) {		
		this.id = id;
		this.nome = nome;
		this.telas = telas;
		this.defTela = defTela;
		this.mensalidade = mensalidade;	
	}
	
	public Plano(){
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getTelas() {
		return telas;
	}

	public void setTelas(int telas) {
		this.telas = telas;
	}

	public String getDefTela() {
		return defTela;
	}

	public void setDefTela(String defTela) {
		this.defTela = defTela;
	}

	public double getMensalidade() {
		return mensalidade;
	}

	public void setMensalidade(double mensalidade) {
		this.mensalidade = mensalidade;
	}
		
	
}
