package model;

public enum Sexo {
	MASCULINO("M"),
	FEMININO("F");
	
	private final String name;
	
	private Sexo(String s) {
        name = s;
    }
	
	public boolean equalsName(String otherName) {
        return (otherName == null) ? false : name.equals(otherName);
    }
	
	public String toString(){
		return this.name;
	}
}
