package model;

import java.sql.Date;
import java.util.ArrayList;

public class Usuario {
	private int id;
	private String nome;
	private String sobrenome;
	private String email;
	private String senha;
	private ArrayList<Perfil> perfilUsuario;
	private Plano plano;
	
	public Usuario(int id, String nome, String sobrenome, String senha, String email) {
		this.id = id;
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.senha = senha;
		this.email = email;
	}
	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public ArrayList<Perfil> getPerfilUsuario() {
		return perfilUsuario;
	}

	public void setPerfilUsuario(ArrayList<Perfil> perfilUsuario) {
		this.perfilUsuario = perfilUsuario;
	}	

	public Plano getPlano() {
		return plano;
	}

	public void setPlano(Plano plano) {
		this.plano = plano;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", nome=" + nome + ", sobrenome="
				+ sobrenome + ", email=" + email + ", senha=" + senha
				+ ", perfilUsuario=" + perfilUsuario + ", plano=" + plano + "]";
	}

	
}
	