package spips;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import model.Ator;
import model.Diretor;
import model.Filme;
import model.Genero;

public class FilmeDAO {
	private Connection conn;
	
	public FilmeDAO(Connection conn) {
		this.conn = conn;
	}
	
	public ArrayList<Filme> consulta1() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT id_filme, nome_filme, sinopse_filme, ano_filme, duracao_filme "
				+ "FROM FILME "
				+ "WHERE YEARS_BETWEEN(SYSDATE, ANO_FILME) >= 10 "
				+ "ORDER BY ANO_FILME"
				);
		
		ArrayList<Filme> filmes = new ArrayList<Filme>();
		
		while(rs.next()){
			Filme filme = new Filme(
					rs.getInt("id_filme"), 
					rs.getString("nome_filme"), 
					rs.getString("sinopse_filme"), 
					rs.getInt("ano_filme"), 
					rs.getInt("duracao")
					);
			filme.setDiretores(encontraDiretores(filme.getId()));
			filme.setElenco(encontraAtores(filme.getId()));
			filme.setGenero(encontraGenero(filme.getId()));
			filmes.add(filme);				
		}
		
		rs.close();
		st.close();
		
		return filmes;
	}
	
	public String consulta2() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT SINOPSE_FILME "
				+ "FROM FILME "
				+ "WHERE nome_filme LIKE 'Forrest Gump'" 
				);
		
		String row = "";
		
		while(rs.next()){
			row.concat(rs.getString("SINOPSE_FILME"));
		}
		
		rs.close();
		st.close();
		
		return row;
	}

	public ArrayList<Filme> consulta5() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT id_filme, nome_filme, sinopse_filme, ano_filme, duracao_filme "
				+ "FROM filme "
				+ "WHERE duracao_filme BETWEEN 70 AND 100 "
				+ "ORDER BY duracao_filme"
				);
		
		ArrayList<Filme> filmes = new ArrayList<Filme>();
		
		while(rs.next()){
			Filme filme = new Filme(
					rs.getInt("id_filme"), 
					rs.getString("nome_filme"), 
					rs.getString("sinopse_filme"), 
					rs.getInt("ano_filme"), 
					rs.getInt("duracao")
					);
			filme.setDiretores(encontraDiretores(filme.getId()));
			filme.setElenco(encontraAtores(filme.getId()));
			filme.setGenero(encontraGenero(filme.getId()));
			filmes.add(filme);				
		}
		
		rs.close();
		st.close();
		
		return filmes;
	}
	
	public String consulta6() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT count(*) "
				+ "FROM filme fil "
				+ "INNER JOIN elenco el ON fil.ID_FILME = el.ID_FILME "
				+ "WHERE fil.NOME_FILME LIKE 'The Godfather'" 
				);
		
		String row = "";
		
		while(rs.next()){
			row.concat(rs.getString("count(*)"));
		}
		
		rs.close();
		st.close();
		
		return row;
	}
	
	public ArrayList<Filme> consulta8() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT fil.id_filme, fil.nome_filme, fil.sinopse_filme, fil.ano_filme "
				+ "FROM filme fil "
				+ "INNER JOIN genero_filme gf ON fil.ID_FILME = gf.ID_FILME "
				+ "INNER JOIN genero ge ON gf.ID_GENERO = ge.ID_GENERO "
				+ "WHERE ge.NOME_GENERO LIKE 'FANTASY' OR "
				+ "ge.NOME_GENERO LIKE 'SCI-FI'"
				);
		
		ArrayList<Filme> filmes = new ArrayList<Filme>();
		
		while(rs.next()){
			Filme filme = new Filme(
					rs.getInt("id_filme"), 
					rs.getString("nome_filme"), 
					rs.getString("sinopse_filme"), 
					rs.getInt("ano_filme"), 
					rs.getInt("duracao")
					);
			filme.setDiretores(encontraDiretores(filme.getId()));
			filme.setElenco(encontraAtores(filme.getId()));
			filme.setGenero(encontraGenero(filme.getId()));
			filmes.add(filme);				
		}
		
		rs.close();
		st.close();
		
		return filmes;
	}
	
	
	public String consulta9() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT COUNT(DISTINCT fil.nome_filme) "
				+ "FROM filme fil "
				+ "INNER JOIN genero_filme gf ON fil.ID_FILME = gf.ID_FILME "
				+ "INNER JOIN genero ge ON gf.ID_GENERO = ge.ID_GENERO "
				+ "WHERE ge.NOME_GENERO LIKE 'ACAO'" 
				);
		
		String row = "";
		
		while(rs.next()){
			row.concat(rs.getString("COUNT(DISTINCT fil.nome_filme)"));
		}
		
		rs.close();
		st.close();
		
		return row;
	}
	
	
	
	public ArrayList<String> consulta11() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT ge.nome_genero, AVG(fil.duracao_filme) "
				+ "FROM genero ge "
				+ "INNER JOIN genero_filme gf ON ge.ID_GENERO = gf.ID_GENERO "
				+ "INNER JOIN filme fil ON gf.ID_FILME = fil.ID_FILME "
				+ "GROUP BY ge.nome_genero "
				+ "HAVING AVG(fil.duracao_filme) > 100" 
				);
		
		ArrayList<String> result = new ArrayList<String>();
		
		while(rs.next()){
			String row = "";
			row.concat(rs.getString("ge.nome_genero"));
			row.concat(": " + rs.getInt("AVG(fil.duracao_filme)"));			
		}
		
		rs.close();
		st.close();
		
		return result;
	}
	
	public ArrayList<String> consulta13() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT ge.nome_genero, COUNT(*) "
				+ "FROM genero ge "
				+ "INNER JOIN genero_filme gf ON ge.ID_GENERO = gf.ID_GENERO "
				+ "INNER JOIN filme fil ON gf.ID_FILME = fil.ID_FILME "
				+ "GROUP BY ge.nome_genero "
				+ "HAVING COUNT(*) > 5" 
				);
		
		ArrayList<String> result = new ArrayList<String>();
		
		while(rs.next()){
			String row = "";
			row.concat(rs.getString("ge.nome_genero"));
			row.concat(": " + rs.getInt("COUNT(*)"));			
		}
		
		rs.close();
		st.close();
		
		return result;
	}
	
	public ArrayList<Filme> consulta16() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT fil.id_filme, fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme "
				+ "FROM filme fil "
				+ "INNER JOIN elenco el ON fil.ID_FILME = fil.ID_FILME "
				+ "WHERE el.ID_ATOR IN ( "
				+ "  SELECT ato.ID_ATOR "
				+ "  FROM ator ato "
				+ "  WHERE EXTRACT( YEAR FROM ato.nascimento_ator) < 1960 "
				+ ")"
				);
		
		ArrayList<Filme> filmes = new ArrayList<Filme>();
		
		while(rs.next()){
			Filme filme = new Filme(
					rs.getInt("id_filme"), 
					rs.getString("nome_filme"), 
					rs.getString("sinopse_filme"), 
					rs.getInt("ano_filme"), 
					rs.getInt("duracao")
					);
			filme.setDiretores(encontraDiretores(filme.getId()));
			filme.setElenco(encontraAtores(filme.getId()));
			filme.setGenero(encontraGenero(filme.getId()));
			filmes.add(filme);				
		}
		
		rs.close();
		st.close();
		
		return filmes;
	}
	
	public ArrayList<Filme> consulta17() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT fil.id_filme, fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme "
				+ "FROM filme fil "
				+ "INNER JOIN diretor_filme df ON fil.ID_FILME = df.ID_DIRETOR "
				+ "WHERE df.id_diretor IN( "
				+ "  SELECT di.id_diretor "
				+ "  FROM diretor di "
				+ "  WHERE di.sexo_diretor LIKE 'F' "
				+ ")"
				);
		
		ArrayList<Filme> filmes = new ArrayList<Filme>();
		
		while(rs.next()){
			Filme filme = new Filme(
					rs.getInt("id_filme"), 
					rs.getString("nome_filme"), 
					rs.getString("sinopse_filme"), 
					rs.getInt("ano_filme"), 
					rs.getInt("duracao")
					);
			filme.setDiretores(encontraDiretores(filme.getId()));
			filme.setElenco(encontraAtores(filme.getId()));
			filme.setGenero(encontraGenero(filme.getId()));
			filmes.add(filme);				
		}
		
		rs.close();
		st.close();
		
		return filmes;
	}
	
	public ArrayList<Filme> consulta18() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme "
				+ "FROM filme fil "
				+ "INNER JOIN elenco el ON fil.ID_FILME = el.ID_FILME "
				+ "WHERE el.ID_ATOR IN( "
				+ "  SELECT el.ID_ATOR "
				+ "  FROM filme fil2 "
				+ "  INNER JOIN elenco el2 ON fil2.ID_FILME = el2.ID_FILME "
				+ "  WHERE fil2.nome_filme LIKE 'The Shawshank Redemption' "
				+ ")"
				);
		
		ArrayList<Filme> filmes = new ArrayList<Filme>();
		
		while(rs.next()){
			Filme filme = new Filme(
					rs.getInt("id_filme"), 
					rs.getString("nome_filme"), 
					rs.getString("sinopse_filme"), 
					rs.getInt("ano_filme"), 
					rs.getInt("duracao")
					);
			filme.setDiretores(encontraDiretores(filme.getId()));
			filme.setElenco(encontraAtores(filme.getId()));
			filme.setGenero(encontraGenero(filme.getId()));
			filmes.add(filme);				
		}
		
		rs.close();
		st.close();
		
		return filmes;
	}
	
	public ArrayList<Filme> consulta19() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme "
				+ "FROM filme fil "
				+ "INNER JOIN genero_filme gf ON fil.ID_FILME = gf.ID_FILME "
				+ "INNER JOIN genero ge ON gf.ID_GENERO = ge.ID_GENERO "
				+ "INNER JOIN diretor_filme df ON fil.ID_FILME = df.ID_FILME "
				+ "WHERE ge.NOME_GENERO LIKE 'ACAO' AND "
				+ "df.ID_DIRETOR IN( "
				+ "  SELECT di2.id_diretor "
				+ "  FROM diretor di2 "
				+ "  INNER JOIN diretor_filme df2 ON di2.id_diretor = df2.id_diretor "
				+ "  INNER JOIN filme fil2 ON df2.id_filme = fil2.id_filme   "
				+ "  INNER JOIN genero_filme gf2 ON fil2.id_filme = gf2.ID_FILME "
				+ "  INNER JOIN genero ge2 ON gf2.id_genero = ge2.id_genero "
				+ "  WHERE ge2.nome_genero LIKE 'ROMANCE' "
				+ ")"
				);
		
		ArrayList<Filme> filmes = new ArrayList<Filme>();
		
		while(rs.next()){
			Filme filme = new Filme(
					rs.getInt("id_filme"), 
					rs.getString("nome_filme"), 
					rs.getString("sinopse_filme"), 
					rs.getInt("ano_filme"), 
					rs.getInt("duracao")
					);
			filme.setDiretores(encontraDiretores(filme.getId()));
			filme.setElenco(encontraAtores(filme.getId()));
			filme.setGenero(encontraGenero(filme.getId()));
			filmes.add(filme);				
		}
		
		rs.close();
		st.close();
		
		return filmes;
	}
	
	public ArrayList<Filme> consulta20() throws SQLException{
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme "
				+ "FROM filme fil "
				+ "INNER JOIN diretor_filme df ON fil.ID_FILME = df.ID_FILME "
				+ "WHERE df.ID_DIRETOR IN( "
				+ "  SELECT di2.ID_DIRETOR"
				+ "  FROM diretor di2"
				+ "  WHERE EXTRACT(YEAR FROM di2.nascimento_diretor) < 1970 "
				+ ")"
				);
		
		ArrayList<Filme> filmes = new ArrayList<Filme>();
		
		while(rs.next()){
			Filme filme = new Filme(
					rs.getInt("id_filme"), 
					rs.getString("nome_filme"), 
					rs.getString("sinopse_filme"), 
					rs.getInt("ano_filme"), 
					rs.getInt("duracao")
					);
			filme.setDiretores(encontraDiretores(filme.getId()));
			filme.setElenco(encontraAtores(filme.getId()));
			filme.setGenero(encontraGenero(filme.getId()));
			filmes.add(filme);		
		}
		return filmes;
	}		
	
	private Set<Genero> encontraGenero(int id) throws SQLException {
		
		Set<Genero> generos = new HashSet<Genero>();
		
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT AT.NOME_ATOR"
					+ "FROM ATORES AT INNER JOIN ELENCO EL "
					+ "ON AT.ID_ATOR = EL.ID_ATOR WHERE FIL.ID_FILME = "+id);
			while(rs.next()){
				generos.add(Genero.valueOf( rs.getString("NOME_GENERO") ) );
			}		
			return generos;
	}

	private Set<Ator> encontraAtores(int id) throws SQLException {
	
			Set<Ator> atores = new HashSet<Ator>();
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT AT.NOME_ATOR"
											+ "FROM ATORES AT INNER JOIN ELENCO EL "
											+ "ON AT.ID_ATOR = EL.ID_ATOR WHERE FIL.ID_FILME = "+id);
			while(rs.next()){
				Ator ator = new Ator();
				ator.setNome(rs.getString("NOME_ATOR"));
				atores.add(ator);
			}
			return atores;
	}
	
	private Set<Diretor> encontraDiretores(int id) throws SQLException {
		  
			Set<Diretor> diretores = new HashSet<Diretor>();
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT DIR.NOME_DIRETOR"
					+ "FROM DIRETOR DIR INNER JOIN DIRETOR_FILME  DIRF "
					+ "ON DIR.ID_DIRETOR = DIRF.ID_DIRETOR WHERE FIL.ID_FILME = "+id);
			while(rs.next()){
				Diretor diretor = new Diretor();
				diretor.setNome(rs.getString("NOME_DIRETOR"));
				diretores.add(diretor);				
			}
			return diretores;
	}
}
