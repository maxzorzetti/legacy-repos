package spips;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import model.Diretor;
import model.Filme;
import model.Perfil;
import model.Plano;
import model.Sexo;
import model.Usuario;

public class UsuarioDAO {

	private Connection con;
	
	public UsuarioDAO(Connection con) {
		this.con = con;
	}
	
	public ArrayList<Usuario> listaUsuarios() throws SQLException{
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM USUARIO");
		
		ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
		
	while(rs.next()){
			Usuario usuario = new Usuario(rs.getInt("ID_USUARIO"), 
					rs.getString("NOME_USUARIO"), 
					rs.getString("SOBRENOME_USUARIO"), 
					rs.getString("EMAIL_USUARIO"),
					rs.getString("SENHA_USUARIO")	
					); 								
			usuario.setPerfilUsuario(mostraPerfis(usuario.getId()));
			usuario.setPlano(mostraPlano(usuario.getId()));
		}		
		rs.close();
		st.close();
		
		return usuarios;
	}
	
	public Plano mostraPlano(int id) throws SQLException{
		
		Plano plano = new Plano();
	
		Statement st = con.createStatement();		
		ResultSet rs = st.executeQuery("SELECT PLAN.NOME_PLANO"
				+ "FROM PLANO PLAN INNER JOIN USUARIO USU ON USU.ID_PLANO = PLAN.ID_PLANO"
				+ "WHERE USU.ID_USUARIO = " + id);
		while(rs.next()){			
            plano.setNome(rs.getString("NOME_PLANO"));            
		}
		return plano;		
	}
	
	public ArrayList<Perfil> mostraPerfis(int id) throws SQLException{
		
		ArrayList<Perfil> perfis = new ArrayList<Perfil>();
	
		Statement st = con.createStatement();		
		ResultSet rs = st.executeQuery("SELECT PER.NOME_PERFIL"
				+ "FROM PERFIL PER INNER JOIN PERFIL_USUARIO PERU ON PERU.ID_PERFIL = PER.ID_PERFIL"
				+ "WHERE USU.ID_USUARIO = " + id);
		while(rs.next()){
			Perfil perfil = new Perfil();
            perfil.setNome(rs.getString("NOME_PERFIL"));            
            perfis.add(perfil);
		}
		return perfis;		
	}
	
	public int consulta7() throws SQLException{
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT count(*)"
				+ "FROM usuario us"
				+ "INNER JOIN perfil_usuario pu ON us.id_usuario = pu.id_usuario"
				+ "WHERE us.nome_usuario LIKE 'Matheus%'");
		
		rs.next();
		return rs.getInt("count(*)");
	}
}
