package spips;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import model.Diretor;
import model.Filme;
import model.Sexo;


public class DiretorDAO {
	private Connection con;
	
	public DiretorDAO(Connection con) {
		this.con = con;
	}
	
	
	
	public ArrayList<Diretor> listaDiretores() throws SQLException{
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM DIRETOR");
		
		ArrayList<Diretor> diretores = new ArrayList<Diretor>();
		
		while(rs.next()){
			Diretor diretor = new Diretor(rs.getInt("id_diretor"), 
					rs.getString("nome_diretor"), 
					rs.getDate("nascimento_diretor"), 
					rs.getDate("morte_diretor"),
					rs.getString("sexo_diretor").equals("M") ? Sexo.MASCULINO : Sexo.FEMININO 
					);
			diretor.setFilmes(encontrarFilmesDeDiretor(diretor.getId()));
			diretores.add(diretor);					
		}
		
		rs.close();
		st.close();
		
		return diretores;
	}
	
	private Set<Filme> encontrarFilmesDeDiretor(int id) throws SQLException{
		
		Set<Filme> filmes = new HashSet<Filme>();
		
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT FIL.NOME_FILME, FIL.ANO_FILME "
				+ "FROM FILME FIL INNER JOIN DIRETOR_FILME DIRF ON FIL.ID_FILME = DIRF.ID_FILME "
				+ "WHERE DIRF.ID_DIRETOR = " + id);
		while(rs.next()){
			Filme filme = new Filme ();
            filme.setNome(rs.getString("NOME_FILME"));
            filme.setAno(rs.getInt("ANO_FILME"));
            filmes.add(filme);
		}
		return filmes;		
	}
	
	public Date consulta4() throws SQLException{
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT nascimento_diretor "
				+ "FROM diretor "
				+ "WHERE nome_diretor LIKE 'Christopher Nolan'");
		
		Date result = null;
		
		while(rs.next()){
			result = rs.getDate("nascimento_diretor");
		}
		
		rs.close();
		st.close();
		
		return result;
	}
	
	
}
