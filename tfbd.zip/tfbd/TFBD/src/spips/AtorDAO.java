package spips;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Ator;
import model.Sexo;

public class AtorDAO {
	private Connection con;
	
	public AtorDAO(Connection con) {
		this.con = con;
	}
	
	public ArrayList<Ator> listaAtores() throws SQLException{
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM ATOR");
		
		ArrayList<Ator> atores = new ArrayList<Ator>();
		
		while(rs.next()){
			atores.add( new Ator(rs.getInt("id_ator"), 
						rs.getString("nome_ator"), 
						rs.getDate("nascimento_ator"), 
						rs.getDate("morte_ator"),
						Sexo.valueOf(rs.getString("sexo_ator"))
						) 
			);					
		}
		
		rs.close();
		st.close();
		
		return atores;
	}
	
	public ArrayList<Ator> consulta10() throws SQLException{
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT ato.NOME_ATOR, ato.NASCIMENTO_ATOR, ato.MORTE_ATOR, ato.SEXO_ATOR "
				+ "FROM ator ato "
				+ "INNER JOIN elenco el ON ato.ID_ATOR = el.ID_ATOR "
				+ "INNER JOIN filme fil ON el.ID_FILME = fil.ID_FILME "
				+ "WHERE fil.NOME_FILME  LIKE 'The Dark Knight'");
		
		ArrayList<Ator> atores = new ArrayList<Ator>();
		
		while(rs.next()){
			atores.add( new Ator(rs.getInt("id_ator"), 
						rs.getString("nome_ator"), 
						rs.getDate("nascimento_ator"), 
						rs.getDate("morte_ator"),
						Sexo.valueOf(rs.getString("sexo_ator"))
						) 
			);					
		}
		
		rs.close();
		st.close();
		
		return atores;
	}
	
}
