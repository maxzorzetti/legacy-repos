-- 1 Lista os filmes lan�ados nos �ltimos 10 anos

SELECT * 
FROM FILME
WHERE YEARS_BETWEEN(SYSDATE, ANO_FILME) >= 10
ORDER BY ANO_FILME;

-- 2 Mostra a sinopse do filme Forrest Gump

SELECT SINOPSE_FILME
FROM FILME
WHERE nome_filme LIKE 'Forrest Gump';

-- 3 Lista todos os atores que t�m John no nome

SELECT COUNT(*)
FROM ator
WHERE nome_ator LIKE 'John%';

-- 4 Mostra a data de nascimento do diretor Christopher Nolan

SELECT nascimento_diretor
FROM diretor
WHERE nome_diretor LIKE 'Christopher Nolan';

-- 5 Lista os filmes com dura��o entre 70 e 100 minutos

SELECT id_filme, nome_filme, sinopse_filme, ano_filme, duracao_filme
FROM filme
WHERE duracao_filme BETWEEN 70 AND 100
ORDER BY duracao_filme;

---------------------------

-- 6 Mostra quantos atores est�o no elenco de The Godfather

SELECT count(*)
FROM filme fil
INNER JOIN elenco el ON fil.ID_FILME = el.ID_FILME
WHERE fil.NOME_FILME LIKE 'The Godfather';

-- 7 Mostra a quantidade de perfis que os usu�rios que t�m o primeiro nome "Matheus"

SELECT count(*)
FROM usuario us
INNER JOIN perfil_usuario pu ON us.id_usuario = pu.id_usuario
WHERE us.nome_usuario LIKE 'Matheus%';


-- 8 Lista as informa��es dos filmes que s�o do g�nero "FANTASY" ou "SCIFI"

SELECT fil.id_filme, fil.nome_filme, fil.sinopse_filme, fil.ano_filme
FROM filme fil
INNER JOIN genero_filme gf ON fil.ID_FILME = gf.ID_FILME
INNER JOIN genero ge ON gf.ID_GENERO = ge.ID_GENERO
WHERE ge.NOME_GENERO LIKE 'FANTASY' OR
ge.NOME_GENERO LIKE 'SCIFI';

-- 9 Mostra a quantidade de filmes do g�nero "ACTION" 

SELECT COUNT(DISTINCT fil.nome_filme)
FROM filme fil
INNER JOIN genero_filme gf ON fil.ID_FILME = gf.ID_FILME
INNER JOIN genero ge ON gf.ID_GENERO = ge.ID_GENERO
WHERE ge.NOME_GENERO LIKE 'ACTION';

-- 10 Lista as informa��es dos atores do filme "The Dark Knight"

SELECT ato.NOME_ATOR, ato.NASCIMENTO_ATOR, ato.MORTE_ATOR, ato.SEXO_ATOR
FROM ator ato
INNER JOIN elenco el ON ato.ID_ATOR = el.ID_ATOR
INNER JOIN filme fil ON el.ID_FILME = fil.ID_FILME
WHERE fil.NOME_FILME  LIKE 'The Dark Knight';

-----------------

-- 11 Mostra a m�dia de dura��o dos filmes agrupados por g�nero, mostrando apenas aqueles que possuem a m�dia de dura��o maior que 100 minutos

SELECT ge.nome_genero, AVG(fil.duracao_filme)
FROM genero ge
INNER JOIN genero_filme gf ON ge.ID_GENERO = gf.ID_GENERO
INNER JOIN filme fil ON gf.ID_FILME = fil.ID_FILME
GROUP BY ge.nome_genero
HAVING AVG(fil.duracao_filme) > 100;

-- 12 Mostra a quantidade de usu�rios, agrupadas por plano, mostrando apenas aqueles que possuem mais de 5 usu�rios

SELECT pl.nome_plano, COUNT(id_usuario)
FROM plano pl
INNER JOIN usuario us ON pl.ID_PLANO = us.ID_PLANO
GROUP BY pl.nome_plano
HAVING COUNT(id_usuario) > 5;

-- 13 Mostra a quantidade de filmes, agrupadas por g�nero, mostrando apenas aqueles que possuem mais de 5 filmes

SELECT ge.nome_genero, COUNT(*)
FROM genero ge
INNER JOIN genero_filme gf ON ge.ID_GENERO = gf.ID_GENERO
INNER JOIN filme fil ON gf.ID_FILME = fil.ID_FILME
GROUP BY ge.nome_genero
HAVING COUNT(*) > 5;

--14



----------------------------------

-- 16 Lista as informa��es dos filmes que possuem atores nascidos ap�s 1960

SELECT fil.id_filme, fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme
FROM filme fil
INNER JOIN elenco el ON fil.ID_FILME = fil.ID_FILME
WHERE el.ID_ATOR IN (
  SELECT ato.ID_ATOR
  FROM ator ato
  WHERE EXTRACT( YEAR FROM ato.nascimento_ator) < 1960
);

-- 17 Lista as informa��es dos filmes que possuem algum diretor do sexo feminino

SELECT fil.id_filme, fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme
FROM filme fil
INNER JOIN diretor_filme df ON fil.ID_FILME = df.ID_DIRETOR
WHERE df.id_diretor IN(
  SELECT di.id_diretor
  FROM diretor di
  WHERE di.sexo_diretor LIKE 'F'
);


-- 18 Lista as informa��es dos filmes que possuem algum autor que estava no elenco de "The Shawshank Redemption"

SELECT fil.id_filme, fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme
FROM filme fil
INNER JOIN elenco el ON fil.ID_FILME = el.ID_FILME
WHERE el.ID_ATOR IN(
  SELECT el.ID_ATOR
  FROM filme fil2
  INNER JOIN elenco el2 ON fil2.ID_FILME = el2.ID_FILME
  WHERE fil2.nome_filme LIKE 'The Shawshank Redemption'
);

-- 19 Lista as informa��es dos filmes de a��o (ACTION) onde o diretor j� fez um filme de romance (ROMANCE)

SELECT fil.id_filme, fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme
FROM filme fil
INNER JOIN genero_filme gf ON fil.ID_FILME = gf.ID_FILME
INNER JOIN genero ge ON gf.ID_GENERO = ge.ID_GENERO
INNER JOIN diretor_filme df ON fil.ID_FILME = df.ID_FILME
WHERE ge.NOME_GENERO LIKE 'ACAO' AND
df.ID_DIRETOR IN(
  SELECT di2.id_diretor
  FROM diretor di2
  INNER JOIN diretor_filme df2 ON di2.id_diretor = df2.id_diretor
  INNER JOIN filme fil2 ON df2.id_filme = fil2.id_filme
  INNER JOIN genero_filme gf2 ON fil2.id_filme = gf2.ID_FILME
  INNER JOIN genero ge2 ON gf2.id_genero = ge2.id_genero
  WHERE ge2.nome_genero LIKE 'ROMANCE'
);

-- 20 Lista as informa��es dos filmes onde seu diretor nasceu antes de 1970

SELECT fil.id_filme, fil.nome_filme, fil.sinopse_filme, fil.ano_filme, fil.duracao_filme
FROM filme fil
INNER JOIN diretor_filme df ON fil.ID_FILME = df.ID_FILME
WHERE df.ID_DIRETOR IN(
  SELECT di2.ID_DIRETOR
  FROM diretor di2
  WHERE EXTRACT(YEAR FROM di2.nascimento_diretor) < 1970
);





















