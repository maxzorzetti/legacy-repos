

CREATE TABLE plano
(
	id_plano NUMBER(10) NOT NULL,
	nome_plano VARCHAR(50) NOT NULL,
	quantidade_telas_plano NUMBER(1) NOT NULL,
	definicao_tela_plano VARCHAR(25) NOT NULL,
	mensalidade_plano NUMBER(5, 2) NOT NULL,
	CONSTRAINT PK_PLANO PRIMARY KEY (id_plano)

);

CREATE TABLE usuario
(
	id_usuario NUMBER(10) NOT NULL,
	nome_usuario VARCHAR(100) NOT NULL,
	email_usuario VARCHAR(100) NOT NULL,
	senha_usuario VARCHAR(25) NOT NULL,
	id_plano NUMBER(10) NOT NULL,
	CONSTRAINT PK_USUARIO PRIMARY KEY (id_usuario),
	CONSTRAINT UK_USUARIO_EMAIL UNIQUE (email_usuario),
  CONSTRAINT FK_USUARIO_PLANO FOREIGN KEY (id_plano) REFERENCES PLANO (id_plano)
);

CREATE TABLE perfil
(
	id_perfil NUMBER(10) NOT NULL,
	nome_perfil VARCHAR(50) NOT NULL,
	CONSTRAINT PK_PERFIL PRIMARY KEY (id_perfil)
);

CREATE TABLE perfil_usuario
(
	id_perfil NUMBER(10) NOT NULL,
	id_usuario NUMBER(10) NOT NULL,
CONSTRAINT PK_PERFIL_USUARIO PRIMARY KEY (id_perfil, id_usuario),
	CONSTRAINT FK_PERFIL_PERUSU FOREIGN KEY (id_perfil) REFERENCES PERFIL (id_perfil),
	CONSTRAINT FK_USUARIO_PERUSU FOREIGN KEY (id_usuario) REFERENCES USUARIO (id_usuario)	
);

CREATE TABLE filme
(
	id_filme NUMBER(10) NOT NULL,
	nome_filme VARCHAR(100) NOT NULL,
	sinopse_filme VARCHAR(500) NOT NULL,
	ano_filme NUMBER(4) NOT NULL,
	duracao_filme NUMBER(3) NOT NULL,
	CONSTRAINT PK_FILME PRIMARY KEY (id_filme),
	CONSTRAINT CK_ANO_FILME CHECK (ano_filme > 1900)
);

CREATE TABLE diretor
(
	id_diretor NUMBER(10) NOT NULL,
	nome_diretor VARCHAR(100) NOT NULL,
	nascimento_diretor DATE NOT NULL,
	morte_diretor DATE NULL,
	sexo_diretor CHAR(1) NOT NULL,
CONSTRAINT CK_SEXO_DIRETOR CHECK (sexo_diretor IN ('M', 'F')),
CONSTRAINT PK_DIRETOR PRIMARY KEY (id_diretor)
);

CREATE TABLE diretor_filme
(
	id_diretor NUMBER(10) NOT NULL,
	id_filme NUMBER(10) NOT NULL,
	CONSTRAINT PK_DIRETOR_FILME PRIMARY KEY (id_diretor, id_filme),
	CONSTRAINT FK_FILME_DIRFIL FOREIGN KEY (id_filme) REFERENCES FILME (id_filme),
	CONSTRAINT FK_DIRETOR_DIRFIL FOREIGN KEY (id_diretor) REFERENCES DIRETOR (id_diretor)
);

CREATE TABLE ator
(
	id_ator NUMBER(10) NOT NULL,
	nome_ator VARCHAR(100) NOT NULL,
	nascimento_ator DATE NOT NULL,
	morte_ator DATE NULL,
	sexo_ator CHAR(1) NOT NULL,
	CONSTRAINT PK_ATOR PRIMARY KEY (id_ator),
	CONSTRAINT CK_SEXO_ATOR CHECK (sexo_ator IN ('M', 'F')),
	CONSTRAINT CK_NASCIMENTO_ATOR CHECK (EXTRACT (YEAR FROM nascimento_ator) > 1850)
);

CREATE TABLE elenco
(
	id_ator NUMBER(10) NOT NULL,
	id_filme NUMBER(10) NOT NULL,
CONSTRAINT PK_ELENCO PRIMARY KEY (id_ator, id_filme),
CONSTRAINT FK_ATOR_ELENCO FOREIGN KEY (id_ator) REFERENCES ATOR (id_ator),
CONSTRAINT FK_FILME_ELENCO FOREIGN KEY (id_filme) REFERENCES FILME (id_filme)
);

CREATE TABLE genero
(
	id_genero NUMBER(10) NOT NULL,
nome_genero VARCHAR(15) NOT NULL,
CONSTRAINT PK_GENERO PRIMARY KEY (id_genero)
);

CREATE TABLE genero_filme
(
	id_genero NUMBER(10) NOT NULL,
	id_filme NUMBER(10) NOT NULL,
CONSTRAINT PK_GENERO_FILME PRIMARY KEY (id_genero, id_filme),
CONSTRAINT FK_GENERO_GENFIL FOREIGN KEY (id_genero) REFERENCES GENERO(id_genero),
CONSTRAINT FK_FILME_GENFIL FOREIGN KEY (id_filme) REFERENCES FILME(id_filme)
);
