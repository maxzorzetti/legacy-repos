#!/bin/bash

#PBS -l nodes=1:ppn=16:cluster-Grad,walltime=10:00:00

#PBS -M luis.novo@acad.pucrs.br

#PBS -d /home/pp12712/t2/pp-t2/

echo "Running sequential code..."
gcc -o sequential sequential.c
./sequential :> sequential_run.txt

for nodes in 3 4
do
  echo "Running using $nodes nodes..."

  for threads in 1 2 4 8 16
  do
    echo "  ...and $threads threads"
    export OMP_NUM_THREADS=$threads
    :> ${nodes}nodes_${threads}threads.txt

    for chunk_size in {1..100}
    do
      echo "    ...and with ${chunk_size} chunk_size"
      mpicc -fopenmp -o t2 t2.c -DDEFAULT_CHUNK_SIZE=$chunk_size
      mpirun -np ${nodes} t2 >> ${nodes}nodes_${threads}threads.txt
    done
  done
done

echo "All done"