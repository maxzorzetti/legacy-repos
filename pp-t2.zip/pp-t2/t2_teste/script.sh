#!/bin/bash
 
# Configuraçõess para o LAD 
#PBS -m abe
#PBS -V
# Alocação de 1 node, com 16 threads, no clusster Grad e com timeout de 20 horas
#PBS -l nodes=1:ppn=16:cluster-Grad,walltime=20:00:00
# Email que será notificado com o status da execução
#PBS -M matheus.vaccaro@acad.pucrs.br
#PBS -r n
#PBS -j oe
# Diretório onde o arquivo está e onde será gerado o arquivo de log .o
#PBS -d /home/pp12714/t2ProgPar

# Compila o programa quick sort sequencial
gcc -o quickSortSequencial sequencial.c
# Executa o programa e escreve o restultado no arquivo resultQuickSort-Sequencial.txt
./quickSortSequencial >> resultQuickSort-Sequencial.txt


# Para todos os números de nodes solicitados
for nodes in 3 4
do
	for threads in 1 2 4 8 16
	do
		# Configura o número de threads requisitadas
		export OMP_NUM_THREADS=$threads
		# Para todos os tamanhos de chunk solicitados
		for chunkSize in {1..100}
		do
			# Compila o programa MPI com as diretivas do openMP e configura a constante CHUNK_SIZE
			mpicc -fopenmp -o quickSortParalelo quickSortParalelo.c -DCHUNK_SIZE=$chunkSize
			# Executa o programa
			# Cria um arquivo chamado quickSortResults-Nodes<número de nodos>-Threads<número de threads>-ChunkSize<tamanho do chunk>.txt
			# E escreve o resultado da execução no arquivo
			mpirun -np $nodes quickSortParalelo >> quickSortResults-Threads${threads}-Nodes${nodes}-ChunkSize${chunkSize}.txt
		done
	done
done
