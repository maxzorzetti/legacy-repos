#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include "mpi.h"

// CONSTANTS
#define NUM_ARRAYS 1000
#define ARRAY_SIZE 100000
#define REQUEST_WORK_MESSAGE 0
#define RESULT_MESSAGE 1

// PROTOTIPOS
void TimeInit(void);
double TimeStart(void);
double TimeStop(double);
void BubbleSort(int n, int *vetor);

// VALOR DO OVERHEAD DA MEDICAO DE TEMPO
static double TimeOverhead = 0.0;

// FUNCAO QUE CALCULA O OVERHEAD DA MEDICAO DE TEMPO
void TimeInit() {
    double t;

    TimeOverhead = 0.0;
    t = TimeStart();
    TimeOverhead = TimeStop(t);
}

// FUNCAO QUE CAPTURA O TEMPO INICIAL DO TRECHO A SER MEDIDO
double TimeStart() {
    struct timeval tv;
    struct timezone tz;

    if (gettimeofday(&tv, &tz) != 0)
        exit(1);
    return tv.tv_sec + tv.tv_usec / 1000000.0;
}

// FUNCAO QUE CALCULA O TEMPO GASTO NO FINAL DO TRECHO A SER MEDIDO
double TimeStop(double TimeInitial) {
    struct timeval tv;
    struct timezone tz;
    double Time;

    if (gettimeofday(&tv, &tz) != 0)
        exit(1);
    Time = tv.tv_sec + tv.tv_usec / 1000000.0;
    return Time - TimeInitial - TimeOverhead;
}

// FUNCAO DE COMPARACAO PARA O QUICK SORT
int compare(const void *p1, const void *p2) {
    int v1 = *(int *)p1;
    int v2 = *(int *)p2;
    if (v1 < v2)
        return -1;
    if (v1 > v2)
        return 1;
    return 0;
}

int work_bag[NUM_ARRAYS][ARRAY_SIZE];

int main(int argc, char** argv) {
    int i, j, k, aux;
    double inicio, total;
	
    int my_rank;       // Identificador deste processo
    int proc_n;        // Numero de processos disparados pelo usuario na linha de comando (np)
    int message;       // Buffer para as mensagens
    MPI_Status status; // estrutura que guarda o estado de retorno

    MPI_Init(&argc, &argv); // funcao que inicializa o MPI, todo o codigo paralelo esta abaixo

    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank); // pega pega o numero do processo atual (rank)
    MPI_Comm_size(MPI_COMM_WORLD, &proc_n);  // pega informacao do numero de processos (quantidade total)

	// qual o meu papel: sou o mestre ou um dos escravos?
    if (my_rank == 0) { // sou mestre
		
        // INICIALIZA OS ARRAYS A SEREM ORDENADOS
        for (i = 0; i < NUM_ARRAYS; i++) {
            for (j = 0; j < ARRAY_SIZE; j++) {
                work_bag[i][j] = i + j;
			}
            for (j = 0; j < ARRAY_SIZE; j++) {
                k = random() % ARRAY_SIZE;
                aux = work_bag[i][j];
                work_bag[i][j] = work_bag[i][k];
                work_bag[i][k] = aux;
            }
        }   

        TimeInit();
        
        inicio = TimeStart();

		int chunkSizeToSend;
		int workBagSize;
		int workBagIndex;
		
		int chunkSizeReceived;
		int workBagSizeReceived;
		int workBagIndexReceived;
		
		int remainingWorkBagSize = NUM_ARRAYS;
        int remainingSlaves = proc_n -1;
		
		// enquanto tenho escravos trabalhando
        while (remainingSlaves > 0) {
			
            MPI_Recv(&message,       /* buffer onde ser� colocada a mensagem */
                     1,              /* uma unidade do dado a ser recebido */
                     MPI_INT,        /* dado do tipo inteiro */
                     MPI_ANY_SOURCE, /* ler mensagem de qualquer emissor */
                     MPI_ANY_TAG,    /* ler mensagem de qualquer etiqueta (tag) */
                     MPI_COMM_WORLD, /* comunicador padr�o */
                     &status);       /* estrtura com informa��es sobre a mensagem recebida */

			// se a mensagem recebida de um escravo for que ele está pronto para trabalhar
            if (message == REQUEST_WORK_MESSAGE) {
				// verifica se tem trabalho a ser realizado
                if (remainingWorkBagSize == 0) { // caso não tenha
					// manda mensagem com tamanho da workbag = 0
                    message = 0;
                    MPI_Send(&message, 1, MPI_INT, status.MPI_SOURCE, 1, MPI_COMM_WORLD);
					// diminiu o número de escravos, já que a mensagem acima fara com que o escravo que a recebeu pare de trabalhar
                    remainingSlaves--;
                    continue;
                }
				
				// há trabalho a ser realizado
				
				// calcula o tamanho do chunk que será enviado
				// se o tamanha da workbag restante não é multiplo de CHUNK_SIZE, manda o resto de sua divisão
				// exemplo: CHUNK_SIZE = 30 e remainingWorkBagSize = 100
				// 30 % 100 = 10, então manda 10 pro escravo. Manda menos agora, para que nos próximos envios possa sempre enviar CHUNK_SIZE máxima
                if (remainingWorkBagSize % CHUNK_SIZE == 0) {
                    chunkSizeToSend = CHUNK_SIZE;
                } else {
                    chunkSizeToSend = remainingWorkBagSize % CHUNK_SIZE;
                }
                // manda chunk pro escravo
                MPI_Send(&chunkSizeToSend, 1, MPI_INT, status.MPI_SOURCE, 1, MPI_COMM_WORLD);

				// manda índice do chunk na workbag para o escravo
                workBagIndex = NUM_ARRAYS - remainingWorkBagSize;
                MPI_Send(&workBagIndex, 1, MPI_INT, status.MPI_SOURCE, 1, MPI_COMM_WORLD);

				// manda workbag para escravo
                workBagSize = ARRAY_SIZE * chunkSizeToSend;
                MPI_Send(&work_bag[workBagIndex], workBagSize, MPI_INT, status.MPI_SOURCE, 1, MPI_COMM_WORLD);
				// atualiza tamanho da workbag
                remainingWorkBagSize -= chunkSizeToSend;
				
            } else if (message == RESULT_MESSAGE) { // mensagem recebida foi um chunk da workbag ordenada
			
				// recebe tamanho do chunk que será enviado pelo escravo
                MPI_Recv(&chunkSizeReceived, 1, MPI_INT, status.MPI_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

				// recebe índice da workbag
                MPI_Recv(&workBagIndexReceived, 1, MPI_INT, status.MPI_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
                workBagSizeReceived = chunkSizeReceived * ARRAY_SIZE;
				
				// recebe workbag do escravo
                MPI_Recv(&work_bag[workBagIndexReceived], workBagSizeReceived, MPI_INT, status.MPI_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
				
            }
        }

        total = TimeStop(inicio);

        // VERIFICA SE OS ARRAYS ESTAO ORDENADOS
        for (i = 0; i < NUM_ARRAYS; i++) {
            for (j = 0; j < ARRAY_SIZE - 1; j++) {
                if (work_bag[i][j] != i + j) {
                    return 1;
				}
			}
        }

        printf("finished\n");
        printf("tempo de execução %lf \n",total);
		
    } else { // sou escravo
	
		int slaveChunkSizeReceived;
		int slaveWorkBagSize;
		int slaveWorkBagIndex;
		
        message = -1;

        while (1) {
			// mando mensagem para o mestre pedindo trabalho
            message = 0;
            MPI_Send(&message, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);

			// recebe tamanho do chunk que será enviado pelo mestre
            MPI_Recv(&slaveChunkSizeReceived, 1, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

			// se chunk recebido for 0, pode parar de trabalhar
            if (slaveChunkSizeReceived == 0) {
                break;
            }

			// chunk recebido é diferente de 0
			
			// recebe índice da workbag do mestre
            MPI_Recv(&slaveWorkBagIndex, 1, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
			// calcula tamanho ocupado pelo chunk
            slaveWorkBagSize = slaveChunkSizeReceived * ARRAY_SIZE;

			// recebe conteúdo do chunk
            MPI_Recv(&work_bag[slaveWorkBagIndex], slaveWorkBagSize, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);       

			// ordena o chunk
            #pragma omp parallel for schedule(dynamic)
            for (i = slaveWorkBagIndex; i < slaveWorkBagIndex + slaveChunkSizeReceived; i++) {
                qsort((void *)&work_bag[i][0], ARRAY_SIZE, sizeof(int), compare);
            }

            // envia mensagem avisando que o chunk está ordenado e será enviado
            message = 1;
            MPI_Send(&message, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);

			// envia tamanho do chunk
            MPI_Send(&slaveChunkSizeReceived, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);
			// envia índice do chunk
            MPI_Send(&slaveWorkBagIndex, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);
			// envia conteúdo do chunk
            MPI_Send(&work_bag[slaveWorkBagIndex], slaveWorkBagSize, MPI_INT, 0, 1, MPI_COMM_WORLD);
        }
    }

	// finaliza escravo
    MPI_Finalize();

    return 0;
}
