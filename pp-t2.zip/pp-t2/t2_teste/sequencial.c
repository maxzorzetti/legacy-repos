#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#define NUM_ARRAYS 1000
#define ARRAY_SIZE 100000

// PROTOTIPOS
void	TimeInit   (void);
double	TimeStart  (void);
double	TimeStop   (double);
void    BubbleSort (int n, int * vetor);

// VALOR DO OVERHEAD DA MEDICAO DE TEMPO
static double TimeOverhead=0.0;

// ESTRUTURA DE DADOS COMPARTILHADA
int work_bag[NUM_ARRAYS][ARRAY_SIZE];

// FUNCAO QUE CALCULA O OVERHEAD DA MEDICAO DE TEMPO
void TimeInit() {
  double t;

  TimeOverhead=0.0;
  t = TimeStart();
  TimeOverhead=TimeStop(t);
}

// FUNCAO QUE CAPTURA O TEMPO INICIAL DO TRECHO A SER MEDIDO
double TimeStart() {
  struct timeval tv;
  struct timezone tz;

  if (gettimeofday(&tv,&tz)!=0)
      exit(1);
  return tv.tv_sec + tv.tv_usec/1000000.0;
}

// FUNCAO QUE CALCULA O TEMPO GASTO NO FINAL DO TRECHO A SER MEDIDO
double TimeStop(double TimeInitial) {
  struct timeval tv;
  struct timezone tz;
  double Time;

  if (gettimeofday(&tv,&tz)!=0)
      exit(1);
  Time = tv.tv_sec + tv.tv_usec/1000000.0;
  return Time-TimeInitial-TimeOverhead;
}

#ifdef BLUBLESORT
// BUBBLE SORT
void BubbleSort(int n, int * vetor) {
  int c =0, d, troca, trocou =1;

  while (c < (n-1) && trocou ) {
        trocou = 0;
        for (d = 0 ; d < n - c - 1; d++)
            if (vetor[d] > vetor[d+1]) {
                troca      = vetor[d];
                vetor[d]   = vetor[d+1];
                vetor[d+1] = troca;
                trocou = 1;
            }
        c++;
  }
}
#endif

// FUNCAO DE COMPARACAO PARA O QUICK SORT
int compare(const void *p1, const void *p2) {
  int v1 = *(int *)p1;
  int v2 = *(int *)p2;
  if (v1 < v2)
     return -1;
  if (v1 > v2)
     return 1;
  return 0;
}

int main() {
  int i, j, k, aux;
  double inicio, total;

  TimeInit();
  srandom(time(NULL));
  // INICIALIZA OS ARRAYS A SEREM ORDENADOS
  for (i=0; i<NUM_ARRAYS; i++) {
      for (j=0; j<ARRAY_SIZE; j++)
          work_bag[i][j] = i+j;
      for (j=0; j<ARRAY_SIZE; j++) {
          k = random() % ARRAY_SIZE;
          aux = work_bag[i][j];
          work_bag[i][j]   = work_bag[i][k];
          work_bag[i][k]   = aux;
      }
  }

  // REALIZA A ORDENACAO
  inicio = TimeStart(); 
  for (i=0; i<NUM_ARRAYS; i++) {
      // BubbleSort(ARRAY_SIZE, &work_bag[i][0]);
      qsort((void *)&work_bag[i][0],ARRAY_SIZE,sizeof(int),compare);
  }
  total = TimeStop(inicio);

  // VERIFICA SE OS ARRAYS ESTAO ORDENADOS
  for (i=0 ; i<NUM_ARRAYS; i++) {
      for (j=0 ; j<ARRAY_SIZE-1; j++)
          if (work_bag[i][j] != i+j )
             return 1;
  }

  // MOSTRA O TEMPO DE EXECUCAO
  printf("%lf",total);
  return 0;
}
