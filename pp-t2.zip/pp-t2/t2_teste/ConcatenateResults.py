# Array com o número de Nodos utilizados para rodar o programa
nodes = [3, 4]
# Array com o número de threads utilizados para rodar o programa
threads = [1, 2, 4, 8, 16]
# Array com o tamanho de Chunks utilizadosss para rodar o programa (1 a 100)
chunk_sizes = range(1, 101)

# Palabra chave utilizada no split dos arquivos de resultado de cada execução do programa para pegar o tempo de execução
keyword = "tempo de execuÃ§Ã£o "

# Arquivo que será gerado com todos os resultados
resultFile = open("results.txt", "w")

for node in nodes:
	for thread in threads:
		# Para cada combinação de Nodo e Thread, escreve uma string para indicar os resultados de suas variações de tamanho de Chunk
		resultFile.write("RESULTS for Node: " + str(node) + " | Thread: " + str(thread) + "\n")
		for chunk_size in chunk_sizes:
			# Abre o arquivo de resultado de uma execução
			fileName = "results-Threads" + str(thread) + "-Nodes" + str(node) + "-ChunkSize" + str(chunk_size) +".txt"
			fileToRead = open(fileName, "r")
			
			# Pega as linhas do arquivo de resultado da execução
			lines = fileToRead.readlines()
			
			# Pega o tempo de execução
			secondLine = lines[1]
			splittedLine = secondLine.split(keyword)
			executionTime = splittedLine[1]
			print(executionTime)
			
			# Escreve tempo de execução no arquivo com todos os resultadoss
			resultFile.write(executionTime)
			fileToRead.close()
			
resultFile.close()
