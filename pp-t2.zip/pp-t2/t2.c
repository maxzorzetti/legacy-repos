#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <mpi.h>

// PROTOTIPOS
void TimeInit(void);
double TimeStart(void);
double TimeStop(double);
void BubbleSort(int n, int *vetor);

// VALOR DO OVERHEAD DA MEDICAO DE TEMPO
static double TimeOverhead = 0.0;

// FUNCAO QUE CALCULA O OVERHEAD DA MEDICAO DE TEMPO
void TimeInit()
{
    double t;

    TimeOverhead = 0.0;
    t = TimeStart();
    TimeOverhead = TimeStop(t);
}

// FUNCAO QUE CAPTURA O TEMPO INICIAL DO TRECHO A SER MEDIDO
double TimeStart()
{
    struct timeval tv;
    struct timezone tz;

    if (gettimeofday(&tv, &tz) != 0)
        exit(1);
    return tv.tv_sec + tv.tv_usec / 1000000.0;
}

// FUNCAO QUE CALCULA O TEMPO GASTO NO FINAL DO TRECHO A SER MEDIDO
double TimeStop(double TimeInitial)
{
    struct timeval tv;
    struct timezone tz;
    double Time;

    if (gettimeofday(&tv, &tz) != 0)
        exit(1);
    Time = tv.tv_sec + tv.tv_usec / 1000000.0;
    return Time - TimeInitial - TimeOverhead;
}

#ifdef BLUBLESORT
// BUBBLE SORT
void BubbleSort(int n, int *vetor)
{
    int c = 0, d, troca, trocou = 1;

    while (c < (n - 1) && trocou)
    {
        trocou = 0;
        for (d = 0; d < n - c - 1; d++)
            if (vetor[d] > vetor[d + 1])
            {
                troca = vetor[d];
                vetor[d] = vetor[d + 1];
                vetor[d + 1] = troca;
                trocou = 1;
            }
        c++;
    }
}
#endif

// FUNCAO DE COMPARACAO PARA O QUICK SORT
int compare(const void *p1, const void *p2)
{
    int v1 = *(int *)p1;
    int v2 = *(int *)p2;
    if (v1 < v2)
        return -1;
    if (v1 > v2)
        return 1;
    return 0;
}

const int KILL_MSG = 0;
const int REQUEST_MSG = 0;
const int RESULT_MSG = 1;

// #define DEFAULT_CHUNK_SIZE 128
#define NUM_ARRAYS 1000
#define ARRAY_SIZE 100000

int main(int argc, char* argv[] )
{
    // Declaração de variáveis usadas por ambos mestre e escravos
    int i, j, k;       // Contadores auxiliares
    int my_rank;       // Identificador deste processo
    int proc_n;        // Número de processos disparados pelo usuario na linha de comando (np)
    int message;       // Buffer para mensagens
    MPI_Status status; // Estrutura que guarda o estado de retorno de mensagens MPI

    MPI_Init(&argc, &argv); // Função que inicializa o MPI, todo o codigo paralelo está abaixo

    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank); // Pega o número do processo atual (rank)
    MPI_Comm_size(MPI_COMM_WORLD, &proc_n);  // Pega informação do número de processos (quantidade total)

    int chunk_size;     // Número de arrays em uma solicitação de trabalho 
    int work_amount;    // Número total de inteiros em uma solicitação de trabalho. Definido por ARRAY_SIZE * chunk_size
    int work_id;        // Número identificador do primeiro array de uma solicitação de trabalho

    if (my_rank == 0)
    {
        // Lógica do mestre
        // Alocação de memória para a estrutura que guarda os arrays a serem ordenados
        int *work_bag = malloc(NUM_ARRAYS * ARRAY_SIZE * sizeof(int));
        
        // Geração dos arrays a serem ordenados
        int aux; // Variável auxiliar
        for (i = 0; i < NUM_ARRAYS; i++)
        {
            for (j = 0; j < ARRAY_SIZE; j++)
                work_bag[(i * ARRAY_SIZE) + j] = i + j;
            for (j = 0; j < ARRAY_SIZE; j++)
            {
                k = random() % ARRAY_SIZE;
                aux = work_bag[(i * ARRAY_SIZE) + j];
                work_bag[(i * ARRAY_SIZE) + j] = work_bag[(i * ARRAY_SIZE) + k];
                work_bag[(i * ARRAY_SIZE) + k] = aux;
            }
        }

        // Medição de tempo de processamento
        TimeInit();
        double startTime = TimeStart();

        // Declaração e atribuição de variáveis usadas para controle do mestre
        int remaining_work = NUM_ARRAYS;        // Arrays que ainda precisam ser ordenados, ou "trabalho" a ser feito
        int *current_work_pointer = work_bag;   // Ponteiro para seção da workbag que ainda não foi ordenada
        int remaining_slaves = proc_n - 1;      // Número de slaves que ainda estão ativos

        // Loop de comunicação
        while (remaining_slaves > 0 || remaining_work > 0)  // Assim que não houver mais trabalho a ser feito e 
        {                                                   // todos os escravos foram avisados disso, encerra o loop
            // printf("%d - remainingslaves: %d | remaining_work: %d\n", my_rank, remaining_slaves, remaining_work);
            // fflush(stdout);

            // Recebe mensagem do escravo
            MPI_Recv(&message,       /* buffer onde ser� colocada a mensagem */
                     1,              /* uma unidade do dado a ser recebido */
                     MPI_INT,        /* dado do tipo inteiro */
                     MPI_ANY_SOURCE, /* ler mensagem de qualquer emissor */
                     MPI_ANY_TAG,    /* ler mensagem de qualquer etiqueta (tag) */
                     MPI_COMM_WORLD, /* comunicador padr�o */
                     &status);       /* estrtura com informa��es sobre a mensagem recebida */
            

            if (message == REQUEST_MSG) // Recebeu mensagem de solicitação de trabalho
            {
                // printf("%d - received REQUEST_WORK command from slave %d\n", my_rank, status.MPI_SOURCE);
                // fflush(stdout);

                if (remaining_work == 0) // Não há mais trabalho a ser feito
                {
                                    
                    // printf("%d - no work available for slave %d\n", my_rank, status.MPI_SOURCE);
                    // fflush(stdout);
                    // Avisa escravo que não há mais trabalho
                    MPI_Send(&KILL_MSG, 1, MPI_INT, status.MPI_SOURCE, 1, MPI_COMM_WORLD);
                    remaining_slaves--;

                    // printf("%d - killed slave %d\n", my_rank, status.MPI_SOURCE);
                    // fflush(stdout);

                    continue;
                }

                // Define o quanto de trabalho mandar para o escravo
                if (remaining_work < DEFAULT_CHUNK_SIZE)
                    chunk_size = remaining_work;
                else 
                    chunk_size = DEFAULT_CHUNK_SIZE;
                
                // printf("%d - sending chunk size %d\n", my_rank, chunk_size);
                // fflush(stdout);
                // Manda o número de arrays a serem ordenados
                MPI_Send(&chunk_size, 1, MPI_INT, status.MPI_SOURCE, 1, MPI_COMM_WORLD);

                work_id = NUM_ARRAYS - remaining_work;
                // Manda o identificador do primeiro array do trabalho a ser enviado
                // printf("%d - sending work id %d\n", my_rank, work_id);
                // fflush(stdout);
                MPI_Send(&work_id, 1, MPI_INT, status.MPI_SOURCE, 1, MPI_COMM_WORLD);

                work_amount = ARRAY_SIZE * chunk_size;
                // Manda os arrays a serem ordenados
                // printf("%d - sending work of size %d\n", my_rank, work_amount);
                // fflush(stdout);
                MPI_Send(current_work_pointer, work_amount, MPI_INT, status.MPI_SOURCE, 1, MPI_COMM_WORLD);

                current_work_pointer += work_amount;    // Atualiza o ponteiro que aponta para a seção não-ordenada da work_bag
                remaining_work -= chunk_size;           // Atualiza quantos arrays ainda devem ser ordenados
            }
            else if (message == RESULT_MSG) // Recebeu mensagem de envio de trabalho processado
            {
                // printf("%d - received RESULT command from %d\n", my_rank, status.MPI_SOURCE);
                // fflush(stdout);
                
                // Recebe número de arrays a serem recebidos
                MPI_Recv(&chunk_size,
                         1,
                         MPI_INT,
                         status.MPI_SOURCE,
                         MPI_ANY_TAG,
                         MPI_COMM_WORLD,
                         &status);
                // printf("%d - received chunksize %d of RESULT from slave %d\n", my_rank, chunk_size, status.MPI_SOURCE);
                // fflush(stdout);

                // Recebe número identificador do primeiro array a ser recebido
                MPI_Recv(&work_id,
                         1,
                         MPI_INT,
                         status.MPI_SOURCE,
                         MPI_ANY_TAG,
                         MPI_COMM_WORLD,
                         &status);
                // printf("%d - received work id \n of RESULT from slave %d\nprint", my_rank, status.MPI_SOURCE);
                // fflush(stdout);

                work_amount = chunk_size * ARRAY_SIZE;
                // Recebe arrays ordenados, colocando-os diretamente na work_bag
                MPI_Recv(work_bag + (work_id * ARRAY_SIZE),
                         work_amount,
                         MPI_INT,
                         status.MPI_SOURCE,
                         MPI_ANY_TAG,
                         MPI_COMM_WORLD,
                         &status);
                // printf("%d - received RESULT of size %d from slave %d\n", my_rank, work_amount, status.MPI_SOURCE);
                // fflush(stdout);
            }
        }

        // Medição de tempo
        double totalDuration = TimeStop(startTime);

        // sleep(1); // Atrasa o display da mensagem de tempo total para facilitar a sua visibilidade
        printf("%d %f\n", DEFAULT_CHUNK_SIZE, totalDuration);
        fflush(stdout);

        // Verificação dos resultados
        // printf("verifying results\n");
        // fflush(stdout);

        int result = 0; // Retorna 0 se a ordenação está correta
        // Verifica se os arrays recebidos estão ordenados mesmo
        // for (i = 0; i < NUM_ARRAYS; i++)
        // {
        //     for (j = 0; j < ARRAY_SIZE; j++) {
        //         // printf("%d ", work_bag[(i * ARRAY_SIZE) + j]); // Imprime os arrays durante a verificação

        //         if(work_bag[(i * ARRAY_SIZE) + j] != i + j) {
        //             result = -1; // Retorna -1 se a ordenação está errada
        //             break;
        //         }
        //     }
        //     // printf("\n");
        // }

        // if (result == 0) {
        //     printf("sort was succesful\n");
        // } else {
        //     printf("\nsort was not succesful\n");
        // }
        // fflush(stdout);

        // Libera a memória da work_bag
        free(work_bag);

        MPI_Finalize();
        return result;
    }
    else
    {
        // Lógica do escravo
        int *buffer; // Buffer para armazenamento dos arrays a serem ordenados
        message = -1;

        while (1) // Loop de processamento
        {
            
            //printf("%d - sending request\n", my_rank);
            //fflush(stdout);
            // Solicita trabalho ao mestre
            MPI_Send(&REQUEST_MSG, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);

            //printf("%d - receiving chunksize\n", my_rank);
            //fflush(stdout);
            // Recebe número de arrays a serem ordenados
            MPI_Recv(&chunk_size,
                     1,
                     MPI_INT,
                     0,
                     MPI_ANY_TAG,
                     MPI_COMM_WORLD,
                     &status);
            //printf("%d - received chunksize %d\n", my_rank, chunk_size);
            //fflush(stdout);

            if (chunk_size == 0)    // Se o número de arrays a serem processados é 0,
            {                       // significa que não há mais trabalho disponível e
                MPI_Finalize();     // o escravo encerra seu processamento
                return 0;           
            }

            // A partir daqui, há trabalho a ser feito

            // Recebe número identificador do primeiro array a ser ordenado
            MPI_Recv(&work_id,
                     1,
                     MPI_INT,
                     0,
                     MPI_ANY_TAG,
                     MPI_COMM_WORLD,
                     &status);
            //printf("%d - received work id %d\n", my_rank, work_id);
            //fflush(stdout);

            work_amount = chunk_size * ARRAY_SIZE;      // Calcula quantos inteiros devem ser alocados
            buffer = malloc(work_amount * sizeof(int)); // Aloca memória para depositar os arrays a serem ordenados

            // Recebe arrays a serem ordenados
            MPI_Recv(buffer,
                     work_amount,
                     MPI_INT,
                     0,
                     MPI_ANY_TAG,
                     MPI_COMM_WORLD,
                     &status);
            //printf("%d - received work of size %d\n", my_rank, work_amount);
            //fflush(stdout);

            // printf("=========== RAW\n");
            // for (i = 0; i < chunk_size; i++)
            // {
            //     for (j = 0; j < ARRAY_SIZE; j++) {
            //         printf("%d ", buffer[(i * ARRAY_SIZE) + j]);
            //     }
            //     printf("\n");
            // }
            // printf("===========\n");

            // Ordena arrays
            #pragma omp parallel for schedule(dynamic)
            for (i = 0; i < chunk_size; i++)
            {
                qsort((void *)&buffer[i * ARRAY_SIZE], ARRAY_SIZE, sizeof(int), compare);
            }
            // printf("===========SORTED\n");
            // for (i = 0; i < chunk_size; i++)
            // {
            //     for (j = 0; j < ARRAY_SIZE; j++) {
            //         printf("%d ", buffer[(i * ARRAY_SIZE) + j]);
            //     }
            //     printf("\n");
            // }
            // printf("==============\n");

            //printf("%d - sending result msg\n", my_rank);
            //fflush(stdout);
            // Envia mensagem de trabalho feito
            MPI_Send(&RESULT_MSG, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);

            //printf("%d - sending result chunksize %d\n", my_rank, chunk_size);
            //fflush(stdout);
            // Avisa quantos arrays vai mandar para o mestre
            MPI_Send(&chunk_size, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);

            //printf("%d - sending result work id %d\n", my_rank, work_id);
            //fflush(stdout);
            // Avisa qual é o número identificador do primeiro array a ser mandando
            MPI_Send(&work_id, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);

            //printf("%d - sending work of size %d\n", my_rank, work_amount);
            //fflush(stdout);
            // Envia arrays ordenados
            MPI_Send(buffer, work_amount, MPI_INT, 0, 1, MPI_COMM_WORLD);

            // Libera a memória que foi alocada
            free(buffer);
        }
    }
}

//cuidar estas coisas:
//obtenção de tempos (ou usando funções de tempo presentes na versão sequencial ou funções de medição de tempo do MPI);
//não considerar tempos de criação, embaralhamento e verificação do conteúdo dos vetores na medição de tempo;
//indicar o número de horas usadas pelo grupo na execução no cluster do LAD, durante o desenvolvimento do trabalho;