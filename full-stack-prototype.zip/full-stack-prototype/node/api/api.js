var express = require('express');
var app = express();

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/test');
var db = mongoose.connection;

var Schema = mongoose.Schema;
var personSchema = new Schema({
	name: String,
	occupation: String
});

var Person = mongoose.model('Person', personSchema);

app.get('/', function(req, res){
	Person.find({}, function(err, people){
		var answer = '';
		res.setHeader('Access-Control-Allow-Origin','*');
		if(err){
			console.log("ERROR!");
			res.end("Error!");
		} else {
			people.forEach( function(p, i) { answer = answer + p.name + ' '; } );		
			res.end(answer);
		}		
	});
});

app.listen(3000, function(){
	console.log("Listening on port 3000.");
});