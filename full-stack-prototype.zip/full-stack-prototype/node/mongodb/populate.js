var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/test');
var db = mongoose.connection;

var Schema = mongoose.Schema;
var personSchema = new Schema({
	name: String,
	occupation: String
});

var Person = mongoose.model('Person', personSchema);

var rick = new Person({ name: 'Rick', occupation: 'Scientist' });
var morty = new Person({ name: 'Morty', occupation: 'Student' });
var summer = new Person({ name: 'Summer', occupation: 'Student' });
var beth = new Person({ name: 'Beth', occupation: 'Horse Surgeon' });

var callback = function(err, document){
	if (err) return console.error(err);
	console.log(document.name + " saved successfully!");
};

db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
	rick.save(callback);
	morty.save(callback);
	summer.save(callback);
	beth.save(callback);
});
