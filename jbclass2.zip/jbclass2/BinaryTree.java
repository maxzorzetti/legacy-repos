// BinaryTree.java
public class BinaryTree {

  // Referência para a raiz da árvore. É null para o caso de uma
  // árvore vazia.

  private Node root;

  private static class Node {
    Node left;
    Node right;
    int data;

    Node( int newData ) {
      left = right = null;
      data = newData;
    }
  }

  /* Cria uma árvore vazia, ou seja, uma referência nula. */
  public BinaryTree() {
    root = null;
  }

  public void insert( int data ) {
    root = insert( root, data );
  }

  private Node insert( Node n, int data ) {
      if( n == null)return new Node(data);         
      if(data > n.data) n.right = insert(n.right, data);
      else n.left = insert(n.left, data);
      return n;
  }

  public void print( ) {
    print( root , "");
  }

  private void print( Node n , String s) {
      if(n == null)return;          
      print(n.left, s+"\t");
      System.out.println(s + n.data); //caminhamento infixado 
      print(n.right, s+"\t");
  }

  public void destroy( ) {
    root = destroy( root );
  }

  private Node destroy( Node n ) {
    if(n == null)return n;          
    n.right = destroy (n.right);
    n.left = destroy (n.left);
    System.out.println(n.data + ": AAAAAAH!");
    return null;
  }

  public int profundidade(){
     return profundidade(root, 0) - 1;
  }
  
  private int profundidade( Node n, int p){
      if( n == null) return p;
      int x = profundidade( n.right, p+1);
      int y = profundidade( n.left, p+1);
      if(x > y) return x;
      return y;
  }
  
  public int altura(){
      return altura( root ) - 1;
  }
  
  private int altura( Node n ){
      if( n == null) return 0;      
      int alturaL = altura(n.left);
      int alturaR = altura(n.right);
      if(alturaL > alturaR) return alturaL + 1;
      return alturaR + 1;
      
  }
  
}
