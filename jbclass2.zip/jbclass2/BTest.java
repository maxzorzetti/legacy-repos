
import java.util.Scanner;

public class BTest {
    public static void main( String[] args ) {
        System.out.println("\fNumber Murder Simulator 1.1v");
        
        BinaryTree T = new BinaryTree();

        Scanner input = new Scanner( System.in );

        while ( input.hasNext() ) {
            String temp = input.next();

            if ( temp.equals( "quit" ) ) break;
            if ( temp.matches( "[0-9]+" ) ) T.insert( Integer.parseInt( temp ) );
            if ( temp.equals( "prof" ) ) System.out.println(T.profundidade());
            if ( temp.equals( "altura" ) ) System.out.println(T.altura());
            System.out.println();
            T.print();

        }
        System.out.println("Morram!");
        T.destroy( );
        System.out.println("10/10 would murder numbers again");
    }
}
