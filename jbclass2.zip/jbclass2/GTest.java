import java.util.Scanner;

public class GTest {

  public static void main( String[] args ) {
    System.out.println("Spips");
    GenTree T = new GenTree( 100 );

    Scanner input = new Scanner( System.in );

    while ( input.hasNext() ) {
      String temp = input.next();

      if ( temp.equals( "quit" ) ) System.exit(0);
      if ( temp.matches( "ins" ) ){
        T.insert( Integer.parseInt( input.next() ),
                  Integer.parseInt( input.next() ));
      }
      if ( temp.equals( "dir" ) ) T.dir();
      
      T.print();
    }
  }
}
