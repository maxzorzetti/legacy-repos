// GenTree.java
public class GenTree {

  private TreeNode root;

  private static class TreeNode {
    Node children;
    int data;

    TreeNode( int newData ) {
      data = newData;
      children = null;
    }

    Node Children( )          { return children; }

  }

  private static class Node {
    TreeNode child;
    Node next;

    Node( TreeNode n )         { child = n; next = null; }
    Node Next( )               { return next; }
    TreeNode Child( )          { return child; }
  }

  public GenTree( int n ) { root = new TreeNode( n ); }

  TreeNode find( TreeNode n, int val ) {
    if ( n == null ) return null;
    if ( n.data == val ) return n;
    Node f = n.Children();
    while ( f != null ) {
      TreeNode ax = find( f.Child(), val );
      if ( ax != null ) return ax;
      f = f.Next();
    }
    return null;
  }

  Node append( Node chi, TreeNode n ) {
    if ( chi == null ) return new Node( n );
    chi.next = append( chi.next, n );
    return chi;
  }

  void insert( int p, int f ) {
    TreeNode n = find( root, p );
    if ( n == null ) return;
    n.children = append( n.children, new TreeNode( f ) );
  }

  void print( ) {
    print ( root );
    System.out.println();
  }

  void print( TreeNode n ) {
    if ( n == null ) return;    
    System.out.print("(" + n.data);
    Node f = n.Children();
    while ( f != null ) {
      print(f.child);
      f = f.Next();      
    }
    System.out.print(")");
    
  }
  
  void dir( TreeNode n , String t) {
    if ( n == null ) return;    
    System.out.println(t + n.data);
    Node f = n.Children();    
    while ( f != null ) {
      dir(f.child, t + "\t");
      f = f.Next();      
    }
  }
  
  void dir( ) {
      dir(root, "");
  }
  
  void remove(int n){
  }

}
