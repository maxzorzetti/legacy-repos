# -*- coding: utf-8 -*-
"""
Created on Mon Aug 01 16:54:01 2016

@author: Max Zorzetti
"""
import json
import sqlite3
import time
#import csv
#from Tkinter import * #TODO GUI
from unicode_csv import UnicodeWriter
from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener

conn = sqlite3.connect('test.db')

def create_db(connection = conn):
    cursor = connection.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS tweets(
                        user text,
                        tweet text
                      )''')
    connection.commit()

def insert_into_db(user, tweet, connection = conn):
    cursor = connection.cursor()
    cursor.execute("INSERT INTO tweets VALUES (?, ?)", (user, tweet))
    connection.commit()
    
#csvFile = open("dados.csv", "a")
#csvWriter = csv.writer(csvFile, delimiter=',')
def processText(text):
    text = text.replace('\n', ' ').replace('\r', ' ')
    text = text.replace('&amp', '&'). replace('&lt;', '<').replace('&gt;', '>')
    return text

class listener(StreamListener):
    def on_data(self, data):  
        raw_data = json.loads(data)
        user = {'screen_name': raw_data['user']['screen_name']}
        tweet = {'text': processText(raw_data['text'])}
        
        output = open('dados.csv', 'a')
        UnicodeWriter(output, delimiter='|', lineterminator='\n').writerow((tweet['text'].replace('\n', ' ').replace('r', ' '), user['screen_name']))
        output.close()
        
        print('@' + user['screen_name'] + '\n' + tweet['text'] + '\n')
        return(True)
    
    def on_error(self, status):
        print status
        
        
ckey = 'rJH91ulKfGZt5YIc92LLgtEce'
csecret = '3rxGYSOop12aAFrtSqE2PFVbAVC4XbyYQT1IEMOBLEpTbqT7VN'
atoken = '3670478417-xkfBRYbEGELGBiAl4Tf1dZ1dwJ4uPtJ5C4pcthv'
asecret = '7H2S2Q4gaunYryTezFHAKWSMXDtUsTEmljo4xLZv8ifPy'



if __name__ == '__main__':
    while True:
        try:
            auth = OAuthHandler(ckey, csecret)
            auth.set_access_token(atoken, asecret)
            twitterStream = Stream(auth, listener())
            twitterStream.filter(track=["hearthstone"])
        except IOError as e:
            print "I/O error({0}): {1}".format(e.errno, e.strerror)
            time.sleep(10)
            continue
            
    